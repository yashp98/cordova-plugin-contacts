﻿define("MobilePatterns.Adaptive.Columns2.mvc$model", ["OutSystems", "MobilePatterns.model"], function (OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("UseGutter", "useGutterIn", "UseGutter", true, OS.Types.Boolean, function () {
return true;
}), 
this.attr("_useGutterInDataFetchStatus", "_useGutterInDataFetchStatus", "_useGutterInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}), 
this.attr("PhonePortraitBreak", "phonePortraitBreakIn", "PhonePortraitBreak", true, OS.Types.Text, function () {
return MobilePatternsModel.staticEntities.columnBreak.breakNone;
}), 
this.attr("_phonePortraitBreakInDataFetchStatus", "_phonePortraitBreakInDataFetchStatus", "_phonePortraitBreakInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}), 
this.attr("PhoneLandscapeBreak", "phoneLandscapeBreakIn", "PhoneLandscapeBreak", true, OS.Types.Text, function () {
return MobilePatternsModel.staticEntities.columnBreak.breakNone;
}), 
this.attr("_phoneLandscapeBreakInDataFetchStatus", "_phoneLandscapeBreakInDataFetchStatus", "_phoneLandscapeBreakInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}), 
this.attr("TabletPortraitBreak", "tabletPortraitBreakIn", "TabletPortraitBreak", true, OS.Types.Text, function () {
return MobilePatternsModel.staticEntities.columnBreak.breakNone;
}), 
this.attr("_tabletPortraitBreakInDataFetchStatus", "_tabletPortraitBreakInDataFetchStatus", "_tabletPortraitBreakInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}), 
this.attr("TabletLandscapeBreak", "tabletLandscapeBreakIn", "TabletLandscapeBreak", true, OS.Types.Text, function () {
return MobilePatternsModel.staticEntities.columnBreak.breakNone;
}), 
this.attr("_tabletLandscapeBreakInDataFetchStatus", "_tabletLandscapeBreakInDataFetchStatus", "_tabletLandscapeBreakInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
})
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("UseGutter" in inputs) {
this.variables.useGutterIn = inputs.UseGutter;
if("_useGutterInDataFetchStatus" in inputs) {
this.variables._useGutterInDataFetchStatus = inputs._useGutterInDataFetchStatus;
}

}

if("PhonePortraitBreak" in inputs) {
this.variables.phonePortraitBreakIn = inputs.PhonePortraitBreak;
if("_phonePortraitBreakInDataFetchStatus" in inputs) {
this.variables._phonePortraitBreakInDataFetchStatus = inputs._phonePortraitBreakInDataFetchStatus;
}

}

if("PhoneLandscapeBreak" in inputs) {
this.variables.phoneLandscapeBreakIn = inputs.PhoneLandscapeBreak;
if("_phoneLandscapeBreakInDataFetchStatus" in inputs) {
this.variables._phoneLandscapeBreakInDataFetchStatus = inputs._phoneLandscapeBreakInDataFetchStatus;
}

}

if("TabletPortraitBreak" in inputs) {
this.variables.tabletPortraitBreakIn = inputs.TabletPortraitBreak;
if("_tabletPortraitBreakInDataFetchStatus" in inputs) {
this.variables._tabletPortraitBreakInDataFetchStatus = inputs._tabletPortraitBreakInDataFetchStatus;
}

}

if("TabletLandscapeBreak" in inputs) {
this.variables.tabletLandscapeBreakIn = inputs.TabletLandscapeBreak;
if("_tabletLandscapeBreakInDataFetchStatus" in inputs) {
this.variables._tabletLandscapeBreakInDataFetchStatus = inputs._tabletLandscapeBreakInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("MobilePatterns.Adaptive.Columns2.mvc$view", ["OutSystems", "MobilePatterns.model", "MobilePatterns.controller", "react", "OutSystemsReactView", "MobilePatterns.Adaptive.Columns2.mvc$model", "MobilePatterns.Adaptive.Columns2.mvc$controller", "OutSystemsReactWidgets"], function (OutSystems, MobilePatternsModel, MobilePatternsController, React, OSView, MobilePatterns_Adaptive_Columns2_mvc_model, MobilePatterns_Adaptive_Columns2_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Adaptive.Columns2";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return MobilePatterns_Adaptive_Columns2_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return MobilePatterns_Adaptive_Columns2_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("k0XTOAX0Dkqp+APevhNhvw.Style"), function () {
return ((((((((("columns cols2" + ((model.variables.useGutterIn) ? (" gutter") : (""))) + " phone-portrait-") + model.variables.phonePortraitBreakIn) + " phone-landscape-") + model.variables.phoneLandscapeBreakIn) + " tablet-portrait-") + model.variables.tabletPortraitBreakIn) + " tablet-landscape-") + model.variables.tabletLandscapeBreakIn);
}, function () {
return model.variables.useGutterIn;
}, function () {
return model.variables.phonePortraitBreakIn;
}, function () {
return model.variables.phoneLandscapeBreakIn;
}, function () {
return model.variables.tabletPortraitBreakIn;
}, function () {
return model.variables.tabletLandscapeBreakIn;
}),
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._useGutterInDataFetchStatus, model.variables._phonePortraitBreakInDataFetchStatus, model.variables._phoneLandscapeBreakInDataFetchStatus, model.variables._tabletPortraitBreakInDataFetchStatus, model.variables._tabletLandscapeBreakInDataFetchStatus)
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.column1,
gridProperties: {
classes: "OSInline"
},
style: "col",
_idProps: {
service: idService,
name: "Column1"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.column2,
gridProperties: {
classes: "OSInline"
},
style: "col",
_idProps: {
service: idService,
name: "Column2"
},
_widgetRecordProvider: widgetsRecordProvider
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("MobilePatterns.Adaptive.Columns2.mvc$controller", ["OutSystems", "MobilePatterns.model", "MobilePatterns.controller", "MobilePatterns.languageResources", "MobilePatterns.Adaptive.Columns2.mvc$debugger"], function (OutSystems, MobilePatternsModel, MobilePatternsController, MobilePatternsLanguageResources, MobilePatterns_Adaptive_Columns2_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:9GgB6wiQjkOC68Dd0FW6zQ:/NRWebFlows.9GgB6wiQjkOC68Dd0FW6zQ:ix_8C8jBh6+cgr+hnelMqw", "MobilePatterns", "Adaptive", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:gxYYuEdl1E21fGXi3GgGxw:/NRWebFlows.9GgB6wiQjkOC68Dd0FW6zQ/NodesShownInESpaceTree.gxYYuEdl1E21fGXi3GgGxw:b4vNP_JH0pdkWMLNqR_oSA", "MobilePatterns", "Columns2", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:gxYYuEdl1E21fGXi3GgGxw", callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:9GgB6wiQjkOC68Dd0FW6zQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return MobilePatternsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, MobilePatternsLanguageResources);
});

define("MobilePatterns.Adaptive.Columns2.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"d2rz_Y3VjEKXDDX5eOBOkA": {
getter: function (varBag, idService) {
return varBag.model.variables.useGutterIn;
},
dataType: OS.Types.Boolean
},
"u4lMv3JhokiRX3M3J_RA2A": {
getter: function (varBag, idService) {
return varBag.model.variables.phonePortraitBreakIn;
},
dataType: OS.Types.Text
},
"lhYDeMZIbUmoioUrCJEWLA": {
getter: function (varBag, idService) {
return varBag.model.variables.phoneLandscapeBreakIn;
},
dataType: OS.Types.Text
},
"oZIPkNT8ZkaVUGXbSHaY1A": {
getter: function (varBag, idService) {
return varBag.model.variables.tabletPortraitBreakIn;
},
dataType: OS.Types.Text
},
"n3rsHKxuJUW39TXFkBtNrw": {
getter: function (varBag, idService) {
return varBag.model.variables.tabletLandscapeBreakIn;
},
dataType: OS.Types.Text
},
"_IxXnXE14kq0VrndEkilcA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"ldl9H0_NYkGUtMFk4PWNAQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
