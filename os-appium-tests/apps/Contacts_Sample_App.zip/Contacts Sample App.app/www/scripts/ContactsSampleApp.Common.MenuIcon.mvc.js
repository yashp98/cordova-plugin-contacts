﻿define("ContactsSampleApp.Common.MenuIcon.mvc$model", ["OutSystems", "ContactsSampleApp.model", "MobilePatterns.controller", "MobilePatterns.controller$MenuShow", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$MobilePatterns", "MobilePatterns.controller$SetMenuIcon"], function (OutSystems, ContactsSampleAppModel, MobilePatternsController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("MenuAction", "menuActionIn", "MenuAction", true, OS.Types.Text, function () {
return ContactsSampleAppModel.staticEntities.menuAction.auto;
}), 
this.attr("_menuActionInDataFetchStatus", "_menuActionInDataFetchStatus", "_menuActionInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
})
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("MenuAction" in inputs) {
this.variables.menuActionIn = inputs.MenuAction;
if("_menuActionInDataFetchStatus" in inputs) {
this.variables._menuActionInDataFetchStatus = inputs._menuActionInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.Common.MenuIcon.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "MobilePatterns.controller", "react", "OutSystemsReactView", "ContactsSampleApp.Common.MenuIcon.mvc$model", "ContactsSampleApp.Common.MenuIcon.mvc$controller", "OutSystemsReactWidgets", "MobilePatterns.controller$MenuShow", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$MobilePatterns", "MobilePatterns.controller$SetMenuIcon"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, MobilePatternsController, React, OSView, ContactsSampleApp_Common_MenuIcon_mvc_model, ContactsSampleApp_Common_MenuIcon_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.MenuIcon";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_Common_MenuIcon_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_Common_MenuIcon_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
marginTop: "0px"
},
style: model.getCachedValue(idService.getId("MenuIcon.Style"), function () {
return ("app-menu-icon" + ((((model.variables.menuActionIn) !== (ContactsSampleAppModel.staticEntities.menuAction.back))) ? ("") : (" back")));
}, function () {
return model.variables.menuActionIn;
}),
visible: ((model.variables.menuActionIn) !== (ContactsSampleAppModel.staticEntities.menuAction.hidden)),
_idProps: {
service: idService,
name: "MenuIcon"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._menuActionInDataFetchStatus),
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._menuActionInDataFetchStatus)
}, React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/MenuIcon/Menu OnClick");
controller.showMenu$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "app-menu-burger",
visible: true,
_idProps: {
service: idService,
name: "Menu"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "app-menu-line",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
style: "app-menu-line",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
style: "app-menu-line",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
OS.Navigation.navigateBack(null);
},
style: "app-menu-back",
visible: true,
_idProps: {
service: idService,
name: "Back"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "angle-left",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
name: "ArrowBack"
},
_widgetRecordProvider: widgetsRecordProvider
}))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ContactsSampleApp.Common.MenuIcon.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "MobilePatterns.controller", "ContactsSampleApp.languageResources", "ContactsSampleApp.Common.MenuIcon.mvc$debugger", "MobilePatterns.controller$MenuShow", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$MobilePatterns", "MobilePatterns.controller$SetMenuIcon"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, MobilePatternsController, ContactsSampleAppLanguageResources, ContactsSampleApp_Common_MenuIcon_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._showMenu$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ShowMenu");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:sagETpEDB0+zEVdbDriy7Q:/NRWebFlows.c+zxB7GelUiC17aCJSfX3w/NodesShownInESpaceTree.QZsSj5n5VkGR9h_QDaQawg/ClientActions.sagETpEDB0+zEVdbDriy7Q:JO88tbkPWTDMt+iA+r+Jxw", "ContactsSampleApp", "ShowMenu", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:4Hqe_2Rr3kOgnqRHsT1jEQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:M3yVQjyydkyF1mr+3RgJpg", callContext.id);
// Execute Action: MenuShow
MobilePatternsController.default.menuShow$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:IMy2j1ldNU2xyFYrPYCu5Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:sagETpEDB0+zEVdbDriy7Q", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:MzjAcBNI90aUsAb8T89CNg:/NRWebFlows.c+zxB7GelUiC17aCJSfX3w/NodesShownInESpaceTree.QZsSj5n5VkGR9h_QDaQawg/ClientActions.MzjAcBNI90aUsAb8T89CNg:eMyp4RUXr9N66NEr2y1JMA", "ContactsSampleApp", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:YU_j+pevFEmMHcVeFgdUqw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:EA+B_62xPUyTVWTG5pixkA", callContext.id);
// Execute Action: SetMenuIcon
MobilePatternsController.default.setMenuIcon$Action(model.variables.menuActionIn, callContext);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:RY9rthBPoE6QhYHKwkkJmQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:MzjAcBNI90aUsAb8T89CNg", callContext.id);
}

};

Controller.prototype.showMenu$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._showMenu$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:c+zxB7GelUiC17aCJSfX3w:/NRWebFlows.c+zxB7GelUiC17aCJSfX3w:BF2CaJhGp5XpiB3Yr4_mGg", "ContactsSampleApp", "Common", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:QZsSj5n5VkGR9h_QDaQawg:/NRWebFlows.c+zxB7GelUiC17aCJSfX3w/NodesShownInESpaceTree.QZsSj5n5VkGR9h_QDaQawg:gIKaXtUKcMnMTOFnKkuDhw", "ContactsSampleApp", "MenuIcon", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:QZsSj5n5VkGR9h_QDaQawg", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:c+zxB7GelUiC17aCJSfX3w", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common/MenuIcon On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.Common.MenuIcon.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"OXR2CB9E_UCCL6iIpDS4fA": {
getter: function (varBag, idService) {
return varBag.model.variables.menuActionIn;
},
dataType: OS.Types.Text
},
"hj3iBDFJpEW8fe+dEEisIQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MenuIcon"));
})(varBag.model, idService);
}
},
"S_FlFTmp0U6kuFXR0HmdYg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Menu"));
})(varBag.model, idService);
}
},
"VBajbBTcfE2eKITqugmRNQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Back"));
})(varBag.model, idService);
}
},
"jzbdd7LeTU2hsp0zwS7hMg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ArrowBack"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
