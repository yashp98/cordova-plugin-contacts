﻿define("MobilePatterns.Private.ApplicationLoadEvents.mvc$model", ["OutSystems", "MobilePatterns.model"], function (OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("MinimumDisplayTimeMs", "minimumDisplayTimeMsIn", "MinimumDisplayTimeMs", true, OS.Types.Integer, function () {
return 1000;
}), 
this.attr("_minimumDisplayTimeMsInDataFetchStatus", "_minimumDisplayTimeMsInDataFetchStatus", "_minimumDisplayTimeMsInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
})
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("MinimumDisplayTimeMs" in inputs) {
this.variables.minimumDisplayTimeMsIn = inputs.MinimumDisplayTimeMs;
if("_minimumDisplayTimeMsInDataFetchStatus" in inputs) {
this.variables._minimumDisplayTimeMsInDataFetchStatus = inputs._minimumDisplayTimeMsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("MobilePatterns.Private.ApplicationLoadEvents.mvc$view", ["OutSystems", "MobilePatterns.model", "MobilePatterns.controller", "react", "OutSystemsReactView", "MobilePatterns.Private.ApplicationLoadEvents.mvc$model", "MobilePatterns.Private.ApplicationLoadEvents.mvc$controller"], function (OutSystems, MobilePatternsModel, MobilePatternsController, React, OSView, MobilePatterns_Private_ApplicationLoadEvents_mvc_model, MobilePatterns_Private_ApplicationLoadEvents_mvc_controller) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Private.ApplicationLoadEvents";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return MobilePatterns_Private_ApplicationLoadEvents_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return MobilePatterns_Private_ApplicationLoadEvents_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties());
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("MobilePatterns.Private.ApplicationLoadEvents.mvc$controller", ["OutSystems", "MobilePatterns.model", "MobilePatterns.controller", "MobilePatterns.languageResources", "MobilePatterns.Private.ApplicationLoadEvents.mvc$controller.OnInitialize.RegisterListenersJS", "MobilePatterns.Private.ApplicationLoadEvents.mvc$debugger"], function (OutSystems, MobilePatternsModel, MobilePatternsController, MobilePatternsLanguageResources, MobilePatterns_Private_ApplicationLoadEvents_mvc_controller_OnInitialize_RegisterListenersJS, MobilePatterns_Private_ApplicationLoadEvents_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
triggerOnUpgradeProgress$Action: function (completedIn, totalIn) {
completedIn = (completedIn === undefined) ? 0 : completedIn;
totalIn = (totalIn === undefined) ? 0 : totalIn;
return controller.executeActionInsideJSNode(controller._triggerOnUpgradeProgress$Action.bind(controller, OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(completedIn, OS.Types.Integer), OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(totalIn, OS.Types.Integer)), controller.callContext(), function (actionResults) {
return {};
});
},
triggerOnLoadComplete$Action: function (redirectURLIn) {
redirectURLIn = (redirectURLIn === undefined) ? "" : redirectURLIn;
return controller.executeActionInsideJSNode(controller._triggerOnLoadComplete$Action.bind(controller, OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(redirectURLIn, OS.Types.Text)), controller.callContext(), function (actionResults) {
return {};
});
}
};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._triggerOnUpgradeProgress$Action = function (completedIn, totalIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TriggerOnUpgradeProgress");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MobilePatterns.Private.ApplicationLoadEvents.TriggerOnUpgradeProgress$vars"))());
vars.value.completedInLocal = completedIn;
vars.value.totalInLocal = totalIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:RqMqHwpiAke_+FcFSnn0fg:/NRWebFlows.IUOdI7QmkEyzLmZAA68__Q/NodesShownInESpaceTree.jkMO6fNONk68dfPLs8KxXg/ClientActions.RqMqHwpiAke_+FcFSnn0fg:zSBq_nGw84Np+dyoifQ+1w", "MobilePatterns", "TriggerOnUpgradeProgress", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dqYgtPLrvUG_uinULDTEDQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:7lJa2zMxqk6tDUHAhjtcIg", callContext.id);
// Trigger Event: OnUpgradeProgress
return controller.onUpgradeProgress$Action(vars.value.completedInLocal, vars.value.totalInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ECF6JbpUu0KfWmvsu2YhIQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:RqMqHwpiAke_+FcFSnn0fg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:RqMqHwpiAke_+FcFSnn0fg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("MobilePatterns.Private.ApplicationLoadEvents.TriggerOnUpgradeProgress$vars", [{
name: "Completed",
attrName: "completedInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Total",
attrName: "totalInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._triggerOnLoadComplete$Action = function (redirectURLIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TriggerOnLoadComplete");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MobilePatterns.Private.ApplicationLoadEvents.TriggerOnLoadComplete$vars"))());
vars.value.redirectURLInLocal = redirectURLIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:+Skia0zMp0OdhlLXzyENOA:/NRWebFlows.IUOdI7QmkEyzLmZAA68__Q/NodesShownInESpaceTree.jkMO6fNONk68dfPLs8KxXg/ClientActions.+Skia0zMp0OdhlLXzyENOA:+yLrbRuipEC9wzfC1EFAIg", "MobilePatterns", "TriggerOnLoadComplete", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:lVdLXzveHEi6fq0v1_kRfQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:zaCq6hHgA0+zTve2EVUlDA", callContext.id);
// Trigger Event: OnLoadComplete
return controller.onLoadComplete$Action(vars.value.redirectURLInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YSNMvtmZkU2xMT_Kcj+jSg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:+Skia0zMp0OdhlLXzyENOA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:+Skia0zMp0OdhlLXzyENOA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("MobilePatterns.Private.ApplicationLoadEvents.TriggerOnLoadComplete$vars", [{
name: "RedirectURL",
attrName: "redirectURLInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:F8tpsFSD_UKGnUVr9ud4bA:/NRWebFlows.IUOdI7QmkEyzLmZAA68__Q/NodesShownInESpaceTree.jkMO6fNONk68dfPLs8KxXg/ClientActions.F8tpsFSD_UKGnUVr9ud4bA:Oj0bPosupHfHS1EyRWe31A", "MobilePatterns", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dTId22GxXkqJF26JapieWw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:iW7rR+64JU29M2auV6jnZQ", callContext.id);
controller.safeExecuteJSNode(MobilePatterns_Private_ApplicationLoadEvents_mvc_controller_OnInitialize_RegisterListenersJS, "RegisterListeners", "OnInitialize", {
MinDisplayTimeMs: OS.DataTypes.JSConversions.basicTypeToJS(model.variables.minimumDisplayTimeMsIn, OS.Types.Integer, true)
}, function ($parameters) {
}, {
TriggerOnUpgradeProgress: controller.clientActionProxies.triggerOnUpgradeProgress$Action,
TriggerOnLoadComplete: controller.clientActionProxies.triggerOnLoadComplete$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:QPSDH0Y5rkaQvGw8vhmeAw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:F8tpsFSD_UKGnUVr9ud4bA", callContext.id);
}

};

Controller.prototype.triggerOnUpgradeProgress$Action = function (completedIn, totalIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._triggerOnUpgradeProgress$Action, callContext, completedIn, totalIn);

};
Controller.prototype.triggerOnLoadComplete$Action = function (redirectURLIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._triggerOnLoadComplete$Action, callContext, redirectURLIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onUpgradeProgress$Action = function () {
return Promise.resolve();
};
Controller.prototype.onLoadComplete$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:IUOdI7QmkEyzLmZAA68__Q:/NRWebFlows.IUOdI7QmkEyzLmZAA68__Q:eMT1lrO7AeXx+QKZ+OQryQ", "MobilePatterns", "Private", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:jkMO6fNONk68dfPLs8KxXg:/NRWebFlows.IUOdI7QmkEyzLmZAA68__Q/NodesShownInESpaceTree.jkMO6fNONk68dfPLs8KxXg:saW3fHPvlQsBWnjNLkEYmw", "MobilePatterns", "ApplicationLoadEvents", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:jkMO6fNONk68dfPLs8KxXg", callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:IUOdI7QmkEyzLmZAA68__Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/ApplicationLoadEvents On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return MobilePatternsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, MobilePatternsLanguageResources);
});
define("MobilePatterns.Private.ApplicationLoadEvents.mvc$controller.OnInitialize.RegisterListenersJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
    var start = new Date();
    // Check if the app is currently being upgraded
    var isUpgrading = $public.ApplicationLifecycle.isUpgradingVersion();
    
    var progressCallback = function(loaded, total) { 
        $actions.TriggerOnUpgradeProgress(loaded, total); 
    };
    
    var finishCallback = function() {
        var elapsedMs = new Date() - start;
        var timeout = Math.max($parameters.MinDisplayTimeMs - elapsedMs, 0);
        setTimeout(function() {
            $actions.TriggerOnLoadComplete(window.location.href);    
        }, timeout);
    };
    
    // When there is no upgrade, we need to mimic the progress using the MinDisplayTimeMs
    if (!isUpgrading) {
        var loaded = 0;
        var interval = Math.ceil($parameters.MinDisplayTimeMs / 10);
        var timerId = setInterval(function() {
            progressCallback(++loaded, 10);
            if (loaded === 10) {
                clearInterval(timerId);
            }
        }, interval);
    }
    $public.ApplicationLifecycle.listen({
        // When there is no upgrade, we'll provide the feedback
        onUpgradeProgress: isUpgrading ? progressCallback : null,
        onLoadComplete: finishCallback
    });
};
});

define("MobilePatterns.Private.ApplicationLoadEvents.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"y_QGn_nTNkKk5ifahW1jPA": {
getter: function (varBag, idService) {
return varBag.vars.value.completedInLocal;
},
dataType: OS.Types.Integer
},
"vBDB5qcszk+1Sp+OHgtCiw": {
getter: function (varBag, idService) {
return varBag.vars.value.totalInLocal;
},
dataType: OS.Types.Integer
},
"I+VKpnJej0iaD6F8iscSXA": {
getter: function (varBag, idService) {
return varBag.vars.value.redirectURLInLocal;
},
dataType: OS.Types.Text
},
"iW7rR+64JU29M2auV6jnZQ": {
getter: function (varBag, idService) {
return varBag.registerListenersJSResult.value;
}
},
"024sl3u8qUejQwcB4vBCtQ": {
getter: function (varBag, idService) {
return varBag.model.variables.minimumDisplayTimeMsIn;
},
dataType: OS.Types.Integer
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
