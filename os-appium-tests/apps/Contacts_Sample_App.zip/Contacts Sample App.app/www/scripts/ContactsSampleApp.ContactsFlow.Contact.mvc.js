﻿define("ContactsSampleApp.ContactsFlow.Contact.mvc$model", ["OutSystems", "ContactsSampleApp.model", "CommonPlugin.model", "ContactsSampleApp.controller", "ContactsPlugin.model", "ContactsSampleApp.Common.Layout.mvc$model", "ContactsSampleApp.Common.MenuIcon.mvc$model", "MobilePatterns.Content.Section.mvc$model", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$model", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsSampleApp.controller$FileSystem_GetPhoto", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (OutSystems, ContactsSampleAppModel, CommonPluginModel, ContactsSampleAppController, ContactsPluginModel, ContactsSampleApp_Common_Layout_mvcModel, ContactsSampleApp_Common_MenuIcon_mvcModel, MobilePatterns_Content_Section_mvcModel, ContactsSampleApp_ContactsFlow_BottomBar_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Contact", "contactVar", "Contact", true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactRec());
}, ContactsPluginModel.ContactRec), 
this.attr("ContactPhoto", "contactPhotoVar", "ContactPhoto", true, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}), 
this.attr("ContactSerialized", "contactSerializedIn", "ContactSerialized", true, OS.Types.Text, function () {
return "";
}), 
this.attr("_contactSerializedInDataFetchStatus", "_contactSerializedInDataFetchStatus", "_contactSerializedInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
})
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((ContactsSampleApp_Common_Layout_mvcModel.hasValidationWidgets || ContactsSampleApp_Common_MenuIcon_mvcModel.hasValidationWidgets) || MobilePatterns_Content_Section_mvcModel.hasValidationWidgets) || ContactsSampleApp_ContactsFlow_BottomBar_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("ContactSerialized" in inputs) {
this.variables.contactSerializedIn = OS.DataTypes.JSConversions.jsToBasicType(inputs.ContactSerialized, OS.Types.Text);
}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.ContactsFlow.Contact.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.model", "react", "OutSystemsReactView", "ContactsSampleApp.ContactsFlow.Contact.mvc$model", "ContactsSampleApp.ContactsFlow.Contact.mvc$controller", "ContactsSampleApp.Common.Layout.mvc$view", "OutSystemsReactWidgets", "ContactsSampleApp.Common.MenuIcon.mvc$view", "MobilePatterns.Content.Section.mvc$view", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$view", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsSampleApp.controller$FileSystem_GetPhoto", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginModel, React, OSView, ContactsSampleApp_ContactsFlow_Contact_mvc_model, ContactsSampleApp_ContactsFlow_Contact_mvc_controller, ContactsSampleApp_Common_Layout_mvc_view, OSWidgets, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Content_Section_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ContactsFlow.Contact";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MobilePatterns.BaseTheme.css", "css/MobilePatterns.TabletTheme.css", "css/ContactsSampleApp.ContactsSampleApp.css", "css/MobilePatterns.TabletTheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ContactsSampleApp_Common_Layout_mvc_view, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Content_Section_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Contact_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Contact_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(ContactsSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: new PlaceholderContent(function () {
return ["Contact details", React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Contacts plugin")];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Helper", {}),
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "QNYP96+LKUyQ1zNWysd7MQ"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "info-circle",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "RZ76eJLKIE+ThYGKEdepZQ"
},
text: [" "],
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "pcmvqB_c_0+cHQ9uSQ_qxA"
},
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(true, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Center*/ 2,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Image, {
extendedProperties: {
"data-style-key": "gTnpRQqyGEiXoeFd8hR4AA"
},
gridProperties: {
classes: "OSFillParent"
},
imageContent: model.variables.contactPhotoVar,
type: /*Binary*/ 2,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Basic Info"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Id"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.idAttr,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Display Name"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.displayNameAttr,
_idProps: {
service: idService,
name: "displayName"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Formatted"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.nameAttr.formattedAttr,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Family Name"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.nameAttr.familyNameAttr,
_idProps: {
service: idService,
name: "lastName"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Given Name"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.nameAttr.givenNameAttr,
_idProps: {
service: idService,
name: "firstname"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Middle Name"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.nameAttr.middleNameAttr,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Honorific Prefix"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.nameAttr.honorificPrefixAttr,
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Honorific Suffix"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.nameAttr.honorificSuffixAttr,
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Nickname"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.nicknameAttr,
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Birthday"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.getCachedValue(idService.getId("birthday.Value"), function () {
return OS.BuiltinFunctions.formatDateTime(model.variables.contactVar.birthdayAttr, "d MMM yyyy HH:mm");
}, function () {
return model.variables.contactVar.birthdayAttr;
}),
_idProps: {
service: idService,
name: "birthday"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "42"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Note"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.noteAttr,
_idProps: {
service: idService,
name: "note"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.noteAttr), asPrimitiveValue(model.variables.contactVar.birthdayAttr), asPrimitiveValue(model.variables.contactVar.nicknameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.honorificSuffixAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.honorificPrefixAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.middleNameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.givenNameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.familyNameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.formattedAttr), asPrimitiveValue(model.variables.contactVar.displayNameAttr), asPrimitiveValue(model.variables.contactVar.idAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "44",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Phone Numbers"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "9DUA7zp0ZUW1mtjRlIaq0w"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactVar.phoneNumbersAttr,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.phoneNumbersAttr.getCurrent(callContext.iterationContext).prefAttr), asPrimitiveValue(model.variables.contactVar.phoneNumbersAttr.getCurrent(callContext.iterationContext).valueAttr), asPrimitiveValue(model.variables.contactVar.phoneNumbersAttr.getCurrent(callContext.iterationContext).typeAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.phoneNumbersAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Value"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.phoneNumbersAttr.getCurrent(callContext.iterationContext).valueAttr,
_idProps: {
service: idService,
name: "phoneNumber"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "53"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.phoneNumbersAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "1")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.phoneNumbersAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "EmailSection",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Emails"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "n2HHYqvLA0+pP1shJeT5xw"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactVar.emailsAttr,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "57"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "58"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.emailsAttr.getCurrent(callContext.iterationContext).prefAttr), asPrimitiveValue(model.variables.contactVar.emailsAttr.getCurrent(callContext.iterationContext).valueAttr), asPrimitiveValue(model.variables.contactVar.emailsAttr.getCurrent(callContext.iterationContext).typeAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "59"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "60"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.emailsAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "62"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "63"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Value"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.emailsAttr.getCurrent(callContext.iterationContext).valueAttr,
_idProps: {
service: idService,
name: "Email"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "65"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "66"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.emailsAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "2")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.emailsAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "68",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Addresses"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "ovo_wCHCuECXYBAM6AaY3w"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactVar.addressesAttr,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "69"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "70"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).countryAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).postalCodeAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).regionAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).localityAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).streetAddressAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).formattedAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).typeAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).prefAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "71"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "72"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "73"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "74"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "75"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "76"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "77"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "78"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Formatted"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).formattedAttr,
_idProps: {
service: idService,
uuid: "79"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "80"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "81"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Street Address"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).streetAddressAttr,
_idProps: {
service: idService,
name: "address"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "83"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "84"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Locality"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).localityAttr,
_idProps: {
service: idService,
uuid: "85"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "86"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "87"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Region"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).regionAttr,
_idProps: {
service: idService,
uuid: "88"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "89"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "90"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Postal Code"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).postalCodeAttr,
_idProps: {
service: idService,
uuid: "91"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "92"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "93"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Country"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.addressesAttr.getCurrent(callContext.iterationContext).countryAttr,
_idProps: {
service: idService,
uuid: "94"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "3")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.addressesAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "95",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["IMs"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "spFwaeponkqDltlK+Z7ACg"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactVar.iMsAttr,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "96"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "97"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.iMsAttr.getCurrent(callContext.iterationContext).prefAttr), asPrimitiveValue(model.variables.contactVar.iMsAttr.getCurrent(callContext.iterationContext).valueAttr), asPrimitiveValue(model.variables.contactVar.iMsAttr.getCurrent(callContext.iterationContext).typeAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "98"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "99"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.iMsAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "100"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "101"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "102"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Value"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.iMsAttr.getCurrent(callContext.iterationContext).valueAttr,
_idProps: {
service: idService,
uuid: "103"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "104"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "105"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.iMsAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "106"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "4")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.iMsAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "107",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Organizations"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "Mzi+VrP1H0OWBpO9UmgAiw"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactVar.organizationsAttr,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "108"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "109"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).titleAttr), asPrimitiveValue(model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).departmentAttr), asPrimitiveValue(model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).nameAttr), asPrimitiveValue(model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).typeAttr), asPrimitiveValue(model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).prefAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "110"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "111"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "112"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "113"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "114"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "115"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "116"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "117"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Name"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
name: "companyName"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "119"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "120"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Department"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).departmentAttr,
_idProps: {
service: idService,
name: "companyDepartment"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "122"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "123"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Title"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.organizationsAttr.getCurrent(callContext.iterationContext).titleAttr,
_idProps: {
service: idService,
name: "jobTitle"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "5")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.organizationsAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "125",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Photos"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "ggLBMcouN0uezSy71w67sg"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Custom*/ 1,
source: model.variables.contactVar.photosAttr,
style: "list list-group",
tag: "span",
_idProps: {
service: idService,
uuid: "126"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "127"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.photosAttr.getCurrent(callContext.iterationContext).prefAttr), asPrimitiveValue(model.variables.contactVar.photosAttr.getCurrent(callContext.iterationContext).valueAttr), asPrimitiveValue(model.variables.contactVar.photosAttr.getCurrent(callContext.iterationContext).typeAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "128"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "129"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.photosAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "130"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "131"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "132"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Value"), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-style-key": "cEWXTM6epEusmI+m7MtpoQ"
},
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.photosAttr.getCurrent(callContext.iterationContext).valueAttr,
_idProps: {
service: idService,
uuid: "133"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "134"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "135"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.photosAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "136"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "6")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.photosAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "137",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Categories"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "KiXkja7DhEyHD7_Z1MdLvg"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactVar.categoriesAttr,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "138"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "139"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.categoriesAttr.getCurrent(callContext.iterationContext).prefAttr), asPrimitiveValue(model.variables.contactVar.categoriesAttr.getCurrent(callContext.iterationContext).valueAttr), asPrimitiveValue(model.variables.contactVar.categoriesAttr.getCurrent(callContext.iterationContext).typeAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "140"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "141"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.categoriesAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "142"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "143"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "144"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Value"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.categoriesAttr.getCurrent(callContext.iterationContext).valueAttr,
_idProps: {
service: idService,
uuid: "145"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "146"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "147"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.categoriesAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "148"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "7")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.categoriesAttr)]
}), React.createElement(MobilePatterns_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "149",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Urls"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "MyMgwyQv8UypOu3ZjocDgw"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactVar.urlsAttr,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "150"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "151"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.contactVar.urlsAttr.getCurrent(callContext.iterationContext).prefAttr), asPrimitiveValue(model.variables.contactVar.urlsAttr.getCurrent(callContext.iterationContext).valueAttr), asPrimitiveValue(model.variables.contactVar.urlsAttr.getCurrent(callContext.iterationContext).typeAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "152"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "153"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Type"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.urlsAttr.getCurrent(callContext.iterationContext).typeAttr,
_idProps: {
service: idService,
uuid: "154"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "155"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "156"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Value"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactVar.urlsAttr.getCurrent(callContext.iterationContext).valueAttr,
_idProps: {
service: idService,
uuid: "157"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "158"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
width: "120px"
},
_idProps: {
service: idService,
uuid: "159"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pref"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "check",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: model.variables.contactVar.urlsAttr.getCurrent(callContext.iterationContext).prefAttr,
_idProps: {
service: idService,
uuid: "160"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "8")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.urlsAttr)]
}))];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_ContactsFlow_BottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "161",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactVar.urlsAttr), asPrimitiveValue(model.variables.contactVar.categoriesAttr), asPrimitiveValue(model.variables.contactVar.photosAttr), asPrimitiveValue(model.variables.contactVar.organizationsAttr), asPrimitiveValue(model.variables.contactVar.iMsAttr), asPrimitiveValue(model.variables.contactVar.addressesAttr), asPrimitiveValue(model.variables.contactVar.emailsAttr), asPrimitiveValue(model.variables.contactVar.phoneNumbersAttr), asPrimitiveValue(model.variables.contactVar.noteAttr), asPrimitiveValue(model.variables.contactVar.birthdayAttr), asPrimitiveValue(model.variables.contactVar.nicknameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.honorificSuffixAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.honorificPrefixAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.middleNameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.givenNameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.familyNameAttr), asPrimitiveValue(model.variables.contactVar.nameAttr.formattedAttr), asPrimitiveValue(model.variables.contactVar.displayNameAttr), asPrimitiveValue(model.variables.contactVar.idAttr), asPrimitiveValue(model.variables.contactPhotoVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ContactsSampleApp.ContactsFlow.Contact.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.model", "ContactsSampleApp.languageResources", "ContactsSampleApp.ContactsFlow.controller", "ContactsSampleApp.ContactsFlow.Contact.mvc$debugger", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsSampleApp.controller$FileSystem_GetPhoto", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginModel, ContactsSampleAppLanguageResources, ContactsSampleApp_ContactsFlowController, ContactsSampleApp_ContactsFlow_Contact_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var fileSystem_GetPhotoVar = new OS.DataTypes.VariableHolder();
var jSONDeserializeContactVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ContactsPluginModel.ContactRec))());
varBag.callContext = callContext;
varBag.fileSystem_GetPhotoVar = fileSystem_GetPhotoVar;
varBag.jSONDeserializeContactVar = jSONDeserializeContactVar;
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:d3i4Pp3khEmyw0hxgoX1Dg:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.yKeYAax7BkG+1kynV4w1ZA/ClientActions.d3i4Pp3khEmyw0hxgoX1Dg:rEhXW5aQQLABgQY34vgG5Q", "ContactsSampleApp", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:21cn+uSim0yYQ6Glxxq4kg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:zVxrnemfM0Op0q4d2Bydkw", callContext.id);
// JSON Deserialize: JSONDeserializeContact
jSONDeserializeContactVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(model.variables.contactSerializedIn, ContactsPluginModel.ContactRec, false);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:xvTQBks8TUSNCFH9F7J7RQ", callContext.id);
// Contact = JSONDeserializeContact.Data
model.variables.contactVar = jSONDeserializeContactVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:pif5aLi050SSYhYuwMmTvQ", callContext.id);
// Execute Action: FileSystem_GetPhoto
model.flush();
return ContactsSampleAppController.default.fileSystem_GetPhoto$Action(model.variables.contactVar.photosAttr.getCurrent(callContext.iterationContext).valueAttr, callContext).then(function (value) {
fileSystem_GetPhotoVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:nlpf+kUCVUWfWDL+k4qyWw", callContext.id) && fileSystem_GetPhotoVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:UR32oCs2YEu7982eF4h9Mg", callContext.id);
// ContactPhoto = FileSystem_GetPhoto.ContactPhoto
model.variables.contactPhotoVar = fileSystem_GetPhotoVar.value.contactPhotoOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:YDxhlQ4El0iWPwFD02r5vA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:+hoQxoge5EyGvcJN1ESq7w", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(((("ErrorCode: " + fileSystem_GetPhotoVar.value.errorOut.errorCodeAttr) + ", ErrorMessage: ") + fileSystem_GetPhotoVar.value.errorOut.errorMessageAttr), /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:Sj0CQ4+EiEWOP8tLPfFUUw", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:d3i4Pp3khEmyw0hxgoX1Dg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:d3i4Pp3khEmyw0hxgoX1Dg", callContext.id);
throw ex;

});
};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q:oTswzJAtrUammmPpEwGYvg", "ContactsSampleApp", "ContactsFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:yKeYAax7BkG+1kynV4w1ZA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.yKeYAax7BkG+1kynV4w1ZA:OXO+NfigWrSdLjtJyy5_7w", "ContactsSampleApp", "Contact", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:yKeYAax7BkG+1kynV4w1ZA", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ContactsFlow/Contact On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ContactsSampleApp_ContactsFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.ContactsFlow.Contact.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"pif5aLi050SSYhYuwMmTvQ": {
getter: function (varBag, idService) {
return varBag.fileSystem_GetPhotoVar.value;
}
},
"zVxrnemfM0Op0q4d2Bydkw": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeContactVar.value;
}
},
"PjeJ4Xt1zE2sKA5ylBA6Qg": {
getter: function (varBag, idService) {
return varBag.model.variables.contactVar;
}
},
"mmCNnxuP80CTV8uKVvDMBg": {
getter: function (varBag, idService) {
return varBag.model.variables.contactPhotoVar;
},
dataType: OS.Types.BinaryData
},
"SRVmzIiq4UutEGBz3yX3eQ": {
getter: function (varBag, idService) {
return varBag.model.variables.contactSerializedIn;
},
dataType: OS.Types.Text
},
"XHPvkm+KcUaW1pz0o7Y7gA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"SDWNXwqXc0ySeE_V+yZP3Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"xwGUm03k30K+2Vpr_QoT8Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"q_dYegk2yk69h41R8QuBJg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderContent"));
})(varBag.model, idService);
}
},
"qoKj0Fl+ekyFVuNJskegEA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"vNy_76cEvEGwQwltBmmfjA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"12+oK7L2m0qI+LhsuaPQxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Gjm9s_wyxECJfr5Kh4isnQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("displayName"));
})(varBag.model, idService);
}
},
"BYwg4PfFskSgOP9btHG+bA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("lastName"));
})(varBag.model, idService);
}
},
"IoEEEHGIfEejHY2cbDlzgQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("firstname"));
})(varBag.model, idService);
}
},
"VykWFzp7zkmWa1zDU3K6VQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("birthday"));
})(varBag.model, idService);
}
},
"TV6OFrcFCkKv+sy4Waf+0Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("note"));
})(varBag.model, idService);
}
},
"TdeIhPoYG02ZzQlMl4vqyQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"u0fxK254PkGVqhUkR29m_g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"HgHcEicklkqObEKJODhPjA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("phoneNumber"));
})(varBag.model, idService);
}
},
"dJlUAQUFd0aJMAVfZYMDNg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("EmailSection"));
})(varBag.model, idService);
}
},
"LbP+8lz2wkCh5kuJa41f_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"KvDIXl39Pk2l9DZZOw3SAA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Z_eY3nB9ek+gN+Jzq+sehw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Email"));
})(varBag.model, idService);
}
},
"1L9N+ggqr0ia9z1hCVn97g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"OLnKGxAaEUKodK+l3K8aAQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"gK3Gwh9djEyQlSpDsN6hdA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("address"));
})(varBag.model, idService);
}
},
"xzsV0GNPn0eiYUrAufDdKw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"2vLR1S0WdU2OolBb8r4Upw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"GpmoAAmZMUWu+gSsWvxbuA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"BB8vTL9CzEq9lJrrUw5Gig": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ESt5bXS__k2WajNmHZCdfw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("companyName"));
})(varBag.model, idService);
}
},
"oZasaT7bb0mIvsamX6Qabw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("companyDepartment"));
})(varBag.model, idService);
}
},
"pPn31kGWP0yP33HG8kSHTw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("jobTitle"));
})(varBag.model, idService);
}
},
"LaMeo6VBOk+bGDlq_aTbbg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"Y+_bcqRFMEaxSSjZRhKGUw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"AD3E+CD3r0+e4SHt9Q7AJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"LlE3t9bXgUyISs2uTuGG6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"jVgLHC5sSUOpMkxpGSQ_wA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"IthvpHdwBUe5H1t6IKTI9Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"CDLqfbl5VUWDiahlH3dOSg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
