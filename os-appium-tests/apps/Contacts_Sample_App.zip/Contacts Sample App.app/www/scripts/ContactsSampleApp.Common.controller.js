﻿define("ContactsSampleApp.Common.controller", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "ContactsSampleApp.Common.controller$debugger"], function (exports, OutSystems, ContactsSampleAppModel, ContactsSampleAppController, ContactsSampleApp_Common_Controller_debugger) {
var OS = OutSystems.Internal;
var ContactsSampleApp_CommonController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var varBag = {};
var controller = this.controller;
var securityExceptionVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var communicationExceptionVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
varBag.securityExceptionVar = securityExceptionVar;
varBag.allExceptionsVar = allExceptionsVar;
varBag.communicationExceptionVar = communicationExceptionVar;
OS.Logger.trace("Common.OnException", OS.Exceptions.getMessage(ex), ex.name);
if(OS.ErrorHandling.ignoreError(ex, callContext)) {
return OS.ErrorHandling.IGNORED_ERROR_RESULT;
}

try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:c+zxB7GelUiC17aCJSfX3w.#FlowExceptionHandler:/NRWebFlows.c+zxB7GelUiC17aCJSfX3w/FlowExceptionHandler:o3nMi21nq_uEnG4aAqjTdg", "ContactsSampleApp", "OnException", "NRFlows.FlowExceptionHandlingFlow", callContext.id, varBag);
OS.Logger.trace("Common.OnException", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: SecurityException
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.SecurityException)) {
securityExceptionVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:xUJzPM0SVkaY8sKv7x2PuA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:iWzo1cX+aUSvKa5viMZJ_Q", callContext.id) && ((OS.BuiltinFunctions.getUserId()) !== (OS.BuiltinFunctions.nullIdentifier())))) {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:j_y+BBETVkqTzeNMiWV2Tw", callContext.id);
// Destination: /ContactsSampleApp/InvalidPermissions
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/ContactsSampleApp/InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:VBw2jEGGN0KTutUVK0fceQ", callContext.id);
// Destination: /ContactsSampleApp/Login
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/ContactsSampleApp/Login", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

}

// Handle Error: CommunicationException
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.CommunicationException)) {
OS.Logger.error(null, ex);
communicationExceptionVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:6whVl4ofEEKXD1bMT1+qFw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:qppm+G1H2UaRy6k08MphHg", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(communicationExceptionVar.value.exceptionMessageAttr, /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:iIiJfq19JkeQsKKBNcP_cw", callContext.id);
return ;

}

// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:0uSlXMsh+U6hlXRvyolnlw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:7XGGNbNsPku3mrkz3vjJJw", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(allExceptionsVar.value.exceptionMessageAttr, /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:B8+01jNzLkWsH6O8yuUtNg", callContext.id);
return ;

}

throw ex;
} catch (unhandledEx) {
OS.Logger.trace("Common.OnException", OS.Exceptions.getMessage(ex), ex.name);
if(!(OS.ErrorHandling.ignoreError(unhandledEx, callContext))) {
OS.ErrorHandling.handleError(unhandledEx, callContext);
OutSystemsDebugger.handleException(unhandledEx, callContext.id);
return OS.ErrorHandling.UNHANDLED_ERROR_RESULT;

}

OutSystemsDebugger.handleException(unhandledEx, callContext.id);
return OS.ErrorHandling.IGNORED_ERROR_RESULT;

} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:c+zxB7GelUiC17aCJSfX3w.#FlowExceptionHandler", callContext.id);
}



};
return Controller;
})(OS.Controller.BaseController);
ContactsSampleApp_CommonController.default = new Controller();
});

define("ContactsSampleApp.Common.controller$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"xUJzPM0SVkaY8sKv7x2PuA": {
getter: function (varBag, idService) {
return varBag.securityExceptionVar.value;
}
},
"0uSlXMsh+U6hlXRvyolnlw": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"6whVl4ofEEKXD1bMT1+qFw": {
getter: function (varBag, idService) {
return varBag.communicationExceptionVar.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
