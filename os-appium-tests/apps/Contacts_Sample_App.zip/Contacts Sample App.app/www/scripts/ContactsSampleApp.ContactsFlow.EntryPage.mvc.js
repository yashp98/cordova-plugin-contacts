﻿define("ContactsSampleApp.ContactsFlow.EntryPage.mvc$model", ["OutSystems", "ContactsSampleApp.model", "CommonPlugin.model", "ContactsPlugin.controller", "CommonPlugin.controller", "ContactsSampleApp.Common.Layout.mvc$model", "ContactsSampleApp.Common.MenuIcon.mvc$model", "MobilePatterns.Utilities.MarginContainer.mvc$model", "MobilePatterns.Adaptive.Columns2.mvc$model", "MobilePatterns.Content.Card.mvc$model", "MobilePatterns.Content.BlankSlate.mvc$model", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$CheckContactsPlugin", "ContactsSampleApp.referencesHealth$ContactsPlugin", "CommonPlugin.controller$GetOperatingSystem"], function (OutSystems, ContactsSampleAppModel, CommonPluginModel, ContactsPluginController, CommonPluginController, ContactsSampleApp_Common_Layout_mvcModel, ContactsSampleApp_Common_MenuIcon_mvcModel, MobilePatterns_Utilities_MarginContainer_mvcModel, MobilePatterns_Adaptive_Columns2_mvcModel, MobilePatterns_Content_Card_mvcModel, MobilePatterns_Content_BlankSlate_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsCorrectOS", "isCorrectOSVar", "IsCorrectOS", true, OS.Types.Boolean, function () {
return false;
}), 
this.attr("IsPluginLoaded", "isPluginLoadedVar", "IsPluginLoaded", true, OS.Types.Boolean, function () {
return false;
}), 
this.attr("OperatingSystemsId", "operatingSystemsIdVar", "OperatingSystemsId", true, OS.Types.Text, function () {
return "";
}), 
this.attr("Error", "errorVar", "Error", true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.ErrorRec());
}, CommonPluginModel.ErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((((ContactsSampleApp_Common_Layout_mvcModel.hasValidationWidgets || ContactsSampleApp_Common_MenuIcon_mvcModel.hasValidationWidgets) || MobilePatterns_Utilities_MarginContainer_mvcModel.hasValidationWidgets) || MobilePatterns_Adaptive_Columns2_mvcModel.hasValidationWidgets) || MobilePatterns_Content_Card_mvcModel.hasValidationWidgets) || MobilePatterns_Content_BlankSlate_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.ContactsFlow.EntryPage.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.controller", "CommonPlugin.controller", "react", "OutSystemsReactView", "ContactsSampleApp.ContactsFlow.EntryPage.mvc$model", "ContactsSampleApp.ContactsFlow.EntryPage.mvc$controller", "ContactsSampleApp.Common.Layout.mvc$view", "OutSystemsReactWidgets", "ContactsSampleApp.Common.MenuIcon.mvc$view", "MobilePatterns.Utilities.MarginContainer.mvc$view", "MobilePatterns.Adaptive.Columns2.mvc$view", "MobilePatterns.Content.Card.mvc$view", "MobilePatterns.Content.BlankSlate.mvc$view", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$CheckContactsPlugin", "ContactsSampleApp.referencesHealth$ContactsPlugin", "CommonPlugin.controller$GetOperatingSystem"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginController, CommonPluginController, React, OSView, ContactsSampleApp_ContactsFlow_EntryPage_mvc_model, ContactsSampleApp_ContactsFlow_EntryPage_mvc_controller, ContactsSampleApp_Common_Layout_mvc_view, OSWidgets, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, MobilePatterns_Adaptive_Columns2_mvc_view, MobilePatterns_Content_Card_mvc_view, MobilePatterns_Content_BlankSlate_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ContactsFlow.EntryPage";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MobilePatterns.BaseTheme.css", "css/MobilePatterns.TabletTheme.css", "css/ContactsSampleApp.ContactsSampleApp.css", "css/MobilePatterns.TabletTheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ContactsSampleApp_Common_Layout_mvc_view, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, MobilePatterns_Adaptive_Columns2_mvc_view, MobilePatterns_Content_Card_mvc_view, MobilePatterns_Content_BlankSlate_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_EntryPage_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_EntryPage_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(ContactsSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Text, {
text: ["Contacts plugin"],
_idProps: {
service: idService,
name: "title"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Helper", {}),
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "iLWgKRbv8UeeQFQ0e3snPA"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "info-circle",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "FsymfKsFVEyxvEA4kFYPXw"
},
text: [" "],
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [$if(model.variables.isCorrectOSVar, false, this, function () {
return [$if(model.variables.isPluginLoadedVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-test-id": "Success-message"
},
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Adaptive_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Content_Card_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Add", {}),
visible: true,
_idProps: {
service: idService,
name: "addContactScreenLink"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Content_BlankSlate_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "addContactScreen",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "plus-circle",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return ["Add  Contact"];
}),
actions: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Content_Card_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Find", {}),
visible: true,
_idProps: {
service: idService,
name: "findContactScreenLink"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Content_BlankSlate_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "findContactScreen",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "search",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return ["Find Contact"];
}),
actions: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Adaptive_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "19",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Content_Card_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Pick", {}),
visible: true,
_idProps: {
service: idService,
name: "pickContactScreenLink"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Content_BlankSlate_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "pickContactScreen",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "user",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return ["Pick Contact"];
}),
actions: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}),
column2: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
}, function () {
return [React.createElement(MobilePatterns_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-test-id": "Failure-message"
},
style: "card card-content background-red text-white",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The plugin is not loaded.", React.DOM.br(), " ", "Error code: ", React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.errorVar.errorCodeAttr,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.DOM.br(), "Message: ", React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.errorVar.errorMessageAttr,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.errorVar.errorMessageAttr), asPrimitiveValue(model.variables.errorVar.errorCodeAttr)]
})];
})];
}, function () {
return [React.createElement(MobilePatterns_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-test-id": "Failure-message"
},
style: "card card-content background-red text-white",
visible: true,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The operating systems that you are using is not supported (", React.createElement(OSWidgets.Expression, {
gridProperties: {
marginLeft: "0"
},
value: model.variables.operatingSystemsIdVar,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}), ").")];
})
},
_dependencies: [asPrimitiveValue(model.variables.operatingSystemsIdVar)]
})];
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.operatingSystemsIdVar), asPrimitiveValue(model.variables.errorVar.errorMessageAttr), asPrimitiveValue(model.variables.errorVar.errorCodeAttr), asPrimitiveValue(model.variables.isPluginLoadedVar), asPrimitiveValue(model.variables.isCorrectOSVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ContactsSampleApp.ContactsFlow.EntryPage.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.controller", "CommonPlugin.controller", "ContactsSampleApp.languageResources", "ContactsSampleApp.ContactsFlow.controller", "ContactsSampleApp.ContactsFlow.EntryPage.mvc$debugger", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$CheckContactsPlugin", "ContactsSampleApp.referencesHealth$ContactsPlugin", "CommonPlugin.controller$GetOperatingSystem"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginController, CommonPluginController, ContactsSampleAppLanguageResources, ContactsSampleApp_ContactsFlowController, ContactsSampleApp_ContactsFlow_EntryPage_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var checkContactsPluginVar = new OS.DataTypes.VariableHolder();
var getOperatingSystemVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.checkContactsPluginVar = checkContactsPluginVar;
varBag.getOperatingSystemVar = getOperatingSystemVar;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:b2KnOFUnzk6GEkLZbDN+Sw:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.p4OwopO+IESdFeU6KYygvA/ClientActions.b2KnOFUnzk6GEkLZbDN+Sw:YupBMVFLg6qtMvD+AgxmTg", "ContactsSampleApp", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:lBOgBE28K0Sd8xS4ZVpLWQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:_g_Wk_2X9kK6ZfhCXQqdIA", callContext.id);
// Execute Action: GetOperatingSystem
getOperatingSystemVar.value = CommonPluginController.default.getOperatingSystem$Action(callContext);

OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:XXlTG0Zzr0SPSAUMgsvLFw", callContext.id);
// Execute Action: CheckContactsPlugin
checkContactsPluginVar.value = ContactsPluginController.default.checkContactsPlugin$Action(callContext);

OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:gmUf8PQKJ0aSYV0SYaQDTQ", callContext.id);
// OperatingSystemsId = GetOperatingSystem.OperatingSystemsId
model.variables.operatingSystemsIdVar = getOperatingSystemVar.value.operatingSystemsIdOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:XwIZ1EVTl0CuklwsIcaFdw", callContext.id);
// IsCorrectOS = GetOperatingSystem.OperatingSystemsId = Android or GetOperatingSystem.OperatingSystemsId = iOS
model.variables.isCorrectOSVar = ((getOperatingSystemVar.value.operatingSystemsIdOut === ContactsSampleAppModel.staticEntities.mobile_OperatingSystem.android) || (getOperatingSystemVar.value.operatingSystemsIdOut === ContactsSampleAppModel.staticEntities.mobile_OperatingSystem.iOS));
// IsPluginLoaded
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:CKqtY_R0w06n2ViMqxezrw", callContext.id);
// IsPluginLoaded = CheckContactsPlugin.IsAvailable
model.variables.isPluginLoadedVar = checkContactsPluginVar.value.isAvailableOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:CKqtY_R0w06n2ViMqxezrw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error = CheckContactsPlugin.Error
model.variables.errorVar = checkContactsPluginVar.value.errorOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:zlUUIUv67UWYuMEzOznCew", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:b2KnOFUnzk6GEkLZbDN+Sw", callContext.id);
}

};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q:oTswzJAtrUammmPpEwGYvg", "ContactsSampleApp", "ContactsFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:p4OwopO+IESdFeU6KYygvA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.p4OwopO+IESdFeU6KYygvA:UwKYNQOUgp6JlkUN+EEWDA", "ContactsSampleApp", "EntryPage", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:p4OwopO+IESdFeU6KYygvA", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ContactsFlow/EntryPage On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ContactsSampleApp_ContactsFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.ContactsFlow.EntryPage.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"XXlTG0Zzr0SPSAUMgsvLFw": {
getter: function (varBag, idService) {
return varBag.checkContactsPluginVar.value;
}
},
"_g_Wk_2X9kK6ZfhCXQqdIA": {
getter: function (varBag, idService) {
return varBag.getOperatingSystemVar.value;
}
},
"LZt4IZ2hFU6RlqQRU+LqXA": {
getter: function (varBag, idService) {
return varBag.model.variables.isCorrectOSVar;
},
dataType: OS.Types.Boolean
},
"TbMlFZ74306ydp9_5aPxJQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isPluginLoadedVar;
},
dataType: OS.Types.Boolean
},
"0IqOhVX0702VfyEQ5aOZMA": {
getter: function (varBag, idService) {
return varBag.model.variables.operatingSystemsIdVar;
},
dataType: OS.Types.Text
},
"Elk3fcJoY0iQ7yY4Uv9DXw": {
getter: function (varBag, idService) {
return varBag.model.variables.errorVar;
}
},
"JSKpUr5LLUCFh7gktDtW5w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"SKIUVptXAk6gR_ft8lrfSw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"baFB6wdLWUedRRgVWTb3dA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("title"));
})(varBag.model, idService);
}
},
"67oz6yCydEuJQEDnbaBppQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"xv78Zq_O6km7N_YphI7a7g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderContent"));
})(varBag.model, idService);
}
},
"m+H6mpKQhEOOZecx8bwCmA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"VIdQE1IyrEGZ53ZRE4azSQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MarginContainer"));
})(varBag.model, idService);
}
},
"zkJNKbJ510aH8bjCQIZ0RA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"AiRpnQKkzUqbqKU3GK_3gg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"bm1+DmUPuU2NTczphFB6pA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("addContactScreenLink"));
})(varBag.model, idService);
}
},
"tvyu0DJAb06KynkS7CkoVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("addContactScreen"));
})(varBag.model, idService);
}
},
"FAZj2q8Ve0OkaRL7gwFR_w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"Irv1++TtiEmCnRdkLVfX8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"g4aHt0cCyUGNTtbbdWgPjQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"tisT823p70y9QLG8ymK6rg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"B2qQGWQe3ku7rX6VqRjW_g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Jr0uAr8wZUKT2Szp+Rhwyw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("findContactScreenLink"));
})(varBag.model, idService);
}
},
"rKcCzq2xzECkwpq9UHLjRg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("findContactScreen"));
})(varBag.model, idService);
}
},
"YelC_preKEyZ1J0y6xRRDw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"zc1Kqosg1ESojgayXR9IoA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"tGuFjYQNNE+zaSpdqPMHHQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"URGES+BSn0iKwjRF6XEdFg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"jeygnA+C7EGiQIQYykk6pg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"_zEWTyWMwEGCUGo7oXn7QA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("pickContactScreenLink"));
})(varBag.model, idService);
}
},
"nwnkFIK8Z0+zoyZyqDcgag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("pickContactScreen"));
})(varBag.model, idService);
}
},
"0xOPWNx0t0OxD53zvZ1OjA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"8gy8kNbbPkm_0fgNvtiaaQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"FfuD9AW0ukmwOLySsNvYYw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"8URmIrdkrUC9J0aeLTwsDg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"ypudMbdcF0Oq4z3+4fOLww": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MarginContainer"));
})(varBag.model, idService);
}
},
"Q9ofVRweCECPGzKNIWpwiA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MarginContainer"));
})(varBag.model, idService);
}
},
"HOdx54GhvkWxH7PiH6N_Mg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
