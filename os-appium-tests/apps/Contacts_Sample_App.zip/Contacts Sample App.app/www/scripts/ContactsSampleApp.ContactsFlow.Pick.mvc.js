﻿define("ContactsSampleApp.ContactsFlow.Pick.mvc$model", ["OutSystems", "ContactsSampleApp.model", "ContactsPlugin.model", "CommonPlugin.model", "ContactsPlugin.controller", "ContactsSampleApp.Common.Layout.mvc$model", "ContactsSampleApp.Common.MenuIcon.mvc$model", "MobilePatterns.Utilities.MarginContainer.mvc$model", "MobilePatterns.Content.Card.mvc$model", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$model", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$PickContact"], function (OutSystems, ContactsSampleAppModel, ContactsPluginModel, CommonPluginModel, ContactsPluginController, ContactsSampleApp_Common_Layout_mvcModel, ContactsSampleApp_Common_MenuIcon_mvcModel, MobilePatterns_Utilities_MarginContainer_mvcModel, MobilePatterns_Content_Card_mvcModel, ContactsSampleApp_ContactsFlow_BottomBar_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((ContactsSampleApp_Common_Layout_mvcModel.hasValidationWidgets || ContactsSampleApp_Common_MenuIcon_mvcModel.hasValidationWidgets) || MobilePatterns_Utilities_MarginContainer_mvcModel.hasValidationWidgets) || MobilePatterns_Content_Card_mvcModel.hasValidationWidgets) || ContactsSampleApp_ContactsFlow_BottomBar_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.ContactsFlow.Pick.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "ContactsPlugin.model", "CommonPlugin.model", "ContactsPlugin.controller", "react", "OutSystemsReactView", "ContactsSampleApp.ContactsFlow.Pick.mvc$model", "ContactsSampleApp.ContactsFlow.Pick.mvc$controller", "ContactsSampleApp.Common.Layout.mvc$view", "OutSystemsReactWidgets", "ContactsSampleApp.Common.MenuIcon.mvc$view", "MobilePatterns.Utilities.MarginContainer.mvc$view", "MobilePatterns.Content.Card.mvc$view", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$view", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$PickContact"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, ContactsPluginModel, CommonPluginModel, ContactsPluginController, React, OSView, ContactsSampleApp_ContactsFlow_Pick_mvc_model, ContactsSampleApp_ContactsFlow_Pick_mvc_controller, ContactsSampleApp_Common_Layout_mvc_view, OSWidgets, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, MobilePatterns_Content_Card_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ContactsFlow.Pick";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MobilePatterns.BaseTheme.css", "css/MobilePatterns.TabletTheme.css", "css/ContactsSampleApp.ContactsSampleApp.css", "css/MobilePatterns.TabletTheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ContactsSampleApp_Common_Layout_mvc_view, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, MobilePatterns_Content_Card_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Pick_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Pick_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(ContactsSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: new PlaceholderContent(function () {
return ["Pick", React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Contacts plugin")];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Helper", {}),
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "TP_veqJ_x0GRb7vS_1a20A"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "info-circle",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "POApt87G+EOoSpmofZm8ng"
},
text: [" "],
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Content_Card_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "Cj1aV5yH7kyHiMdEZO5A2g"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Pick/pickContactButton OnClick");
return controller.pickOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "pickContactButton"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Pick Contact"), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Opens the device specific contact picker to pick a contact from the device\'s address book.")];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_ContactsFlow_BottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ContactsSampleApp.ContactsFlow.Pick.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "ContactsPlugin.model", "CommonPlugin.model", "ContactsPlugin.controller", "ContactsSampleApp.languageResources", "ContactsSampleApp.ContactsFlow.controller", "ContactsSampleApp.ContactsFlow.Pick.mvc$debugger", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$PickContact"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, ContactsPluginModel, CommonPluginModel, ContactsPluginController, ContactsSampleAppLanguageResources, ContactsSampleApp_ContactsFlowController, ContactsSampleApp_ContactsFlow_Pick_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._pickOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("PickOnClick");
callContext = controller.callContext(callContext);
var pickContactVar = new OS.DataTypes.VariableHolder();
var jSONSerialize1Var = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.pickContactVar = pickContactVar;
varBag.jSONSerialize1Var = jSONSerialize1Var;
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:TWSPrppZaUCusQarGUlsNA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.RdxGbPWmkkyyAV3+QePOSA/ClientActions.TWSPrppZaUCusQarGUlsNA:Xz6weLgDyChOBZQCbBPgeA", "ContactsSampleApp", "PickOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:W0CvKCLiskqzYP_WnBp5+g", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:sO4wk7QQVkKm0nkKCMyrFA", callContext.id);
// Execute Action: PickContact
model.flush();
return ContactsPluginController.default.pickContact$Action(callContext).then(function (value) {
pickContactVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:AJUEo0shkEOTpLgjOsD+nQ", callContext.id) && pickContactVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:S+niI4aAJk6nTVh3YQdqgQ", callContext.id);
// JSON Serialize: JSONSerialize1
jSONSerialize1Var.value.jSONOut = OS.JSONUtils.serializeToJSON(pickContactVar.value.contactOut, false, false);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:e_nL+3uEV0OcSg7FFZLz1Q", callContext.id);
// Destination: /ContactsSampleApp/Contact
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/ContactsSampleApp/Contact", {
ContactSerialized: jSONSerialize1Var.value.jSONOut
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
// PickContact Error
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:v3x7NwJigUqkvfEvq+sclQ", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(((("ErrorCode: " + pickContactVar.value.errorOut.errorCodeAttr) + ", ErrorMessage: ") + pickContactVar.value.errorOut.errorMessageAttr), /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ZFrAIHmVk0ifgZD9fWyuqQ", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:TWSPrppZaUCusQarGUlsNA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:TWSPrppZaUCusQarGUlsNA", callContext.id);
throw ex;

});
};

Controller.prototype.pickOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._pickOnClick$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q:oTswzJAtrUammmPpEwGYvg", "ContactsSampleApp", "ContactsFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:RdxGbPWmkkyyAV3+QePOSA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.RdxGbPWmkkyyAV3+QePOSA:m5v29IJgkghqO560Q1uz1w", "ContactsSampleApp", "Pick", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:RdxGbPWmkkyyAV3+QePOSA", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ContactsSampleApp_ContactsFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.ContactsFlow.Pick.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"sO4wk7QQVkKm0nkKCMyrFA": {
getter: function (varBag, idService) {
return varBag.pickContactVar.value;
}
},
"S+niI4aAJk6nTVh3YQdqgQ": {
getter: function (varBag, idService) {
return varBag.jSONSerialize1Var.value;
}
},
"lg0RO+4dr0G_0m3gD7dShw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"ID7piL29KUOindIa3xeoSQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"+Fu3cqskwUGIR8iW1oGfdg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"d7ljGIXY8UuJOE_QMom3uQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderContent"));
})(varBag.model, idService);
}
},
"4l8e09T8g0eqcM4q2MXc7g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"sJke55NS4UW1c7LA5tTlqQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MarginContainer"));
})(varBag.model, idService);
}
},
"00ucH1fx50+VbENYfdVYog": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Cj1aV5yH7kyHiMdEZO5A2g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("pickContactButton"));
})(varBag.model, idService);
}
},
"R21EVBLBhUyMq1sPRd00gg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
