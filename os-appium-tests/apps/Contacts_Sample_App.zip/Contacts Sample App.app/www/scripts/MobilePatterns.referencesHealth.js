﻿define("MobilePatterns.referencesHealth$HTTPRequestHandler", [], function () {
// Reference to producer 'HTTPRequestHandler' is OK.
});
define("MobilePatterns.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("MobilePatterns.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("MobilePatterns.referencesHealth", [], function () {
});
