﻿define("ContactsPlugin.model$ContactNameRec", ["exports", "OutSystems", "ContactsPlugin.model"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactNameRec = (function (_super) {
__extends(ContactNameRec, _super);
function ContactNameRec(defaults) {
_super.apply(this, arguments);
}
ContactNameRec.attributesToDeclare = function () {
return [
this.attr("Formatted", "formattedAttr", "formatted", false, OS.Types.Text, function () {
return "";
}), 
this.attr("FamilyName", "familyNameAttr", "familyName", false, OS.Types.Text, function () {
return "";
}), 
this.attr("GivenName", "givenNameAttr", "givenName", false, OS.Types.Text, function () {
return "";
}), 
this.attr("MiddleName", "middleNameAttr", "MiddleName", false, OS.Types.Text, function () {
return "";
}), 
this.attr("HonorificPrefix", "honorificPrefixAttr", "HonorificPrefix", false, OS.Types.Text, function () {
return "";
}), 
this.attr("HonorificSuffix", "honorificSuffixAttr", "HonorificSuffix", false, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
ContactNameRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
ContactNameRec.init();
return ContactNameRec;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactNameRec = ContactNameRec;

});
define("ContactsPlugin.model$ContactFieldRec", ["exports", "OutSystems", "ContactsPlugin.model"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactFieldRec = (function (_super) {
__extends(ContactFieldRec, _super);
function ContactFieldRec(defaults) {
_super.apply(this, arguments);
}
ContactFieldRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Value", "valueAttr", "value", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Pref", "prefAttr", "pref", false, OS.Types.Boolean, function () {
return false;
})
].concat(_super.attributesToDeclare.call(this));
};
ContactFieldRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
ContactFieldRec.init();
return ContactFieldRec;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactFieldRec = ContactFieldRec;

});
define("ContactsPlugin.model$ContactFieldList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactFieldRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactFieldList = (function (_super) {
__extends(ContactFieldList, _super);
function ContactFieldList(defaults) {
_super.apply(this, arguments);
}
ContactFieldList.RecordType = ContactsPluginModel.ContactFieldRec;
return ContactFieldList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactFieldList = ContactFieldList;

});
define("ContactsPlugin.model$ContactAddressRec", ["exports", "OutSystems", "ContactsPlugin.model"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactAddressRec = (function (_super) {
__extends(ContactAddressRec, _super);
function ContactAddressRec(defaults) {
_super.apply(this, arguments);
}
ContactAddressRec.attributesToDeclare = function () {
return [
this.attr("Pref", "prefAttr", "pref", false, OS.Types.Boolean, function () {
return false;
}), 
this.attr("Type", "typeAttr", "type", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Formatted", "formattedAttr", "formatted", false, OS.Types.Text, function () {
return "";
}), 
this.attr("StreetAddress", "streetAddressAttr", "streetAddress", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Locality", "localityAttr", "locality", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Region", "regionAttr", "region", false, OS.Types.Text, function () {
return "";
}), 
this.attr("PostalCode", "postalCodeAttr", "postalCode", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Country", "countryAttr", "country", false, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
ContactAddressRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
ContactAddressRec.init();
return ContactAddressRec;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactAddressRec = ContactAddressRec;

});
define("ContactsPlugin.model$ContactAddressList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactAddressRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactAddressList = (function (_super) {
__extends(ContactAddressList, _super);
function ContactAddressList(defaults) {
_super.apply(this, arguments);
}
ContactAddressList.RecordType = ContactsPluginModel.ContactAddressRec;
return ContactAddressList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactAddressList = ContactAddressList;

});
define("ContactsPlugin.model$ContactOrganizationRec", ["exports", "OutSystems", "ContactsPlugin.model"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactOrganizationRec = (function (_super) {
__extends(ContactOrganizationRec, _super);
function ContactOrganizationRec(defaults) {
_super.apply(this, arguments);
}
ContactOrganizationRec.attributesToDeclare = function () {
return [
this.attr("Pref", "prefAttr", "pref", false, OS.Types.Boolean, function () {
return false;
}), 
this.attr("Type", "typeAttr", "type", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Name", "nameAttr", "name", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Department", "departmentAttr", "value", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Title", "titleAttr", "title", false, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
ContactOrganizationRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
ContactOrganizationRec.init();
return ContactOrganizationRec;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactOrganizationRec = ContactOrganizationRec;

});
define("ContactsPlugin.model$ContactOrganizationList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactOrganizationRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactOrganizationList = (function (_super) {
__extends(ContactOrganizationList, _super);
function ContactOrganizationList(defaults) {
_super.apply(this, arguments);
}
ContactOrganizationList.RecordType = ContactsPluginModel.ContactOrganizationRec;
return ContactOrganizationList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactOrganizationList = ContactOrganizationList;

});
define("ContactsPlugin.model$ContactRec", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactNameRec", "ContactsPlugin.model$ContactFieldList", "ContactsPlugin.model$ContactAddressList", "ContactsPlugin.model$ContactOrganizationList"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactRec = (function (_super) {
__extends(ContactRec, _super);
function ContactRec(defaults) {
_super.apply(this, arguments);
}
ContactRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "id", false, OS.Types.Text, function () {
return "";
}), 
this.attr("DisplayName", "displayNameAttr", "displayName", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Name", "nameAttr", "name", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactNameRec());
}, ContactsPluginModel.ContactNameRec), 
this.attr("Nickname", "nicknameAttr", "nickname", false, OS.Types.Text, function () {
return "";
}), 
this.attr("PhoneNumbers", "phoneNumbersAttr", "phoneNumbers", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldList());
}, ContactsPluginModel.ContactFieldList), 
this.attr("Emails", "emailsAttr", "emails", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldList());
}, ContactsPluginModel.ContactFieldList), 
this.attr("Addresses", "addressesAttr", "addresses", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactAddressList());
}, ContactsPluginModel.ContactAddressList), 
this.attr("IMs", "iMsAttr", "ims", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldList());
}, ContactsPluginModel.ContactFieldList), 
this.attr("Organizations", "organizationsAttr", "organizations", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactOrganizationList());
}, ContactsPluginModel.ContactOrganizationList), 
this.attr("Birthday", "birthdayAttr", "birthday", false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}), 
this.attr("Note", "noteAttr", "note", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Photos", "photosAttr", "photos", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldList());
}, ContactsPluginModel.ContactFieldList), 
this.attr("Categories", "categoriesAttr", "categories", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldList());
}, ContactsPluginModel.ContactFieldList), 
this.attr("Urls", "urlsAttr", "urls", false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldList());
}, ContactsPluginModel.ContactFieldList)
].concat(_super.attributesToDeclare.call(this));
};
ContactRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
ContactRec.init();
return ContactRec;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactRec = ContactRec;

});
define("ContactsPlugin.model$ContactRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactRecord = (function (_super) {
__extends(ContactRecord, _super);
function ContactRecord(defaults) {
_super.apply(this, arguments);
}
ContactRecord.attributesToDeclare = function () {
return [
this.attr("Contact", "contactAttr", "Contact", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactRec());
}, ContactsPluginModel.ContactRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactRecord.fromStructure = function (str) {
return new ContactRecord(new ContactRecord.RecordClass({
contactAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactRecord.IsAnonymousRecord = true;
ContactRecord.UniqueId = "02fbfcb4-679e-8285-4fb4-6fe3cfa74602";
ContactRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactRecord.init();
return ContactRecord;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactRecord = ContactRecord;

});
define("ContactsPlugin.model$ContactFieldRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactFieldRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactFieldRecord = (function (_super) {
__extends(ContactFieldRecord, _super);
function ContactFieldRecord(defaults) {
_super.apply(this, arguments);
}
ContactFieldRecord.attributesToDeclare = function () {
return [
this.attr("ContactField", "contactFieldAttr", "ContactField", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldRec());
}, ContactsPluginModel.ContactFieldRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactFieldRecord.fromStructure = function (str) {
return new ContactFieldRecord(new ContactFieldRecord.RecordClass({
contactFieldAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactFieldRecord.IsAnonymousRecord = true;
ContactFieldRecord.UniqueId = "27effb4f-73b6-2c44-3999-1cf7173f1d5b";
ContactFieldRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactFieldRecord.init();
return ContactFieldRecord;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactFieldRecord = ContactFieldRecord;

});
define("ContactsPlugin.model$ContactFieldRecordList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactFieldRecord"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactFieldRecordList = (function (_super) {
__extends(ContactFieldRecordList, _super);
function ContactFieldRecordList(defaults) {
_super.apply(this, arguments);
}
ContactFieldRecordList.RecordType = ContactsPluginModel.ContactFieldRecord;
return ContactFieldRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactFieldRecordList = ContactFieldRecordList;

});
define("ContactsPlugin.model$ErrorList", ["exports", "OutSystems", "CommonPlugin.model", "ContactsPlugin.model", "CommonPlugin.model$ErrorRec", "ContactsPlugin.referencesHealth", "ContactsPlugin.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ErrorList = (function (_super) {
__extends(ErrorList, _super);
function ErrorList(defaults) {
_super.apply(this, arguments);
}
ErrorList.RecordType = CommonPluginModel.ErrorRec;
return ErrorList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ErrorList = ErrorList;

});
define("ContactsPlugin.model$ContactNameRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactNameRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactNameRecord = (function (_super) {
__extends(ContactNameRecord, _super);
function ContactNameRecord(defaults) {
_super.apply(this, arguments);
}
ContactNameRecord.attributesToDeclare = function () {
return [
this.attr("ContactName", "contactNameAttr", "ContactName", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactNameRec());
}, ContactsPluginModel.ContactNameRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactNameRecord.fromStructure = function (str) {
return new ContactNameRecord(new ContactNameRecord.RecordClass({
contactNameAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactNameRecord.IsAnonymousRecord = true;
ContactNameRecord.UniqueId = "9faf2b14-b0e9-9043-56f4-c30c2e29c727";
ContactNameRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactNameRecord.init();
return ContactNameRecord;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactNameRecord = ContactNameRecord;

});
define("ContactsPlugin.model$ContactNameRecordList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactNameRecord"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactNameRecordList = (function (_super) {
__extends(ContactNameRecordList, _super);
function ContactNameRecordList(defaults) {
_super.apply(this, arguments);
}
ContactNameRecordList.RecordType = ContactsPluginModel.ContactNameRecord;
return ContactNameRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactNameRecordList = ContactNameRecordList;

});
define("ContactsPlugin.model$ErrorRecord", ["exports", "OutSystems", "CommonPlugin.model", "ContactsPlugin.model", "CommonPlugin.model$ErrorRec", "ContactsPlugin.referencesHealth", "ContactsPlugin.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ErrorRecord = (function (_super) {
__extends(ErrorRecord, _super);
function ErrorRecord(defaults) {
_super.apply(this, arguments);
}
ErrorRecord.attributesToDeclare = function () {
return [
this.attr("Error", "errorAttr", "Error", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.ErrorRec());
}, CommonPluginModel.ErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ErrorRecord.fromStructure = function (str) {
return new ErrorRecord(new ErrorRecord.RecordClass({
errorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ErrorRecord.IsAnonymousRecord = true;
ErrorRecord.UniqueId = "cbbd7d57-66e1-86ff-28ab-3b75adf75b93";
ErrorRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ErrorRecord.init();
return ErrorRecord;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ErrorRecord = ErrorRecord;

});
define("ContactsPlugin.model$ErrorRecordList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ErrorRecord"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ErrorRecordList = (function (_super) {
__extends(ErrorRecordList, _super);
function ErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ErrorRecordList.RecordType = ContactsPluginModel.ErrorRecord;
return ErrorRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ErrorRecordList = ErrorRecordList;

});
define("ContactsPlugin.model$ContactNameList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactNameRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactNameList = (function (_super) {
__extends(ContactNameList, _super);
function ContactNameList(defaults) {
_super.apply(this, arguments);
}
ContactNameList.RecordType = ContactsPluginModel.ContactNameRec;
return ContactNameList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactNameList = ContactNameList;

});
define("ContactsPlugin.model$ContactOrganizationRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactOrganizationRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactOrganizationRecord = (function (_super) {
__extends(ContactOrganizationRecord, _super);
function ContactOrganizationRecord(defaults) {
_super.apply(this, arguments);
}
ContactOrganizationRecord.attributesToDeclare = function () {
return [
this.attr("ContactOrganization", "contactOrganizationAttr", "ContactOrganization", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactOrganizationRec());
}, ContactsPluginModel.ContactOrganizationRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactOrganizationRecord.fromStructure = function (str) {
return new ContactOrganizationRecord(new ContactOrganizationRecord.RecordClass({
contactOrganizationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactOrganizationRecord.IsAnonymousRecord = true;
ContactOrganizationRecord.UniqueId = "93f02c96-b6e3-055c-f3e0-db8e15f483ac";
ContactOrganizationRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactOrganizationRecord.init();
return ContactOrganizationRecord;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactOrganizationRecord = ContactOrganizationRecord;

});
define("ContactsPlugin.model$ContactOrganizationRecordList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactOrganizationRecord"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactOrganizationRecordList = (function (_super) {
__extends(ContactOrganizationRecordList, _super);
function ContactOrganizationRecordList(defaults) {
_super.apply(this, arguments);
}
ContactOrganizationRecordList.RecordType = ContactsPluginModel.ContactOrganizationRecord;
return ContactOrganizationRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactOrganizationRecordList = ContactOrganizationRecordList;

});
define("ContactsPlugin.model$ContactAddressRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactAddressRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactAddressRecord = (function (_super) {
__extends(ContactAddressRecord, _super);
function ContactAddressRecord(defaults) {
_super.apply(this, arguments);
}
ContactAddressRecord.attributesToDeclare = function () {
return [
this.attr("ContactAddress", "contactAddressAttr", "ContactAddress", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactAddressRec());
}, ContactsPluginModel.ContactAddressRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactAddressRecord.fromStructure = function (str) {
return new ContactAddressRecord(new ContactAddressRecord.RecordClass({
contactAddressAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactAddressRecord.IsAnonymousRecord = true;
ContactAddressRecord.UniqueId = "a141adb5-7ff9-2281-e375-405159ed89a0";
ContactAddressRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactAddressRecord.init();
return ContactAddressRecord;
})(OS.DataTypes.GenericRecord);
ContactsPluginModel.ContactAddressRecord = ContactAddressRecord;

});
define("ContactsPlugin.model$ContactAddressRecordList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactAddressRecord"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactAddressRecordList = (function (_super) {
__extends(ContactAddressRecordList, _super);
function ContactAddressRecordList(defaults) {
_super.apply(this, arguments);
}
ContactAddressRecordList.RecordType = ContactsPluginModel.ContactAddressRecord;
return ContactAddressRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactAddressRecordList = ContactAddressRecordList;

});
define("ContactsPlugin.model$ContactList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactRec"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactList = (function (_super) {
__extends(ContactList, _super);
function ContactList(defaults) {
_super.apply(this, arguments);
}
ContactList.RecordType = ContactsPluginModel.ContactRec;
return ContactList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactList = ContactList;

});
define("ContactsPlugin.model$ContactRecordList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.model$ContactRecord"], function (exports, OutSystems, ContactsPluginModel) {
var OS = OutSystems.Internal;
var ContactRecordList = (function (_super) {
__extends(ContactRecordList, _super);
function ContactRecordList(defaults) {
_super.apply(this, arguments);
}
ContactRecordList.RecordType = ContactsPluginModel.ContactRecord;
return ContactRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsPluginModel.ContactRecordList = ContactRecordList;

});
define("ContactsPlugin.model", ["exports", "OutSystems"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ContactsPluginModel = exports;
Object.defineProperty(ContactsPluginModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["592480c6-99c1-4972-bb55-42fea1299882"];
}
});

ContactsPluginModel.staticEntities = {};
});
