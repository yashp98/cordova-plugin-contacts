﻿define("ContactsSampleApp.ContactsFlow.Add.mvc$model", ["OutSystems", "ContactsSampleApp.model", "CommonPlugin.model", "ContactsPlugin.controller", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$AddToContacts", "ContactsSampleApp.referencesHealth$ContactsPlugin", "ContactsSampleApp.model$AddContactRequestRec"], function (OutSystems, ContactsSampleAppModel, CommonPluginModel, ContactsPluginController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("AddContactRequest", "addContactRequestVar", "AddContactRequest", true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsSampleAppModel.AddContactRequestRec());
}, ContactsSampleAppModel.AddContactRequestRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromStructure = function (str) {
return new VariablesRecord(new VariablesRecord.RecordClass({
addContactRequestVar: OS.DataTypes.ImmutableBase.getData(str)
}));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Form1: OS.Model.ValidationWidgetRecord,
inputFirstName: OS.Model.ValidationWidgetRecord,
inputLastName: OS.Model.ValidationWidgetRecord,
inputPhone: OS.Model.ValidationWidgetRecord,
inputEmail: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.ContactsFlow.Add.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.controller", "react", "OutSystemsReactView", "ContactsSampleApp.ContactsFlow.Add.mvc$model", "ContactsSampleApp.ContactsFlow.Add.mvc$controller", "ContactsSampleApp.Common.Layout.mvc$view", "OutSystemsReactWidgets", "ContactsSampleApp.Common.MenuIcon.mvc$view", "MobilePatterns.Utilities.MarginContainer.mvc$view", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$view", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$AddToContacts", "ContactsSampleApp.referencesHealth$ContactsPlugin", "ContactsSampleApp.model$AddContactRequestRec"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginController, React, OSView, ContactsSampleApp_ContactsFlow_Add_mvc_model, ContactsSampleApp_ContactsFlow_Add_mvc_controller, ContactsSampleApp_Common_Layout_mvc_view, OSWidgets, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ContactsFlow.Add";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MobilePatterns.BaseTheme.css", "css/MobilePatterns.TabletTheme.css", "css/ContactsSampleApp.ContactsSampleApp.css", "css/MobilePatterns.TabletTheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ContactsSampleApp_Common_Layout_mvc_view, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Add_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Add_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(ContactsSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: new PlaceholderContent(function () {
return ["Add", React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Contacts plugin")];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Helper", {}),
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "RdSvhiMLXkeZEiXHLb1HMg"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "info-circle",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "PllLcYA3206CKXi2gkn7uQ"
},
text: [" "],
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form card",
_idProps: {
service: idService,
name: "Form1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/Name1 OnClick");
controller.name1OnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "Name1"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Name1"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "WF+bSlZTO0yTso_UaIAAmQ"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/Name1_changephone OnClick");
controller.name1ChangePhoneOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "Name1_changephone"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Name1 (change phone)"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "HvtP7BYZZUuIAwcpIyg6Zg"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/Name1_changeemail OnClick");
controller.name1ChangeEmailOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "Name1_changeemail"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Name1 (change email)"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "phqrW0129kKmBxKr4sI+0A"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/Name1_changephoneandemail OnClick");
controller.name1ChangePhoneEmailOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "Name1_changephoneandemail"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Name1 (change phone and email)"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "eKevp+xzwkCUNHCALuJSFQ"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/Name2_nophone OnClick");
controller.name2OnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "Name2_nophone"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Name2 (no phone)"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "fja9Lxy3b0udW5Fyt02fmw"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/onlyphone OnClick");
controller.onlyPhoneOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "onlyphone"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Only Phone"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "f9bmtrZrQ0uBW4IZRxwP1A"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/strangeformat OnClick");
controller.strangeFormatOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "strangeformat"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Strange Format")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
visible: true,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "inputFirstName",
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, "First Name"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.addContactRequestVar.firstNameAttr, function (value) {
model.variables.addContactRequestVar.firstNameAttr = value;
}),
_idProps: {
service: idService,
name: "inputFirstName"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The first name of the contact.")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "inputLastName",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Last Name"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.addContactRequestVar.lastNameAttr, function (value) {
model.variables.addContactRequestVar.lastNameAttr = value;
}),
_idProps: {
service: idService,
name: "inputLastName"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The last name of the contact.")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "inputPhone",
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Phone"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Phone*/ 6,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.PhoneNumber, model.variables.addContactRequestVar.phoneAttr, function (value) {
model.variables.addContactRequestVar.phoneAttr = value;
}),
_idProps: {
service: idService,
name: "inputPhone"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The phone number of the contact.")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
visible: true,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "inputEmail",
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Email"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Email*/ 7,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Email, model.variables.addContactRequestVar.emailAttr, function (value) {
model.variables.addContactRequestVar.emailAttr = value;
}),
_idProps: {
service: idService,
name: "inputEmail"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The email address of the contact.")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "4s9egduvjUGF2aYW1GWU9Q",
"button-id": "addContact"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
_this.validateWidget(idService.getId("Form1"));
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Add/addContactButton OnClick");
return controller.addOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});

;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "addContactButton"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Add Contact")))];
})
},
_dependencies: [asPrimitiveValue(model.variables.addContactRequestVar.emailAttr), asPrimitiveValue(model.variables.addContactRequestVar.phoneAttr), asPrimitiveValue(model.variables.addContactRequestVar.lastNameAttr), asPrimitiveValue(model.variables.addContactRequestVar.firstNameAttr)]
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_ContactsFlow_BottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.addContactRequestVar.emailAttr), asPrimitiveValue(model.variables.addContactRequestVar.phoneAttr), asPrimitiveValue(model.variables.addContactRequestVar.lastNameAttr), asPrimitiveValue(model.variables.addContactRequestVar.firstNameAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ContactsSampleApp.ContactsFlow.Add.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.controller", "ContactsSampleApp.languageResources", "ContactsSampleApp.ContactsFlow.controller", "ContactsSampleApp.ContactsFlow.Add.mvc$debugger", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$AddToContacts", "ContactsSampleApp.referencesHealth$ContactsPlugin", "ContactsSampleApp.model$AddContactRequestRec"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginController, ContactsSampleAppLanguageResources, ContactsSampleApp_ContactsFlowController, ContactsSampleApp_ContactsFlow_Add_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._name1ChangePhoneOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name1ChangePhoneOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:wNndBO5kVEW80KXCf+ZhIA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.wNndBO5kVEW80KXCf+ZhIA:kvLQpjte2vQOlPL_i+U48A", "ContactsSampleApp", "Name1ChangePhoneOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:sFLCtYjiWEyMtMv907VQgg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:KDnswHMroUiTXwsLf1vzGw", callContext.id);
// AddContactRequest.FirstName = "Test app - Name1"
model.variables.addContactRequestVar.firstNameAttr = "Test app - Name1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:KDnswHMroUiTXwsLf1vzGw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddContactRequest.LastName = "Last1"
model.variables.addContactRequestVar.lastNameAttr = "Last1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:KDnswHMroUiTXwsLf1vzGw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddContactRequest.Phone = "+351111111111"
model.variables.addContactRequestVar.phoneAttr = "+351111111111";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:KDnswHMroUiTXwsLf1vzGw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddContactRequest.Email = "email1@outsystems.com"
model.variables.addContactRequestVar.emailAttr = "email1@outsystems.com";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:nchSPXdfC0OU9PFX6wOVyg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:wNndBO5kVEW80KXCf+ZhIA", callContext.id);
}

};
Controller.prototype._onlyPhoneOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnlyPhoneOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:CqFkQMGX50y0v19DQSN5ug:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.CqFkQMGX50y0v19DQSN5ug:IULr04KQrq7r7e_THe1NeA", "ContactsSampleApp", "OnlyPhoneOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:aS_mheFcEUCHBX+JNvKXsw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:QdqjjITS2kSgamzSLkCM6w", callContext.id);
// AddContactRequest.FirstName = ""
model.variables.addContactRequestVar.firstNameAttr = "";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:QdqjjITS2kSgamzSLkCM6w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddContactRequest.LastName = ""
model.variables.addContactRequestVar.lastNameAttr = "";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:QdqjjITS2kSgamzSLkCM6w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddContactRequest.Phone = "+351000000000"
model.variables.addContactRequestVar.phoneAttr = "+351000000000";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:QdqjjITS2kSgamzSLkCM6w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddContactRequest.Email = ""
model.variables.addContactRequestVar.emailAttr = "";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:xpG8gtGHykWa860BcEhUag", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:CqFkQMGX50y0v19DQSN5ug", callContext.id);
}

};
Controller.prototype._name2OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name2OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:Bs+BTBrCoUmSf6jl9WWfYQ:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.Bs+BTBrCoUmSf6jl9WWfYQ:inBG_e3Yi4iFTZI0X7Lh6Q", "ContactsSampleApp", "Name2OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:VQ+D0YHtCE227nHJy9+2dw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:J415jirUOU6UrMk39ebfkw", callContext.id);
// AddContactRequest.FirstName = "Test app - Name2"
model.variables.addContactRequestVar.firstNameAttr = "Test app - Name2";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:J415jirUOU6UrMk39ebfkw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddContactRequest.LastName = "Last2"
model.variables.addContactRequestVar.lastNameAttr = "Last2";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:J415jirUOU6UrMk39ebfkw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddContactRequest.Phone = ""
model.variables.addContactRequestVar.phoneAttr = "";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:J415jirUOU6UrMk39ebfkw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddContactRequest.Email = "email1@outsystems.com"
model.variables.addContactRequestVar.emailAttr = "email1@outsystems.com";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:M9W11jQsUk+GJbFC2GAiLw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:Bs+BTBrCoUmSf6jl9WWfYQ", callContext.id);
}

};
Controller.prototype._strangeFormatOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("StrangeFormatOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:AjGufbHMk0WJ1kkNvOTZ9Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.AjGufbHMk0WJ1kkNvOTZ9Q:7Bocro3MzFLXr2hAAD9Qlg", "ContactsSampleApp", "StrangeFormatOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:gvDjhQBlQEC85C6JNMPEaQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:XEhdWP5OBUqbrfBrOhoRlA", callContext.id);
// AddContactRequest.FirstName = "Test app - 111"
model.variables.addContactRequestVar.firstNameAttr = "Test app - 111";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:XEhdWP5OBUqbrfBrOhoRlA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddContactRequest.LastName = "222"
model.variables.addContactRequestVar.lastNameAttr = "222";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:XEhdWP5OBUqbrfBrOhoRlA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddContactRequest.Phone = "+#,N12#"
model.variables.addContactRequestVar.phoneAttr = "+#,N12#";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:XEhdWP5OBUqbrfBrOhoRlA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddContactRequest.Email = "333"
model.variables.addContactRequestVar.emailAttr = "333";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:LorEuKR4MUKh3jAIerE4BA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:AjGufbHMk0WJ1kkNvOTZ9Q", callContext.id);
}

};
Controller.prototype._name1OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name1OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:BLd_ikuVakupGJdfExfjAg:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.BLd_ikuVakupGJdfExfjAg:gXanyzfa50oh6JP1xnYDAg", "ContactsSampleApp", "Name1OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:oxyzrib98kaBWJBYJ2GMfw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:YXHsq_qrIUyQCc9tr7T23A", callContext.id);
// AddContactRequest.FirstName = "Test app - Name1"
model.variables.addContactRequestVar.firstNameAttr = "Test app - Name1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:YXHsq_qrIUyQCc9tr7T23A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddContactRequest.LastName = "Last1"
model.variables.addContactRequestVar.lastNameAttr = "Last1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:YXHsq_qrIUyQCc9tr7T23A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddContactRequest.Phone = "+351000000000"
model.variables.addContactRequestVar.phoneAttr = "+351000000000";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:YXHsq_qrIUyQCc9tr7T23A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddContactRequest.Email = "email1@outsystems.com"
model.variables.addContactRequestVar.emailAttr = "email1@outsystems.com";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:2obzutnV2kyn7OKXj_jHOQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:BLd_ikuVakupGJdfExfjAg", callContext.id);
}

};
Controller.prototype._name1ChangePhoneEmailOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name1ChangePhoneEmailOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:aDCfuOKnBUGuER0LmCYs2A:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.aDCfuOKnBUGuER0LmCYs2A:WKnMDeT_Va8yrbe7wl2j4g", "ContactsSampleApp", "Name1ChangePhoneEmailOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:CahoBpykEE6bG4lkNuZ6Sw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ETchjTkZ+kSEILS9lnOCCw", callContext.id);
// AddContactRequest.FirstName = "Test app - Name1"
model.variables.addContactRequestVar.firstNameAttr = "Test app - Name1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ETchjTkZ+kSEILS9lnOCCw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddContactRequest.LastName = "Last1"
model.variables.addContactRequestVar.lastNameAttr = "Last1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ETchjTkZ+kSEILS9lnOCCw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddContactRequest.Phone = "+351222222222"
model.variables.addContactRequestVar.phoneAttr = "+351222222222";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ETchjTkZ+kSEILS9lnOCCw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddContactRequest.Email = "email3@outsystems.com"
model.variables.addContactRequestVar.emailAttr = "email3@outsystems.com";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:zh08kSJhPUK_sG4uN4yKZA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:aDCfuOKnBUGuER0LmCYs2A", callContext.id);
}

};
Controller.prototype._addOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("AddOnClick");
callContext = controller.callContext(callContext);
var addToContactsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.addToContactsVar = addToContactsVar;
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:OxMzv3ELeUSMQT76ZkKX9w:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.OxMzv3ELeUSMQT76ZkKX9w:7DpXxwmywxSkwRcBhSq6Kg", "ContactsSampleApp", "AddOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:R9i0yk9GBkSp+TmEskkTCQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:6CYhmGsJO0a5FtJvTtG7sQ", callContext.id);
// Execute Action: AddToContacts
model.flush();
return ContactsPluginController.default.addToContacts$Action(model.variables.addContactRequestVar.firstNameAttr, model.variables.addContactRequestVar.lastNameAttr, model.variables.addContactRequestVar.phoneAttr, model.variables.addContactRequestVar.emailAttr, callContext).then(function (value) {
addToContactsVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:6a6RaxEzXkilPD67zUlgRw", callContext.id) && addToContactsVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:21ZF0XeYoUqabB4+xMds9w", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(("Success: " + (addToContactsVar.value.successOut ? "True" : "False")), /*Info*/ 0);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:bP_UBljloUmwqrlrnF8sUQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:+bymet7lF0aIftujkC7V_w", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(((("ErrorCode: " + addToContactsVar.value.errorOut.errorCodeAttr) + ", ErrorMessage: ") + addToContactsVar.value.errorOut.errorMessageAttr), /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:tW41+9BSHkOS5GvV7wk2cA", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:OxMzv3ELeUSMQT76ZkKX9w", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:OxMzv3ELeUSMQT76ZkKX9w", callContext.id);
throw ex;

});
};
Controller.prototype._name1ChangeEmailOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name1ChangeEmailOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:ZlQz9drJkEqbQkVKgpjZdg:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q/ClientActions.ZlQz9drJkEqbQkVKgpjZdg:9U77awzmLtDU0FdWwGNtQw", "ContactsSampleApp", "Name1ChangeEmailOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:eywOwBv6j0+b9FSgUd0lng", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:HzcrGEtLEEetDaJbeideTQ", callContext.id);
// AddContactRequest.FirstName = "Test app - Name1"
model.variables.addContactRequestVar.firstNameAttr = "Test app - Name1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:HzcrGEtLEEetDaJbeideTQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddContactRequest.LastName = "Last1"
model.variables.addContactRequestVar.lastNameAttr = "Last1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:HzcrGEtLEEetDaJbeideTQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddContactRequest.Phone = "+351000000000"
model.variables.addContactRequestVar.phoneAttr = "+351000000000";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:HzcrGEtLEEetDaJbeideTQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddContactRequest.Email = "email2@outsystems.com"
model.variables.addContactRequestVar.emailAttr = "email2@outsystems.com";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:q2t+iGCcMk6wvgXQXyP_aA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:ZlQz9drJkEqbQkVKgpjZdg", callContext.id);
}

};

Controller.prototype.name1ChangePhoneOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name1ChangePhoneOnClick$Action, callContext);

};
Controller.prototype.onlyPhoneOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onlyPhoneOnClick$Action, callContext);

};
Controller.prototype.name2OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name2OnClick$Action, callContext);

};
Controller.prototype.strangeFormatOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._strangeFormatOnClick$Action, callContext);

};
Controller.prototype.name1OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name1OnClick$Action, callContext);

};
Controller.prototype.name1ChangePhoneEmailOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name1ChangePhoneEmailOnClick$Action, callContext);

};
Controller.prototype.addOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._addOnClick$Action, callContext);

};
Controller.prototype.name1ChangeEmailOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name1ChangeEmailOnClick$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q:oTswzJAtrUammmPpEwGYvg", "ContactsSampleApp", "ContactsFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:0uF3KiBbpUy9SyDGZS2u0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.0uF3KiBbpUy9SyDGZS2u0Q:f4eAarbSGQpqOK+pszqunw", "ContactsSampleApp", "Add", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:0uF3KiBbpUy9SyDGZS2u0Q", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ContactsSampleApp_ContactsFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.ContactsFlow.Add.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"6CYhmGsJO0a5FtJvTtG7sQ": {
getter: function (varBag, idService) {
return varBag.addToContactsVar.value;
}
},
"woX+tsPAoEWKKhfE5V85HQ": {
getter: function (varBag, idService) {
return varBag.model.variables.addContactRequestVar;
}
},
"+oGITAxdbE611AMV7FsriA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"Wtz4iW8+VUmbd_ISs_z00g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"CGC6u7sOtUemIS+iwWTAXg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"22YhCMhbgkeYQkLuE760tQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderContent"));
})(varBag.model, idService);
}
},
"Ar15iVA7sE6DOBIVzCJAtA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"iIDZrFy5ckKmzHNxZ2o_9A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MarginContainer"));
})(varBag.model, idService);
}
},
"Vm6PIymUr0GLcwzc1886BQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form1"));
})(varBag.model, idService);
}
},
"Y4MiNcQw8UyYUXMhuU2MoA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Name1"));
})(varBag.model, idService);
}
},
"WF+bSlZTO0yTso_UaIAAmQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Name1_changephone"));
})(varBag.model, idService);
}
},
"HvtP7BYZZUuIAwcpIyg6Zg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Name1_changeemail"));
})(varBag.model, idService);
}
},
"phqrW0129kKmBxKr4sI+0A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Name1_changephoneandemail"));
})(varBag.model, idService);
}
},
"eKevp+xzwkCUNHCALuJSFQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Name2_nophone"));
})(varBag.model, idService);
}
},
"fja9Lxy3b0udW5Fyt02fmw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("onlyphone"));
})(varBag.model, idService);
}
},
"f9bmtrZrQ0uBW4IZRxwP1A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("strangeformat"));
})(varBag.model, idService);
}
},
"XYpMR8ayxk2cGC4kODFUgg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("inputFirstName"));
})(varBag.model, idService);
}
},
"3fnBXQMMjkGSLRSWPVRaFA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("inputLastName"));
})(varBag.model, idService);
}
},
"_EkkpUW5lEWKlZfqScOhWA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("inputPhone"));
})(varBag.model, idService);
}
},
"9GCzEIf3E0OcF3VDjK0lGw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("inputEmail"));
})(varBag.model, idService);
}
},
"4s9egduvjUGF2aYW1GWU9Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("addContactButton"));
})(varBag.model, idService);
}
},
"Ir+snzUYP0+fxHfECErd6A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
