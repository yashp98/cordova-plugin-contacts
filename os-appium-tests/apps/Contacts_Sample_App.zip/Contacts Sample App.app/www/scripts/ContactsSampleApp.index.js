﻿require(["OutSystems", "ContactsSampleApp.appDefinition", "Debugger"], function (OutSystems, ContactsSampleAppAppDefinition, Debugger) {
var OS = OutSystems.Internal;
OS.Settings.setPlatformSettings({
DbNullDatesTZAware: true
});
if(OS.Navigation.ensureRequestSecurity()) {
return;
}

OutSystemsDebugger.initialize().then(function () {
return OS.Application.initialize(ContactsSampleAppAppDefinition, OS.Interfaces.Application.InitializationType.Full, new OS.Format.DateTimeFormatInfo("yyyy-MM-dd", "HH:mm:ss"), new OS.Format.NumberFormatInfo(".", "")).then(function (success) {
function initViewPromise() {
return OS.Flow.promise(function (resolve, reject) {
require(["OutSystemsReactView", "fastclick"], function (OSView, FastClick) {
try {OSView.Router.load(OS.Application);
FastClick.attach(document.body);
resolve();
} catch (error) {
reject(error);
}

});
});
};
if(success) {
return initViewPromise();
}


});
}).catch(function (error) {
OS.ErrorHandling.handleError(error);
});
});

