﻿define("ContactsSampleApp.Common.InvalidPermissions.mvc$model", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.Common.Layout.mvc$model", "ContactsSampleApp.Common.MenuIcon.mvc$model", "MobilePatterns.Content.BlankSlate.mvc$model", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$model"], function (OutSystems, ContactsSampleAppModel, ContactsSampleApp_Common_Layout_mvcModel, ContactsSampleApp_Common_MenuIcon_mvcModel, MobilePatterns_Content_BlankSlate_mvcModel, ContactsSampleApp_ContactsFlow_BottomBar_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((ContactsSampleApp_Common_Layout_mvcModel.hasValidationWidgets || ContactsSampleApp_Common_MenuIcon_mvcModel.hasValidationWidgets) || MobilePatterns_Content_BlankSlate_mvcModel.hasValidationWidgets) || ContactsSampleApp_ContactsFlow_BottomBar_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.Common.InvalidPermissions.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "react", "OutSystemsReactView", "ContactsSampleApp.Common.InvalidPermissions.mvc$model", "ContactsSampleApp.Common.InvalidPermissions.mvc$controller", "ContactsSampleApp.Common.Layout.mvc$view", "OutSystemsReactWidgets", "ContactsSampleApp.Common.MenuIcon.mvc$view", "MobilePatterns.Content.BlankSlate.mvc$view", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$view"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, React, OSView, ContactsSampleApp_Common_InvalidPermissions_mvc_model, ContactsSampleApp_Common_InvalidPermissions_mvc_controller, ContactsSampleApp_Common_Layout_mvc_view, OSWidgets, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Content_BlankSlate_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.InvalidPermissions";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MobilePatterns.BaseTheme.css", "css/MobilePatterns.TabletTheme.css", "css/ContactsSampleApp.ContactsSampleApp.css", "css/MobilePatterns.TabletTheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ContactsSampleApp_Common_Layout_mvc_view, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Content_BlankSlate_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_Common_InvalidPermissions_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_Common_InvalidPermissions_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(ContactsSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: PlaceholderContent.Empty,
headerRight: PlaceholderContent.Empty,
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Content_BlankSlate_mvc_view, {
inputs: {
FullHeight: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "warning",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
name: "Icon1"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return ["You don\'t have permissions to view the required screen."];
}),
actions: PlaceholderContent.Empty
},
_dependencies: []
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_ContactsFlow_BottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ContactsSampleApp.Common.InvalidPermissions.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "ContactsSampleApp.languageResources", "ContactsSampleApp.Common.controller", "ContactsSampleApp.Common.InvalidPermissions.mvc$debugger"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, ContactsSampleAppLanguageResources, ContactsSampleApp_CommonController, ContactsSampleApp_Common_InvalidPermissions_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:c+zxB7GelUiC17aCJSfX3w:/NRWebFlows.c+zxB7GelUiC17aCJSfX3w:BF2CaJhGp5XpiB3Yr4_mGg", "ContactsSampleApp", "Common", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:dvmqVMo1XkadgTnuZbMAyg:/NRWebFlows.c+zxB7GelUiC17aCJSfX3w/NodesShownInESpaceTree.dvmqVMo1XkadgTnuZbMAyg:rn4sgm3UjNN0T5jv17gfhg", "ContactsSampleApp", "InvalidPermissions", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:dvmqVMo1XkadgTnuZbMAyg", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:c+zxB7GelUiC17aCJSfX3w", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ContactsSampleApp_CommonController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.Common.InvalidPermissions.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"ep1+crax0k+tD7V7EH9dZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"XhfR1y1ylk+Khld2jZqsyA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"2i8Wz6UeZ0+wJZFscgFbFA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"uPAO6oiGaEm1CimgEVpGqg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderContent"));
})(varBag.model, idService);
}
},
"bNXcnH7DK0aQjknATeuc4w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"RaCdlHCLd0qBa0g51F408g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"Imp7e0n+S0GY9mWDLq9J7w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon1"));
})(varBag.model, idService);
}
},
"zNRMaz78YUaJaXoUyjpOeg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"E64KtA+eCUqKdsXBqZPGJg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"dcO8TnuJ7U6gFsW6kTm4jg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
