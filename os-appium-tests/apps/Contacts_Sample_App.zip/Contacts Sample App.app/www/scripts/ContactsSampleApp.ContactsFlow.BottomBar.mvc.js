﻿define("ContactsSampleApp.ContactsFlow.BottomBar.mvc$model", ["OutSystems", "ContactsSampleApp.model", "MobilePatterns.Navigation.BottomBarItem.mvc$model"], function (OutSystems, ContactsSampleAppModel, MobilePatterns_Navigation_BottomBarItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ActiveItem", "activeItemIn", "ActiveItem", true, OS.Types.Integer, function () {
return 0;
}), 
this.attr("_activeItemInDataFetchStatus", "_activeItemInDataFetchStatus", "_activeItemInDataFetchStatus", true, OS.Types.Integer, function () {
return /*Fetched*/ 1;
})
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = MobilePatterns_Navigation_BottomBarItem_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("ActiveItem" in inputs) {
this.variables.activeItemIn = inputs.ActiveItem;
if("_activeItemInDataFetchStatus" in inputs) {
this.variables._activeItemInDataFetchStatus = inputs._activeItemInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.ContactsFlow.BottomBar.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "react", "OutSystemsReactView", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$model", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$controller", "OutSystemsReactWidgets", "MobilePatterns.Navigation.BottomBarItem.mvc$view"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, React, OSView, ContactsSampleApp_ContactsFlow_BottomBar_mvc_model, ContactsSampleApp_ContactsFlow_BottomBar_mvc_controller, OSWidgets, MobilePatterns_Navigation_BottomBarItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ContactsFlow.BottomBar";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [MobilePatterns_Navigation_BottomBarItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_BottomBar_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_BottomBar_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "bottom-bar-wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "bottom-bar ph",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Add", {}),
visible: true,
_idProps: {
service: idService,
name: "AddContactBottomBar"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Navigation_BottomBarItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "plus-circle",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["Add"];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Find", {}),
visible: true,
_idProps: {
service: idService,
name: "FindContactBottomBar"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Navigation_BottomBarItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "search",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["Find"];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Pick", {}),
visible: true,
_idProps: {
service: idService,
name: "PickContactBottomBar"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MobilePatterns_Navigation_BottomBarItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "user",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["Pick"];
})
},
_dependencies: []
})))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ContactsSampleApp.ContactsFlow.BottomBar.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "ContactsSampleApp.languageResources", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$controller.OnReady.AddActiveJS", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$debugger"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, ContactsSampleAppLanguageResources, ContactsSampleApp_ContactsFlow_BottomBar_mvc_controller_OnReady_AddActiveJS, ContactsSampleApp_ContactsFlow_BottomBar_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:B3nhUozeBESojVWQjS1mLA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.YOnS9SNoGUer5jSgVoXTaQ/ClientActions.B3nhUozeBESojVWQjS1mLA:94Exfq3H9Pvczo8jETjwCw", "ContactsSampleApp", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:tqd6xmyicU+tnCqxMvSZSg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:qcCm37_Ki0y0xV+9HEObCw", callContext.id);
controller.safeExecuteJSNode(ContactsSampleApp_ContactsFlow_BottomBar_mvc_controller_OnReady_AddActiveJS, "AddActive", "OnReady", {
Active: OS.DataTypes.JSConversions.basicTypeToJS(model.variables.activeItemIn, OS.Types.Integer, true)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:E3E2DcsSy02PN0UQd5T4xw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:B3nhUozeBESojVWQjS1mLA", callContext.id);
}

};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q:oTswzJAtrUammmPpEwGYvg", "ContactsSampleApp", "ContactsFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:YOnS9SNoGUer5jSgVoXTaQ:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.YOnS9SNoGUer5jSgVoXTaQ:ihaGHhmEpeEIhZlBmB3PuQ", "ContactsSampleApp", "BottomBar", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:YOnS9SNoGUer5jSgVoXTaQ", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ContactsFlow/BottomBar On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});
define("ContactsSampleApp.ContactsFlow.BottomBar.mvc$controller.OnReady.AddActiveJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if(document.querySelector('.bottom-bar').children[$parameters.Active]) {
    document.querySelector('.bottom-bar').children[$parameters.Active].classList.add("active");
}
};
});

define("ContactsSampleApp.ContactsFlow.BottomBar.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"qcCm37_Ki0y0xV+9HEObCw": {
getter: function (varBag, idService) {
return varBag.addActiveJSResult.value;
}
},
"AjYp__LcC0eJZcDCmo+HYQ": {
getter: function (varBag, idService) {
return varBag.model.variables.activeItemIn;
},
dataType: OS.Types.Integer
},
"vl2FUfT49EmKZYp6Q+Bi_A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AddContactBottomBar"));
})(varBag.model, idService);
}
},
"JsWH7RuFmUGC9NHeqXCPuA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"ZB0co_XU_kG9Ht4cj0t2Mg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"IIMHIu7uX0mzjGXPj_JjYw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("FindContactBottomBar"));
})(varBag.model, idService);
}
},
"argOEjRDfkyhNYKvsZdJFQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"ojhB5h5qQU6MIbbgwaDI6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"ujTD+Pc9wESympvRSqcQWw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PickContactBottomBar"));
})(varBag.model, idService);
}
},
"eW9mC6vM90+ON8q8QTbbiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"sqTXqmQDfEW5cyMMVRYi8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
