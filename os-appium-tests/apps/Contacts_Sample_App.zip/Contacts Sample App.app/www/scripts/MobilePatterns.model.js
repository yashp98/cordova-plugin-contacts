﻿define("MobilePatterns.model$Espace_ReferenceRecord", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$Espace_ReferenceRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var Espace_ReferenceRecord = (function (_super) {
__extends(Espace_ReferenceRecord, _super);
function Espace_ReferenceRecord(defaults) {
_super.apply(this, arguments);
}
Espace_ReferenceRecord.attributesToDeclare = function () {
return [
this.attr("Espace_Reference", "espace_ReferenceAttr", "Espace_Reference", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.Espace_ReferenceRec());
}, ServiceCenterModel.Espace_ReferenceRec)
].concat(_super.attributesToDeclare.call(this));
};
Espace_ReferenceRecord.fromStructure = function (str) {
return new Espace_ReferenceRecord(new Espace_ReferenceRecord.RecordClass({
espace_ReferenceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Espace_ReferenceRecord.IsAnonymousRecord = true;
Espace_ReferenceRecord.UniqueId = "00d9030e-cdd6-e653-c433-b8d974361bea";
Espace_ReferenceRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
Espace_ReferenceRecord.init();
return Espace_ReferenceRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.Espace_ReferenceRecord = Espace_ReferenceRecord;

});
define("MobilePatterns.model$Espace_ReferenceRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$Espace_ReferenceRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var Espace_ReferenceRecordList = (function (_super) {
__extends(Espace_ReferenceRecordList, _super);
function Espace_ReferenceRecordList(defaults) {
_super.apply(this, arguments);
}
Espace_ReferenceRecordList.RecordType = MobilePatternsModel.Espace_ReferenceRecord;
return Espace_ReferenceRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.Espace_ReferenceRecordList = Espace_ReferenceRecordList;

});
define("MobilePatterns.model$IntegerRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var IntegerRec = (function (_super) {
__extends(IntegerRec, _super);
function IntegerRec(defaults) {
_super.apply(this, arguments);
}
IntegerRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "Value", false, OS.Types.Integer, function () {
return 0;
})
].concat(_super.attributesToDeclare.call(this));
};
IntegerRec.fromStructure = function (str) {
return new IntegerRec(new IntegerRec.RecordClass({
valueAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
IntegerRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
IntegerRec.init();
return IntegerRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.IntegerRec = IntegerRec;

});
define("MobilePatterns.model$IntegerRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$IntegerRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var IntegerRecord = (function (_super) {
__extends(IntegerRecord, _super);
function IntegerRecord(defaults) {
_super.apply(this, arguments);
}
IntegerRecord.attributesToDeclare = function () {
return [
this.attr("Integer", "integerAttr", "Integer", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.IntegerRec());
}, MobilePatternsModel.IntegerRec)
].concat(_super.attributesToDeclare.call(this));
};
IntegerRecord.fromStructure = function (str) {
return new IntegerRecord(new IntegerRecord.RecordClass({
integerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
IntegerRecord.IsAnonymousRecord = true;
IntegerRecord.UniqueId = "7f4713a5-cd2e-d102-2e44-4e19c38677ac";
IntegerRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
IntegerRecord.init();
return IntegerRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.IntegerRecord = IntegerRecord;

});
define("MobilePatterns.model$IntegerRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$IntegerRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var IntegerRecordList = (function (_super) {
__extends(IntegerRecordList, _super);
function IntegerRecordList(defaults) {
_super.apply(this, arguments);
}
IntegerRecordList.RecordType = MobilePatternsModel.IntegerRecord;
return IntegerRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.IntegerRecordList = IntegerRecordList;

});
define("MobilePatterns.model$StepsRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StepsRec = (function (_super) {
__extends(StepsRec, _super);
function StepsRec(defaults) {
_super.apply(this, arguments);
}
StepsRec.attributesToDeclare = function () {
return [
this.attr("Steps", "stepsAttr", "Steps", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
StepsRec.fromStructure = function (str) {
return new StepsRec(new StepsRec.RecordClass({
stepsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StepsRec.generateFromLocalStorage = function () {
return false;
};
StepsRec.init();
return StepsRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.StepsRec = StepsRec;

});
define("MobilePatterns.model$StepsRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StepsRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StepsRecord = (function (_super) {
__extends(StepsRecord, _super);
function StepsRecord(defaults) {
_super.apply(this, arguments);
}
StepsRecord.attributesToDeclare = function () {
return [
this.attr("Steps", "stepsAttr", "Steps", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.StepsRec());
}, MobilePatternsModel.StepsRec)
].concat(_super.attributesToDeclare.call(this));
};
StepsRecord.fromStructure = function (str) {
return new StepsRecord(new StepsRecord.RecordClass({
stepsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StepsRecord.IsAnonymousRecord = true;
StepsRecord.UniqueId = "0d776a4e-191f-af32-1030-d5ce57aa4167";
StepsRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
StepsRecord.init();
return StepsRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.StepsRecord = StepsRecord;

});
define("MobilePatterns.model$AnimationTypeRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AnimationTypeRec = (function (_super) {
__extends(AnimationTypeRec, _super);
function AnimationTypeRec(defaults) {
_super.apply(this, arguments);
}
AnimationTypeRec.attributesToDeclare = function () {
return [
this.attr("AnimationType", "animationTypeAttr", "AnimationType", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
AnimationTypeRec.fromStructure = function (str) {
return new AnimationTypeRec(new AnimationTypeRec.RecordClass({
animationTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AnimationTypeRec.generateFromLocalStorage = function () {
return false;
};
AnimationTypeRec.init();
return AnimationTypeRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.AnimationTypeRec = AnimationTypeRec;

});
define("MobilePatterns.model$AnimationTypeRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AnimationTypeRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AnimationTypeRecord = (function (_super) {
__extends(AnimationTypeRecord, _super);
function AnimationTypeRecord(defaults) {
_super.apply(this, arguments);
}
AnimationTypeRecord.attributesToDeclare = function () {
return [
this.attr("AnimationType", "animationTypeAttr", "AnimationType", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.AnimationTypeRec());
}, MobilePatternsModel.AnimationTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
AnimationTypeRecord.fromStructure = function (str) {
return new AnimationTypeRecord(new AnimationTypeRecord.RecordClass({
animationTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AnimationTypeRecord.IsAnonymousRecord = true;
AnimationTypeRecord.UniqueId = "78b6d6ed-7d52-800a-8a68-e7d796ec6850";
AnimationTypeRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
AnimationTypeRecord.init();
return AnimationTypeRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.AnimationTypeRecord = AnimationTypeRecord;

});
define("MobilePatterns.model$AnimationTypeRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AnimationTypeRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AnimationTypeRecordList = (function (_super) {
__extends(AnimationTypeRecordList, _super);
function AnimationTypeRecordList(defaults) {
_super.apply(this, arguments);
}
AnimationTypeRecordList.RecordType = MobilePatternsModel.AnimationTypeRecord;
return AnimationTypeRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.AnimationTypeRecordList = AnimationTypeRecordList;

});
define("MobilePatterns.model$MessageStatusRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MessageStatusRec = (function (_super) {
__extends(MessageStatusRec, _super);
function MessageStatusRec(defaults) {
_super.apply(this, arguments);
}
MessageStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, OS.Types.Integer, function () {
return 0;
}), 
this.attr("Type", "typeAttr", "Type", true, OS.Types.Text, function () {
return "";
}), 
this.attr("Order", "orderAttr", "Order", true, OS.Types.Integer, function () {
return 0;
})
].concat(_super.attributesToDeclare.call(this));
};
MessageStatusRec.generateFromLocalStorage = function () {
return false;
};
MessageStatusRec.init();
return MessageStatusRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.MessageStatusRec = MessageStatusRec;

});
define("MobilePatterns.model$AutoplayRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AutoplayRec = (function (_super) {
__extends(AutoplayRec, _super);
function AutoplayRec(defaults) {
_super.apply(this, arguments);
}
AutoplayRec.attributesToDeclare = function () {
return [
this.attr("Autoplay", "autoplayAttr", "Autoplay", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
AutoplayRec.fromStructure = function (str) {
return new AutoplayRec(new AutoplayRec.RecordClass({
autoplayAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AutoplayRec.generateFromLocalStorage = function () {
return false;
};
AutoplayRec.init();
return AutoplayRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.AutoplayRec = AutoplayRec;

});
define("MobilePatterns.model$AutoplayRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AutoplayRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AutoplayRecord = (function (_super) {
__extends(AutoplayRecord, _super);
function AutoplayRecord(defaults) {
_super.apply(this, arguments);
}
AutoplayRecord.attributesToDeclare = function () {
return [
this.attr("Autoplay", "autoplayAttr", "Autoplay", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.AutoplayRec());
}, MobilePatternsModel.AutoplayRec)
].concat(_super.attributesToDeclare.call(this));
};
AutoplayRecord.fromStructure = function (str) {
return new AutoplayRecord(new AutoplayRecord.RecordClass({
autoplayAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AutoplayRecord.IsAnonymousRecord = true;
AutoplayRecord.UniqueId = "c6831d06-e579-de4e-dbcf-59e128b60b13";
AutoplayRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
AutoplayRecord.init();
return AutoplayRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.AutoplayRecord = AutoplayRecord;

});
define("MobilePatterns.model$AutoplayRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AutoplayRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AutoplayRecordList = (function (_super) {
__extends(AutoplayRecordList, _super);
function AutoplayRecordList(defaults) {
_super.apply(this, arguments);
}
AutoplayRecordList.RecordType = MobilePatternsModel.AutoplayRecord;
return AutoplayRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.AutoplayRecordList = AutoplayRecordList;

});
define("MobilePatterns.model$StuffRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StuffRec = (function (_super) {
__extends(StuffRec, _super);
function StuffRec(defaults) {
_super.apply(this, arguments);
}
StuffRec.attributesToDeclare = function () {
return [
this.attr("label", "labelAttr", "label", false, OS.Types.Text, function () {
return "";
}), 
this.attr("value", "valueAttr", "value", false, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
StuffRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
StuffRec.init();
return StuffRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.StuffRec = StuffRec;

});
define("MobilePatterns.model$SpeedRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var SpeedRec = (function (_super) {
__extends(SpeedRec, _super);
function SpeedRec(defaults) {
_super.apply(this, arguments);
}
SpeedRec.attributesToDeclare = function () {
return [
this.attr("Speed", "speedAttr", "Speed", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
SpeedRec.fromStructure = function (str) {
return new SpeedRec(new SpeedRec.RecordClass({
speedAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpeedRec.generateFromLocalStorage = function () {
return false;
};
SpeedRec.init();
return SpeedRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.SpeedRec = SpeedRec;

});
define("MobilePatterns.model$MessageStatusRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MessageStatusRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MessageStatusRecord = (function (_super) {
__extends(MessageStatusRecord, _super);
function MessageStatusRecord(defaults) {
_super.apply(this, arguments);
}
MessageStatusRecord.attributesToDeclare = function () {
return [
this.attr("MessageStatus", "messageStatusAttr", "MessageStatus", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.MessageStatusRec());
}, MobilePatternsModel.MessageStatusRec)
].concat(_super.attributesToDeclare.call(this));
};
MessageStatusRecord.fromStructure = function (str) {
return new MessageStatusRecord(new MessageStatusRecord.RecordClass({
messageStatusAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MessageStatusRecord.IsAnonymousRecord = true;
MessageStatusRecord.UniqueId = "63c659b6-dc55-4b0b-4f81-d60382bf5fd6";
MessageStatusRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
MessageStatusRecord.init();
return MessageStatusRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.MessageStatusRecord = MessageStatusRecord;

});
define("MobilePatterns.model$MessageStatusRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MessageStatusRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MessageStatusRecordList = (function (_super) {
__extends(MessageStatusRecordList, _super);
function MessageStatusRecordList(defaults) {
_super.apply(this, arguments);
}
MessageStatusRecordList.RecordType = MobilePatternsModel.MessageStatusRecord;
return MessageStatusRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.MessageStatusRecordList = MessageStatusRecordList;

});
define("MobilePatterns.model$MenuActionRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MenuActionRec = (function (_super) {
__extends(MenuActionRec, _super);
function MenuActionRec(defaults) {
_super.apply(this, arguments);
}
MenuActionRec.attributesToDeclare = function () {
return [
this.attr("MenuAction", "menuActionAttr", "MenuAction", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
MenuActionRec.fromStructure = function (str) {
return new MenuActionRec(new MenuActionRec.RecordClass({
menuActionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuActionRec.generateFromLocalStorage = function () {
return false;
};
MenuActionRec.init();
return MenuActionRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.MenuActionRec = MenuActionRec;

});
define("MobilePatterns.model$MenuActionRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MenuActionRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MenuActionRecord = (function (_super) {
__extends(MenuActionRecord, _super);
function MenuActionRecord(defaults) {
_super.apply(this, arguments);
}
MenuActionRecord.attributesToDeclare = function () {
return [
this.attr("MenuAction", "menuActionAttr", "MenuAction", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.MenuActionRec());
}, MobilePatternsModel.MenuActionRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuActionRecord.fromStructure = function (str) {
return new MenuActionRecord(new MenuActionRecord.RecordClass({
menuActionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuActionRecord.IsAnonymousRecord = true;
MenuActionRecord.UniqueId = "954cd123-1210-e70f-33f1-84017bf580ac";
MenuActionRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
MenuActionRecord.init();
return MenuActionRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.MenuActionRecord = MenuActionRecord;

});
define("MobilePatterns.model$MenuActionRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MenuActionRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MenuActionRecordList = (function (_super) {
__extends(MenuActionRecordList, _super);
function MenuActionRecordList(defaults) {
_super.apply(this, arguments);
}
MenuActionRecordList.RecordType = MobilePatternsModel.MenuActionRecord;
return MenuActionRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.MenuActionRecordList = MenuActionRecordList;

});
define("MobilePatterns.model$StackedCardsPositionRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionRec = (function (_super) {
__extends(StackedCardsPositionRec, _super);
function StackedCardsPositionRec(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
StackedCardsPositionRec.fromStructure = function (str) {
return new StackedCardsPositionRec(new StackedCardsPositionRec.RecordClass({
labelAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StackedCardsPositionRec.generateFromLocalStorage = function () {
return false;
};
StackedCardsPositionRec.init();
return StackedCardsPositionRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.StackedCardsPositionRec = StackedCardsPositionRec;

});
define("MobilePatterns.model$StackedCardsPositionList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StackedCardsPositionRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionList = (function (_super) {
__extends(StackedCardsPositionList, _super);
function StackedCardsPositionList(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionList.RecordType = MobilePatternsModel.StackedCardsPositionRec;
return StackedCardsPositionList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.StackedCardsPositionList = StackedCardsPositionList;

});
define("MobilePatterns.model$ColumnBreakRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColumnBreakRec = (function (_super) {
__extends(ColumnBreakRec, _super);
function ColumnBreakRec(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRec.attributesToDeclare = function () {
return [
this.attr("ColumnBreak", "columnBreakAttr", "ColumnBreak", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
ColumnBreakRec.fromStructure = function (str) {
return new ColumnBreakRec(new ColumnBreakRec.RecordClass({
columnBreakAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColumnBreakRec.generateFromLocalStorage = function () {
return false;
};
ColumnBreakRec.init();
return ColumnBreakRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.ColumnBreakRec = ColumnBreakRec;

});
define("MobilePatterns.model$ColumnBreakList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$ColumnBreakRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColumnBreakList = (function (_super) {
__extends(ColumnBreakList, _super);
function ColumnBreakList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakList.RecordType = MobilePatternsModel.ColumnBreakRec;
return ColumnBreakList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.ColumnBreakList = ColumnBreakList;

});
define("MobilePatterns.model$ColorRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColorRec = (function (_super) {
__extends(ColorRec, _super);
function ColorRec(defaults) {
_super.apply(this, arguments);
}
ColorRec.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
ColorRec.fromStructure = function (str) {
return new ColorRec(new ColorRec.RecordClass({
colorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColorRec.generateFromLocalStorage = function () {
return false;
};
ColorRec.init();
return ColorRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.ColorRec = ColorRec;

});
define("MobilePatterns.model$ColorList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$ColorRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColorList = (function (_super) {
__extends(ColorList, _super);
function ColorList(defaults) {
_super.apply(this, arguments);
}
ColorList.RecordType = MobilePatternsModel.ColorRec;
return ColorList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.ColorList = ColorList;

});
define("MobilePatterns.model$StuffRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StuffRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StuffRecord = (function (_super) {
__extends(StuffRecord, _super);
function StuffRecord(defaults) {
_super.apply(this, arguments);
}
StuffRecord.attributesToDeclare = function () {
return [
this.attr("Stuff", "stuffAttr", "Stuff", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.StuffRec());
}, MobilePatternsModel.StuffRec)
].concat(_super.attributesToDeclare.call(this));
};
StuffRecord.fromStructure = function (str) {
return new StuffRecord(new StuffRecord.RecordClass({
stuffAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StuffRecord.IsAnonymousRecord = true;
StuffRecord.UniqueId = "3f3ee9a8-7cc3-ad91-c4e4-582f79c6b52b";
StuffRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
StuffRecord.init();
return StuffRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.StuffRecord = StuffRecord;

});
define("MobilePatterns.model$Espace_VersionList", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$Espace_VersionRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var Espace_VersionList = (function (_super) {
__extends(Espace_VersionList, _super);
function Espace_VersionList(defaults) {
_super.apply(this, arguments);
}
Espace_VersionList.RecordType = ServiceCenterModel.Espace_VersionRec;
return Espace_VersionList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.Espace_VersionList = Espace_VersionList;

});
define("MobilePatterns.model$MenuActionList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MenuActionRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MenuActionList = (function (_super) {
__extends(MenuActionList, _super);
function MenuActionList(defaults) {
_super.apply(this, arguments);
}
MenuActionList.RecordType = MobilePatternsModel.MenuActionRec;
return MenuActionList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.MenuActionList = MenuActionList;

});
define("MobilePatterns.model$MasterDetailItemRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MasterDetailItemRec = (function (_super) {
__extends(MasterDetailItemRec, _super);
function MasterDetailItemRec(defaults) {
_super.apply(this, arguments);
}
MasterDetailItemRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}), 
this.attr("Title", "titleAttr", "Title", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Description", "descriptionAttr", "Description", false, OS.Types.Text, function () {
return "";
}), 
this.attr("ImageUrl", "imageUrlAttr", "ImageUrl", false, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
MasterDetailItemRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
MasterDetailItemRec.init();
return MasterDetailItemRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.MasterDetailItemRec = MasterDetailItemRec;

});
define("MobilePatterns.model$PositionRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var PositionRec = (function (_super) {
__extends(PositionRec, _super);
function PositionRec(defaults) {
_super.apply(this, arguments);
}
PositionRec.attributesToDeclare = function () {
return [
this.attr("Position", "positionAttr", "Position", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
PositionRec.fromStructure = function (str) {
return new PositionRec(new PositionRec.RecordClass({
positionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PositionRec.generateFromLocalStorage = function () {
return false;
};
PositionRec.init();
return PositionRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.PositionRec = PositionRec;

});
define("MobilePatterns.model$PositionRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$PositionRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var PositionRecord = (function (_super) {
__extends(PositionRecord, _super);
function PositionRecord(defaults) {
_super.apply(this, arguments);
}
PositionRecord.attributesToDeclare = function () {
return [
this.attr("Position", "positionAttr", "Position", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.PositionRec());
}, MobilePatternsModel.PositionRec)
].concat(_super.attributesToDeclare.call(this));
};
PositionRecord.fromStructure = function (str) {
return new PositionRecord(new PositionRecord.RecordClass({
positionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PositionRecord.IsAnonymousRecord = true;
PositionRecord.UniqueId = "5f28219a-5e30-fb90-023f-cbc295513e7c";
PositionRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
PositionRecord.init();
return PositionRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.PositionRecord = PositionRecord;

});
define("MobilePatterns.model$PositionRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$PositionRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var PositionRecordList = (function (_super) {
__extends(PositionRecordList, _super);
function PositionRecordList(defaults) {
_super.apply(this, arguments);
}
PositionRecordList.RecordType = MobilePatternsModel.PositionRecord;
return PositionRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.PositionRecordList = PositionRecordList;

});
define("MobilePatterns.model$MasterDetailItemRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MasterDetailItemRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MasterDetailItemRecord = (function (_super) {
__extends(MasterDetailItemRecord, _super);
function MasterDetailItemRecord(defaults) {
_super.apply(this, arguments);
}
MasterDetailItemRecord.attributesToDeclare = function () {
return [
this.attr("MasterDetailItem", "masterDetailItemAttr", "MasterDetailItem", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.MasterDetailItemRec());
}, MobilePatternsModel.MasterDetailItemRec)
].concat(_super.attributesToDeclare.call(this));
};
MasterDetailItemRecord.fromStructure = function (str) {
return new MasterDetailItemRecord(new MasterDetailItemRecord.RecordClass({
masterDetailItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MasterDetailItemRecord.IsAnonymousRecord = true;
MasterDetailItemRecord.UniqueId = "c7e749f2-1266-5bf8-3f6d-7b6126e9e92e";
MasterDetailItemRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
MasterDetailItemRecord.init();
return MasterDetailItemRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.MasterDetailItemRecord = MasterDetailItemRecord;

});
define("MobilePatterns.model$MasterDetailItemRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MasterDetailItemRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MasterDetailItemRecordList = (function (_super) {
__extends(MasterDetailItemRecordList, _super);
function MasterDetailItemRecordList(defaults) {
_super.apply(this, arguments);
}
MasterDetailItemRecordList.RecordType = MobilePatternsModel.MasterDetailItemRecord;
return MasterDetailItemRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.MasterDetailItemRecordList = MasterDetailItemRecordList;

});
define("MobilePatterns.model$EspaceList", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$EspaceRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var EspaceList = (function (_super) {
__extends(EspaceList, _super);
function EspaceList(defaults) {
_super.apply(this, arguments);
}
EspaceList.RecordType = ServiceCenterModel.EspaceRec;
return EspaceList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.EspaceList = EspaceList;

});
define("MobilePatterns.model$MessageStatusList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MessageStatusRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MessageStatusList = (function (_super) {
__extends(MessageStatusList, _super);
function MessageStatusList(defaults) {
_super.apply(this, arguments);
}
MessageStatusList.RecordType = MobilePatternsModel.MessageStatusRec;
return MessageStatusList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.MessageStatusList = MessageStatusList;

});
define("MobilePatterns.model$StackedCardsPositionRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StackedCardsPositionRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionRecord = (function (_super) {
__extends(StackedCardsPositionRecord, _super);
function StackedCardsPositionRecord(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionRecord.attributesToDeclare = function () {
return [
this.attr("StackedCardsPosition", "stackedCardsPositionAttr", "StackedCardsPosition", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.StackedCardsPositionRec());
}, MobilePatternsModel.StackedCardsPositionRec)
].concat(_super.attributesToDeclare.call(this));
};
StackedCardsPositionRecord.fromStructure = function (str) {
return new StackedCardsPositionRecord(new StackedCardsPositionRecord.RecordClass({
stackedCardsPositionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StackedCardsPositionRecord.IsAnonymousRecord = true;
StackedCardsPositionRecord.UniqueId = "967cb657-10fd-1a34-6ebf-0b0d8dbea56b";
StackedCardsPositionRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
StackedCardsPositionRecord.init();
return StackedCardsPositionRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.StackedCardsPositionRecord = StackedCardsPositionRecord;

});
define("MobilePatterns.model$StackedCardsPositionRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StackedCardsPositionRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionRecordList = (function (_super) {
__extends(StackedCardsPositionRecordList, _super);
function StackedCardsPositionRecordList(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionRecordList.RecordType = MobilePatternsModel.StackedCardsPositionRecord;
return StackedCardsPositionRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.StackedCardsPositionRecordList = StackedCardsPositionRecordList;

});
define("MobilePatterns.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.attributesToDeclare = function () {
return [
this.attr("ChangeEventDuringSlide", "changeEventDuringSlideAttr", "ChangeEventDuringSlide", false, OS.Types.Boolean, function () {
return false;
}), 
this.attr("ShowPips", "showPipsAttr", "ShowPips", false, OS.Types.Boolean, function () {
return false;
}), 
this.attr("InitialIntervalEnd", "initialIntervalEndAttr", "InitialIntervalEnd", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("InitialIntervalStart", "initialIntervalStartAttr", "InitialIntervalStart", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("MaxValue", "maxValueAttr", "MaxValue", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("MinValue", "minValueAttr", "MinValue", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("PipsStep", "pipsStepAttr", "PipsStep", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("Step", "stepAttr", "Step", false, OS.Types.Integer, function () {
return 0;
})
].concat(_super.attributesToDeclare.call(this));
};
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.IsAnonymousRecord = true;
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.UniqueId = "845b5f28-a6e4-8277-561b-d4b51c5e965a";
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.init();
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord = BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord;

});
define("MobilePatterns.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList.RecordType = MobilePatternsModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord;
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList = BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList;

});
define("MobilePatterns.model$EspaceRecord", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$EspaceRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var EspaceRecord = (function (_super) {
__extends(EspaceRecord, _super);
function EspaceRecord(defaults) {
_super.apply(this, arguments);
}
EspaceRecord.attributesToDeclare = function () {
return [
this.attr("Espace", "espaceAttr", "Espace", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.EspaceRec());
}, ServiceCenterModel.EspaceRec)
].concat(_super.attributesToDeclare.call(this));
};
EspaceRecord.fromStructure = function (str) {
return new EspaceRecord(new EspaceRecord.RecordClass({
espaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EspaceRecord.IsAnonymousRecord = true;
EspaceRecord.UniqueId = "a702e171-772a-9b89-c17e-2544ab6d1d29";
EspaceRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
EspaceRecord.init();
return EspaceRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.EspaceRecord = EspaceRecord;

});
define("MobilePatterns.model$EspaceRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$EspaceRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var EspaceRecordList = (function (_super) {
__extends(EspaceRecordList, _super);
function EspaceRecordList(defaults) {
_super.apply(this, arguments);
}
EspaceRecordList.RecordType = MobilePatternsModel.EspaceRecord;
return EspaceRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.EspaceRecordList = EspaceRecordList;

});
define("MobilePatterns.model$UserRecord", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$UserRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var UserRecord = (function (_super) {
__extends(UserRecord, _super);
function UserRecord(defaults) {
_super.apply(this, arguments);
}
UserRecord.attributesToDeclare = function () {
return [
this.attr("User", "userAttr", "User", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.UserRec());
}, ServiceCenterModel.UserRec)
].concat(_super.attributesToDeclare.call(this));
};
UserRecord.fromStructure = function (str) {
return new UserRecord(new UserRecord.RecordClass({
userAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UserRecord.IsAnonymousRecord = true;
UserRecord.UniqueId = "ced01335-8a82-a813-f1d9-a5108f17ce79";
UserRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
UserRecord.init();
return UserRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.UserRecord = UserRecord;

});
define("MobilePatterns.model$UserRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$UserRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var UserRecordList = (function (_super) {
__extends(UserRecordList, _super);
function UserRecordList(defaults) {
_super.apply(this, arguments);
}
UserRecordList.RecordType = MobilePatternsModel.UserRecord;
return UserRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.UserRecordList = UserRecordList;

});
define("MobilePatterns.model$ActivationRecord", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$ActivationRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ActivationRecord = (function (_super) {
__extends(ActivationRecord, _super);
function ActivationRecord(defaults) {
_super.apply(this, arguments);
}
ActivationRecord.attributesToDeclare = function () {
return [
this.attr("Activation", "activationAttr", "Activation", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.ActivationRec());
}, ServiceCenterModel.ActivationRec)
].concat(_super.attributesToDeclare.call(this));
};
ActivationRecord.fromStructure = function (str) {
return new ActivationRecord(new ActivationRecord.RecordClass({
activationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ActivationRecord.IsAnonymousRecord = true;
ActivationRecord.UniqueId = "886d2dd6-1407-08fe-8df9-6213b169d599";
ActivationRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ActivationRecord.init();
return ActivationRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.ActivationRecord = ActivationRecord;

});
define("MobilePatterns.model$ActivationRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$ActivationRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ActivationRecordList = (function (_super) {
__extends(ActivationRecordList, _super);
function ActivationRecordList(defaults) {
_super.apply(this, arguments);
}
ActivationRecordList.RecordType = MobilePatternsModel.ActivationRecord;
return ActivationRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.ActivationRecordList = ActivationRecordList;

});
define("MobilePatterns.model$Espace_VersionRecord", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$Espace_VersionRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var Espace_VersionRecord = (function (_super) {
__extends(Espace_VersionRecord, _super);
function Espace_VersionRecord(defaults) {
_super.apply(this, arguments);
}
Espace_VersionRecord.attributesToDeclare = function () {
return [
this.attr("Espace_Version", "espace_VersionAttr", "Espace_Version", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.Espace_VersionRec());
}, ServiceCenterModel.Espace_VersionRec)
].concat(_super.attributesToDeclare.call(this));
};
Espace_VersionRecord.fromStructure = function (str) {
return new Espace_VersionRecord(new Espace_VersionRecord.RecordClass({
espace_VersionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Espace_VersionRecord.IsAnonymousRecord = true;
Espace_VersionRecord.UniqueId = "a30dbf03-0b81-3bab-70c6-b26430e8789b";
Espace_VersionRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
Espace_VersionRecord.init();
return Espace_VersionRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.Espace_VersionRecord = Espace_VersionRecord;

});
define("MobilePatterns.model$Espace_VersionRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$Espace_VersionRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var Espace_VersionRecordList = (function (_super) {
__extends(Espace_VersionRecordList, _super);
function Espace_VersionRecordList(defaults) {
_super.apply(this, arguments);
}
Espace_VersionRecordList.RecordType = MobilePatternsModel.Espace_VersionRecord;
return Espace_VersionRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.Espace_VersionRecordList = Espace_VersionRecordList;

});
define("MobilePatterns.model$AlertRec", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AlertRec = (function (_super) {
__extends(AlertRec, _super);
function AlertRec(defaults) {
_super.apply(this, arguments);
}
AlertRec.attributesToDeclare = function () {
return [
this.attr("Alert", "alertAttr", "Alert", true, OS.Types.Text, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
AlertRec.fromStructure = function (str) {
return new AlertRec(new AlertRec.RecordClass({
alertAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AlertRec.generateFromLocalStorage = function () {
return false;
};
AlertRec.init();
return AlertRec;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.AlertRec = AlertRec;

});
define("MobilePatterns.model$AlertRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AlertRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AlertRecord = (function (_super) {
__extends(AlertRecord, _super);
function AlertRecord(defaults) {
_super.apply(this, arguments);
}
AlertRecord.attributesToDeclare = function () {
return [
this.attr("Alert", "alertAttr", "Alert", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.AlertRec());
}, MobilePatternsModel.AlertRec)
].concat(_super.attributesToDeclare.call(this));
};
AlertRecord.fromStructure = function (str) {
return new AlertRecord(new AlertRecord.RecordClass({
alertAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AlertRecord.IsAnonymousRecord = true;
AlertRecord.UniqueId = "9ca6a18c-c49c-a724-6c44-c0f7c2cef62a";
AlertRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
AlertRecord.init();
return AlertRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.AlertRecord = AlertRecord;

});
define("MobilePatterns.model$AnimationTypeList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AnimationTypeRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AnimationTypeList = (function (_super) {
__extends(AnimationTypeList, _super);
function AnimationTypeList(defaults) {
_super.apply(this, arguments);
}
AnimationTypeList.RecordType = MobilePatternsModel.AnimationTypeRec;
return AnimationTypeList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.AnimationTypeList = AnimationTypeList;

});
define("MobilePatterns.model$ColorRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$ColorRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColorRecord = (function (_super) {
__extends(ColorRecord, _super);
function ColorRecord(defaults) {
_super.apply(this, arguments);
}
ColorRecord.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.ColorRec());
}, MobilePatternsModel.ColorRec)
].concat(_super.attributesToDeclare.call(this));
};
ColorRecord.fromStructure = function (str) {
return new ColorRecord(new ColorRecord.RecordClass({
colorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColorRecord.IsAnonymousRecord = true;
ColorRecord.UniqueId = "c47826b7-e423-2fbf-8907-84243715f5a8";
ColorRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ColorRecord.init();
return ColorRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.ColorRecord = ColorRecord;

});
define("MobilePatterns.model$ColorRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$ColorRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColorRecordList = (function (_super) {
__extends(ColorRecordList, _super);
function ColorRecordList(defaults) {
_super.apply(this, arguments);
}
ColorRecordList.RecordType = MobilePatternsModel.ColorRecord;
return ColorRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.ColorRecordList = ColorRecordList;

});
define("MobilePatterns.model$AlertList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AlertRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AlertList = (function (_super) {
__extends(AlertList, _super);
function AlertList(defaults) {
_super.apply(this, arguments);
}
AlertList.RecordType = MobilePatternsModel.AlertRec;
return AlertList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.AlertList = AlertList;

});
define("MobilePatterns.model$ColumnBreakRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$ColumnBreakRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecord = (function (_super) {
__extends(ColumnBreakRecord, _super);
function ColumnBreakRecord(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecord.attributesToDeclare = function () {
return [
this.attr("ColumnBreak", "columnBreakAttr", "ColumnBreak", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.ColumnBreakRec());
}, MobilePatternsModel.ColumnBreakRec)
].concat(_super.attributesToDeclare.call(this));
};
ColumnBreakRecord.fromStructure = function (str) {
return new ColumnBreakRecord(new ColumnBreakRecord.RecordClass({
columnBreakAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColumnBreakRecord.IsAnonymousRecord = true;
ColumnBreakRecord.UniqueId = "b6adbbf4-e08b-ad29-75a6-f8f796279b71";
ColumnBreakRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ColumnBreakRecord.init();
return ColumnBreakRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.ColumnBreakRecord = ColumnBreakRecord;

});
define("MobilePatterns.model$ColumnBreakRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$ColumnBreakRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecordList = (function (_super) {
__extends(ColumnBreakRecordList, _super);
function ColumnBreakRecordList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecordList.RecordType = MobilePatternsModel.ColumnBreakRecord;
return ColumnBreakRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.ColumnBreakRecordList = ColumnBreakRecordList;

});
define("MobilePatterns.model$Espace_ReferenceList", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$Espace_ReferenceRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var Espace_ReferenceList = (function (_super) {
__extends(Espace_ReferenceList, _super);
function Espace_ReferenceList(defaults) {
_super.apply(this, arguments);
}
Espace_ReferenceList.RecordType = ServiceCenterModel.Espace_ReferenceRec;
return Espace_ReferenceList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.Espace_ReferenceList = Espace_ReferenceList;

});
define("MobilePatterns.model$StuffList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StuffRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StuffList = (function (_super) {
__extends(StuffList, _super);
function StuffList(defaults) {
_super.apply(this, arguments);
}
StuffList.RecordType = MobilePatternsModel.StuffRec;
return StuffList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.StuffList = StuffList;

});
define("MobilePatterns.model$ActivationList", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$ActivationRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var ActivationList = (function (_super) {
__extends(ActivationList, _super);
function ActivationList(defaults) {
_super.apply(this, arguments);
}
ActivationList.RecordType = ServiceCenterModel.ActivationRec;
return ActivationList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.ActivationList = ActivationList;

});
define("MobilePatterns.model$StepsList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StepsRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StepsList = (function (_super) {
__extends(StepsList, _super);
function StepsList(defaults) {
_super.apply(this, arguments);
}
StepsList.RecordType = MobilePatternsModel.StepsRec;
return StepsList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.StepsList = StepsList;

});
define("MobilePatterns.model$SpeedRecord", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$SpeedRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var SpeedRecord = (function (_super) {
__extends(SpeedRecord, _super);
function SpeedRecord(defaults) {
_super.apply(this, arguments);
}
SpeedRecord.attributesToDeclare = function () {
return [
this.attr("Speed", "speedAttr", "Speed", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.SpeedRec());
}, MobilePatternsModel.SpeedRec)
].concat(_super.attributesToDeclare.call(this));
};
SpeedRecord.fromStructure = function (str) {
return new SpeedRecord(new SpeedRecord.RecordClass({
speedAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpeedRecord.IsAnonymousRecord = true;
SpeedRecord.UniqueId = "d15ba8cc-56cc-5ee5-8bd8-acaffd974239";
SpeedRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
SpeedRecord.init();
return SpeedRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.SpeedRecord = SpeedRecord;

});
define("MobilePatterns.model$PositionList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$PositionRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var PositionList = (function (_super) {
__extends(PositionList, _super);
function PositionList(defaults) {
_super.apply(this, arguments);
}
PositionList.RecordType = MobilePatternsModel.PositionRec;
return PositionList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.PositionList = PositionList;

});
define("MobilePatterns.model$IntegerList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$IntegerRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var IntegerList = (function (_super) {
__extends(IntegerList, _super);
function IntegerList(defaults) {
_super.apply(this, arguments);
}
IntegerList.RecordType = MobilePatternsModel.IntegerRec;
return IntegerList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.IntegerList = IntegerList;

});
define("MobilePatterns.model$AutoplayList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AutoplayRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AutoplayList = (function (_super) {
__extends(AutoplayList, _super);
function AutoplayList(defaults) {
_super.apply(this, arguments);
}
AutoplayList.RecordType = MobilePatternsModel.AutoplayRec;
return AutoplayList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.AutoplayList = AutoplayList;

});
define("MobilePatterns.model$MasterDetailItemList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$MasterDetailItemRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var MasterDetailItemList = (function (_super) {
__extends(MasterDetailItemList, _super);
function MasterDetailItemList(defaults) {
_super.apply(this, arguments);
}
MasterDetailItemList.RecordType = MobilePatternsModel.MasterDetailItemRec;
return MasterDetailItemList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.MasterDetailItemList = MasterDetailItemList;

});
define("MobilePatterns.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord", ["exports", "OutSystems", "MobilePatterns.model"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.attributesToDeclare = function () {
return [
this.attr("ChangeEventDuringSlide", "changeEventDuringSlideAttr", "ChangeEventDuringSlide", false, OS.Types.Boolean, function () {
return false;
}), 
this.attr("ShowPips", "showPipsAttr", "ShowPips", false, OS.Types.Boolean, function () {
return false;
}), 
this.attr("InitialValue", "initialValueAttr", "InitialValue", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("MaxValue", "maxValueAttr", "MaxValue", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("MinValue", "minValueAttr", "MinValue", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("PipsStep", "pipsStepAttr", "PipsStep", false, OS.Types.Integer, function () {
return 0;
}), 
this.attr("Step", "stepAttr", "Step", false, OS.Types.Integer, function () {
return 0;
})
].concat(_super.attributesToDeclare.call(this));
};
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.IsAnonymousRecord = true;
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.UniqueId = "e57d7c30-9592-d9b0-9e76-04ad507fe534";
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.init();
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord;
})(OS.DataTypes.GenericRecord);
MobilePatternsModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord = BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord;

});
define("MobilePatterns.model$SpeedList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$SpeedRec"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var SpeedList = (function (_super) {
__extends(SpeedList, _super);
function SpeedList(defaults) {
_super.apply(this, arguments);
}
SpeedList.RecordType = MobilePatternsModel.SpeedRec;
return SpeedList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.SpeedList = SpeedList;

});
define("MobilePatterns.model$StepsRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StepsRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StepsRecordList = (function (_super) {
__extends(StepsRecordList, _super);
function StepsRecordList(defaults) {
_super.apply(this, arguments);
}
StepsRecordList.RecordType = MobilePatternsModel.StepsRecord;
return StepsRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.StepsRecordList = StepsRecordList;

});
define("MobilePatterns.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList.RecordType = MobilePatternsModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord;
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList = BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList;

});
define("MobilePatterns.model$UserList", ["exports", "OutSystems", "ServiceCenter.model", "MobilePatterns.model", "ServiceCenter.model$UserRec", "MobilePatterns.referencesHealth", "MobilePatterns.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, MobilePatternsModel) {
var OS = OutSystems.Internal;
var UserList = (function (_super) {
__extends(UserList, _super);
function UserList(defaults) {
_super.apply(this, arguments);
}
UserList.RecordType = ServiceCenterModel.UserRec;
return UserList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.UserList = UserList;

});
define("MobilePatterns.model$AlertRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$AlertRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var AlertRecordList = (function (_super) {
__extends(AlertRecordList, _super);
function AlertRecordList(defaults) {
_super.apply(this, arguments);
}
AlertRecordList.RecordType = MobilePatternsModel.AlertRecord;
return AlertRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.AlertRecordList = AlertRecordList;

});
define("MobilePatterns.model$SpeedRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$SpeedRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var SpeedRecordList = (function (_super) {
__extends(SpeedRecordList, _super);
function SpeedRecordList(defaults) {
_super.apply(this, arguments);
}
SpeedRecordList.RecordType = MobilePatternsModel.SpeedRecord;
return SpeedRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.SpeedRecordList = SpeedRecordList;

});
define("MobilePatterns.model$StuffRecordList", ["exports", "OutSystems", "MobilePatterns.model", "MobilePatterns.model$StuffRecord"], function (exports, OutSystems, MobilePatternsModel) {
var OS = OutSystems.Internal;
var StuffRecordList = (function (_super) {
__extends(StuffRecordList, _super);
function StuffRecordList(defaults) {
_super.apply(this, arguments);
}
StuffRecordList.RecordType = MobilePatternsModel.StuffRecord;
return StuffRecordList;
})(OS.DataTypes.GenericRecordList);
MobilePatternsModel.StuffRecordList = StuffRecordList;

});
define("MobilePatterns.model", ["exports", "OutSystems"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var MobilePatternsModel = exports;
Object.defineProperty(MobilePatternsModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"];
}
});

MobilePatternsModel.staticEntities = {};
MobilePatternsModel.staticEntities.animationType = {};
var getAnimationTypeRecord = function (record) {
return MobilePatternsModel.module.staticEntities["0463d449-6834-40d5-817b-3d74d1a71bb2"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "topToBottom", {
get: function () {
return getAnimationTypeRecord("2d5a98f9-381b-4ff8-9219-085bc35dfc44");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "bounce", {
get: function () {
return getAnimationTypeRecord("3c3ad352-52fc-43c5-ae3a-f8d651bfa094");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "fadeIn", {
get: function () {
return getAnimationTypeRecord("69814f09-c20b-4d55-b06a-7231a5515d2c");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "scaleDown", {
get: function () {
return getAnimationTypeRecord("7d8fd3a6-eac4-4ae8-b865-18f5711814cb");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "scale", {
get: function () {
return getAnimationTypeRecord("8a8e0e8b-0e5a-407c-9739-4942e1c708e8");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "spinner", {
get: function () {
return getAnimationTypeRecord("b1e2a22f-cd5a-49a8-83e2-a82471745aea");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "bottomToTop", {
get: function () {
return getAnimationTypeRecord("b71cef18-b0ee-4e9b-8b98-5700b6c6b9e4");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "rightToLeft", {
get: function () {
return getAnimationTypeRecord("b7a58aaa-e1f6-4bbb-9557-5fb4742ef542");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.animationType, "leftToRight", {
get: function () {
return getAnimationTypeRecord("f4c21a73-5f0c-4d9e-a9e6-7053b68c2cea");
}
});

MobilePatternsModel.staticEntities.speed = {};
var getSpeedRecord = function (record) {
return MobilePatternsModel.module.staticEntities["0a5cc4ae-b54f-4ea3-9ace-9f49c7724606"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.speed, "fast", {
get: function () {
return getSpeedRecord("4fb2b6d9-70ff-415d-a09d-4ee05adda5c4");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.speed, "normal", {
get: function () {
return getSpeedRecord("93b9215f-8fb1-4f08-8555-9b0125b18f51");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.speed, "slow", {
get: function () {
return getSpeedRecord("b2c67d31-506d-42e7-890e-0e4f29234ae6");
}
});

MobilePatternsModel.staticEntities.color = {};
var getColorRecord = function (record) {
return MobilePatternsModel.module.staticEntities["4a5b3b8d-44e7-4c03-9b89-453fa2feee20"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.color, "white", {
get: function () {
return getColorRecord("05505a13-1fe9-4adf-9845-11368c74e98b");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "blue", {
get: function () {
return getColorRecord("0772a1e6-baf6-4f8d-9b63-aef9b16bec31");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "black", {
get: function () {
return getColorRecord("26ba2ced-6bce-452f-b33a-7874dc80d8d1");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "violet", {
get: function () {
return getColorRecord("3269784e-d6b0-46db-a0b5-5a9a64ee0e41");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "none", {
get: function () {
return getColorRecord("342260d0-74a4-44fd-9e9d-f0505a330244");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "orange", {
get: function () {
return getColorRecord("833f5f9b-2325-4b92-9285-e14aa1a17c25");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "red", {
get: function () {
return getColorRecord("94682198-3a70-458e-9889-3eef131d1b00");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "primaryColor", {
get: function () {
return getColorRecord("9bd951e1-c94c-434b-85cb-a4cde3ffe638");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "green", {
get: function () {
return getColorRecord("ad00278a-a271-46de-ac30-9f99c87f97a4");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.color, "grey", {
get: function () {
return getColorRecord("f986e894-0745-46fd-aa63-7680b5fd9234");
}
});

MobilePatternsModel.staticEntities.stackedCardsPosition = {};
var getStackedCardsPositionRecord = function (record) {
return MobilePatternsModel.module.staticEntities["71865eb4-55fe-40a5-bc7f-45b005a3a0b5"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.stackedCardsPosition, "bottom", {
get: function () {
return getStackedCardsPositionRecord("2e9dd7c6-b9a7-404f-b207-9a3da7fb05ed");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.stackedCardsPosition, "top", {
get: function () {
return getStackedCardsPositionRecord("5766b18f-82ef-49f1-9476-cf8f49249f25");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.stackedCardsPosition, "none", {
get: function () {
return getStackedCardsPositionRecord("89cf1ed9-b6fd-4e0a-af41-cfd79db935d7");
}
});

MobilePatternsModel.staticEntities.autoplay = {};
var getAutoplayRecord = function (record) {
return MobilePatternsModel.module.staticEntities["82aa58b4-8bbb-4d19-92b6-2944affad02c"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.autoplay, "disabled", {
get: function () {
return getAutoplayRecord("1ffcca5d-17d0-492e-9e9e-b8addde7fd80");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.autoplay, "slow", {
get: function () {
return getAutoplayRecord("4167f601-5731-452d-9653-1be7f25199f1");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.autoplay, "fast", {
get: function () {
return getAutoplayRecord("41b9ec04-2023-4f87-b953-0c01713d1992");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.autoplay, "normal", {
get: function () {
return getAutoplayRecord("e3033046-77ba-49cd-928a-5d831105f349");
}
});

MobilePatternsModel.staticEntities.position = {};
var getPositionRecord = function (record) {
return MobilePatternsModel.module.staticEntities["83c073e8-bac2-4122-9772-aa6e122a5d36"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.position, "top", {
get: function () {
return getPositionRecord("3bbcac35-309e-49a8-bf1b-a3c66e1ef3cd");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "left", {
get: function () {
return getPositionRecord("4d70c81a-67bd-4a1f-a21a-c6aa13d0f364");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "bottomRight", {
get: function () {
return getPositionRecord("73459c44-0160-4454-8ad0-c9bd44778a61");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "bottomLeft", {
get: function () {
return getPositionRecord("7352570c-243a-4f05-b6d1-608495931118");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "right", {
get: function () {
return getPositionRecord("bf43697b-2483-4855-a6c2-0a786bab472f");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "topLeft", {
get: function () {
return getPositionRecord("c1d22c62-5a36-4d69-b188-02d62b8fe7c4");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "topRight", {
get: function () {
return getPositionRecord("d14d8aae-f1c9-4538-a4a9-91a2690e6d92");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "center", {
get: function () {
return getPositionRecord("dcc9ffa2-34a7-4097-86d0-dde224907425");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.position, "bottom", {
get: function () {
return getPositionRecord("fb8d90f9-5432-4678-932b-f468c00d3361");
}
});

MobilePatternsModel.staticEntities.alert = {};
var getAlertRecord = function (record) {
return MobilePatternsModel.module.staticEntities["924486c0-dd9a-46ea-ad74-2cf9ac0c84d9"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.alert, "success", {
get: function () {
return getAlertRecord("4aac6381-179c-477f-a0d2-8aa7c0e2ece5");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.alert, "error", {
get: function () {
return getAlertRecord("85c06001-4d3a-4a08-b18f-4f9ebdc60d33");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.alert, "info", {
get: function () {
return getAlertRecord("e7c6b907-0f56-481e-b267-eb69bd92ed26");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.alert, "warning", {
get: function () {
return getAlertRecord("ed710523-9de5-47b6-b3ac-736fb4848c04");
}
});

MobilePatternsModel.staticEntities.menuAction = {};
var getMenuActionRecord = function (record) {
return MobilePatternsModel.module.staticEntities["9cc12883-06ab-4cf0-9997-ede7c6c02d67"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.menuAction, "menu", {
get: function () {
return getMenuActionRecord("55ba18a9-cd6b-45dd-99ce-9081ee1387ea");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.menuAction, "auto", {
get: function () {
return getMenuActionRecord("6c0c753a-86f4-4e76-9781-6e821c850c72");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.menuAction, "hidden", {
get: function () {
return getMenuActionRecord("86c9d356-be64-46a1-b027-843ab93b4aea");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.menuAction, "back", {
get: function () {
return getMenuActionRecord("f2db3c50-4c38-4ee7-a770-aa9476cb0d68");
}
});

MobilePatternsModel.staticEntities.messageStatus = {};
var getMessageStatusRecord = function (record) {
return MobilePatternsModel.module.staticEntities["c1015fc0-c81c-40cc-a046-bf99cf21a280"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.messageStatus, "hidden", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMessageStatusRecord("2f2266ed-167a-45db-ac12-ca1e3cfa0fd2"));
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.messageStatus, "read", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMessageStatusRecord("34f4ff93-8e4e-4933-baae-8b9f122eb3cc"));
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.messageStatus, "sent", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMessageStatusRecord("a1f1ba89-bd84-4943-a94c-a84ea4a142bf"));
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.messageStatus, "received", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMessageStatusRecord("c90b88d0-8f7d-484a-8d17-b0d1b9795a94"));
}
});

MobilePatternsModel.staticEntities.columnBreak = {};
var getColumnBreakRecord = function (record) {
return MobilePatternsModel.module.staticEntities["cce6ac21-942a-492f-8b46-64c5e6ea057b"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.columnBreak, "breakMiddle", {
get: function () {
return getColumnBreakRecord("3b01fc99-ef23-4043-8771-f88660720e01");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.columnBreak, "breakAll", {
get: function () {
return getColumnBreakRecord("43788f73-6893-4396-b67a-04a6ff690e74");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.columnBreak, "breakNone", {
get: function () {
return getColumnBreakRecord("69e6c609-9e8a-45a7-b006-45b92275ec49");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.columnBreak, "breakLast", {
get: function () {
return getColumnBreakRecord("6b3725c8-8951-48ed-a977-cbfaf003c896");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.columnBreak, "breakFirst", {
get: function () {
return getColumnBreakRecord("8c8b45b6-c1af-4b11-907e-3c8a5ce161e2");
}
});

MobilePatternsModel.staticEntities.steps = {};
var getStepsRecord = function (record) {
return MobilePatternsModel.module.staticEntities["e4dd8e9f-a620-4df5-b619-9b8a771be5a3"][record];
};
Object.defineProperty(MobilePatternsModel.staticEntities.steps, "next", {
get: function () {
return getStepsRecord("03e9ec31-9b26-4304-b532-29aa077d99ea");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.steps, "past", {
get: function () {
return getStepsRecord("5452e8a1-02ca-4ff2-8d74-bff1512fc4a3");
}
});

Object.defineProperty(MobilePatternsModel.staticEntities.steps, "active", {
get: function () {
return getStepsRecord("dbde9903-8367-49e7-8302-f6758c190844");
}
});

});
