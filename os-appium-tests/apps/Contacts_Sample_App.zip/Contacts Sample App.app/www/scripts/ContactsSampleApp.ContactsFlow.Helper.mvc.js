﻿define("ContactsSampleApp.ContactsFlow.Helper.mvc$model", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.Common.Layout.mvc$model", "ContactsSampleApp.Common.MenuIcon.mvc$model", "MobilePatterns.Content.Card.mvc$model", "MobilePatterns.Content.CardSectioned.mvc$model", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$model"], function (OutSystems, ContactsSampleAppModel, ContactsSampleApp_Common_Layout_mvcModel, ContactsSampleApp_Common_MenuIcon_mvcModel, MobilePatterns_Content_Card_mvcModel, MobilePatterns_Content_CardSectioned_mvcModel, ContactsSampleApp_ContactsFlow_BottomBar_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((ContactsSampleApp_Common_Layout_mvcModel.hasValidationWidgets || ContactsSampleApp_Common_MenuIcon_mvcModel.hasValidationWidgets) || MobilePatterns_Content_Card_mvcModel.hasValidationWidgets) || MobilePatterns_Content_CardSectioned_mvcModel.hasValidationWidgets) || ContactsSampleApp_ContactsFlow_BottomBar_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.ContactsFlow.Helper.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "react", "OutSystemsReactView", "ContactsSampleApp.ContactsFlow.Helper.mvc$model", "ContactsSampleApp.ContactsFlow.Helper.mvc$controller", "ContactsSampleApp.Common.Layout.mvc$view", "OutSystemsReactWidgets", "ContactsSampleApp.Common.MenuIcon.mvc$view", "MobilePatterns.Content.Card.mvc$view", "MobilePatterns.Content.CardSectioned.mvc$view", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$view"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, React, OSView, ContactsSampleApp_ContactsFlow_Helper_mvc_model, ContactsSampleApp_ContactsFlow_Helper_mvc_controller, ContactsSampleApp_Common_Layout_mvc_view, OSWidgets, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Content_Card_mvc_view, MobilePatterns_Content_CardSectioned_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ContactsFlow.Helper";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MobilePatterns.BaseTheme.css", "css/MobilePatterns.TabletTheme.css", "css/ContactsSampleApp.ContactsSampleApp.css", "css/MobilePatterns.TabletTheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ContactsSampleApp_Common_Layout_mvc_view, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Content_Card_mvc_view, MobilePatterns_Content_CardSectioned_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Helper_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Helper_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(ContactsSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: new PlaceholderContent(function () {
return ["Helper"];
}),
headerRight: PlaceholderContent.Empty,
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Content_Card_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "KqqL+Q0ruEGxAVDsENQdzw"
},
text: ["In the screens of this sample app, there are buttons which help filling the information needed for the tests. Below, you can find information about them. Additionally, there\'s a link for the test plan."],
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
}), React.createElement(MobilePatterns_Content_Card_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return ["add test plan"];
})
},
_dependencies: []
}), React.createElement(MobilePatterns_Content_CardSectioned_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "YPdJ0ZR0_UeJedMxJlhAFg"
},
text: ["Create Contact"],
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "BKqQDiJp_kScJwXrl++h1g"
},
text: ["Button Name1 "],
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "EZaAxcBcoUuPcazQeDlJNQ"
},
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "AYvwVsJgIkiy_yol0KmdsQ"
},
text: ["First Name = Test app - Name1 ", React.DOM.br(), "Last Name = Last1", React.DOM.br(), "Phone = +351000000000", React.DOM.br(), "Email = email1@outsystems.com "],
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "AhdEO_NROU2BJt7xHo9ZvA"
},
text: ["Button Name1 (change phone) "],
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "s87VQcB+k0efTYlVvifKpQ"
},
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "64CFIxZMQES19AzrgeGV4A"
},
text: ["First Name = Test app - Name1 ", React.DOM.br(), "Last Name = Last1", React.DOM.br(), "Phone = +351111111111", React.DOM.br(), "Email = email1@outsystems.com "],
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "MhCm1b5SvUevyKpXOMst0A"
},
text: ["Button Name1 (change email)"],
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "OvFYfmiIakW7IGP6ralvew"
},
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "iksFoLDtdUmXJFVwN9jwhg"
},
text: ["First Name = Test app - Name1 ", React.DOM.br(), "Last Name = Last1", React.DOM.br(), "Phone = +351000000000", React.DOM.br(), "Email = email2@outsystems.com "],
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "HqAjCAzp5UaGiVLT7GrKLQ"
},
text: ["Button Name1 (change phone and email) "],
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "34mOrtZBBkW3tQdChWH0Pg"
},
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "js7fPp9Hd02rmbYzsnBxrg"
},
text: ["First Name = Test app - Name1 ", React.DOM.br(), "Last Name = Last1", React.DOM.br(), "Phone = +351222222222", React.DOM.br(), "Email = email3@outsystems.com "],
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "AGkgU24DZUiY43nzLlZd_A"
},
text: ["Button Name 2 (no phone) "],
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "eqn5ueLqxUO2po_d0Ng85A"
},
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "JdLGkFfAS0SYcNvrKh9Znw"
},
text: ["First Name = Test app - Name2 ", React.DOM.br(), "Last Name = Last2", React.DOM.br(), "Phone = <empty>", React.DOM.br(), "Email = email1@outsystems.com "],
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "xwoLXUPAtkW27ElHsgIEyg"
},
text: ["Button Only Phone "],
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "udF+Oq4wjEeWDPXRXLux9Q"
},
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "CMRZAGJSr0+l0uKwYMS5yg"
},
text: ["First Name = ", React.DOM.br(), "Last Name = ", React.DOM.br(), "Phone = +351000000000 ", React.DOM.br(), "Email =  "],
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "lcsJOGJhm0iyFBXAOvtWww"
},
text: ["Button 111 (strange format) "],
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "9DypmWuApEGW8qcWkZ1IYA"
},
visible: true,
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "m4dgs+22IUmfpTO5btqGHg"
},
text: ["First Name = Test app - 111", React.DOM.br(), "Last Name = 222", React.DOM.br(), "Phone = +#,N12#", React.DOM.br(), "Email = 333"],
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
footer: PlaceholderContent.Empty
},
_dependencies: []
}), React.createElement(MobilePatterns_Content_CardSectioned_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "36",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "y_i68DE1M06dN7LblzNCaA"
},
text: ["Find Contact"],
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "oKh+geUpKUyh5pyJFjQWqw"
},
text: ["Button Name1 "],
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "3rh3nK_bV0KYJoA6Q7zhFg"
},
visible: true,
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "fRrkjvDcg0mY_g_10xCaZg"
},
text: ["Search Parameter = Test app - Name1", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "42"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "Q4_r7giP50COjXG0DM+Dqw"
},
text: ["Button Last1"],
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "Ji0pMO065Eq1_mXf_yBGhA"
},
visible: true,
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "IexxTHpL9UqcY3DaMZBtXg"
},
text: ["Search Parameter = Last1", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "ZGH+n0blj0y5OqYfctsjSQ"
},
text: ["Button +351"],
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "SAYnCqR0BUCBUHdvZd3tEQ"
},
visible: true,
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "YoHsD1bae0GC2aEJB4TekQ"
},
text: ["Search Parameter = +351", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "y3j4gvqQmE+mYQ9gIpe2Rw"
},
text: ["Button email3@outsystems.com"],
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "kN_Het08D0CiNi2JA_YkFg"
},
visible: true,
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "eSJ6CY6E8kq8Yc668DrRdw"
},
text: ["Search Parameter = email3@ousystems.com", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "53"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "v+y3UknnREa4jNaLrFGdgA"
},
text: ["Button 1"],
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "DimTBYUtEEm7XNjxkWHWJw"
},
visible: true,
_idProps: {
service: idService,
uuid: "56"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "KyPKwCrjRku4LxMofQUG+w"
},
text: ["Search Parameter = 1", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "57"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "58"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "QY0l1bzQ60uuqhDcHV+4hw"
},
text: ["Button Name3"],
_idProps: {
service: idService,
uuid: "59"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "ctkYJywf8EOLBu0_hoDujQ"
},
visible: true,
_idProps: {
service: idService,
uuid: "60"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "ewdyGVhhHEG0QqFbw7bUJA"
},
text: ["Search Parameter = Test app - Name3", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "62"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "5BLcNl208U2HRSKS1Urv2Q"
},
text: ["Button Name2"],
_idProps: {
service: idService,
uuid: "63"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "CZ6pIgEPzkusTq3tnhufgg"
},
visible: true,
_idProps: {
service: idService,
uuid: "64"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "B1G4e+Kj1kCP8jfCMqdTIg"
},
text: ["Search Parameter = Name2", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "65"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "66"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "8Cj4+qglrkiKinr+4UijXw"
},
text: ["Button email3"],
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "W7zNxVPU6EaUfy3pGFmuiA"
},
visible: true,
_idProps: {
service: idService,
uuid: "68"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "W9XxeUXeU0+4tha7pzkmSA"
},
text: ["Search Parameter = email3", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "69"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "70"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "BEWpHb8GAEuZ_VF4RQAT+g"
},
text: ["Button Non existent contact"],
_idProps: {
service: idService,
uuid: "71"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "z9951ejdb0CJeUcPTVrRXA"
},
visible: true,
_idProps: {
service: idService,
uuid: "72"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "jKS2JUivREeAyUqurTcEzg"
},
text: ["Search Parameter = non existent contact", React.DOM.br(), "Multiple Contacts: true "],
_idProps: {
service: idService,
uuid: "73"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
footer: PlaceholderContent.Empty
},
_dependencies: []
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_ContactsFlow_BottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "74",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ContactsSampleApp.ContactsFlow.Helper.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "ContactsSampleApp.languageResources", "ContactsSampleApp.ContactsFlow.controller", "ContactsSampleApp.ContactsFlow.Helper.mvc$debugger"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, ContactsSampleAppLanguageResources, ContactsSampleApp_ContactsFlowController, ContactsSampleApp_ContactsFlow_Helper_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q:oTswzJAtrUammmPpEwGYvg", "ContactsSampleApp", "ContactsFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:6yakDRpI_EeQ+Cs6hCNXww:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.6yakDRpI_EeQ+Cs6hCNXww:UD7em4SAe6hia5BaApuzSQ", "ContactsSampleApp", "Helper", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:6yakDRpI_EeQ+Cs6hCNXww", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ContactsSampleApp_ContactsFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.ContactsFlow.Helper.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"128GMKWODkadADOTUic8xw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"cbvlgus9Ik+1IMn_eEuHsw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"3m4N_eMDUUm9cncuQEjYgA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"ks4MZeqVtk2zZ_uPNQd2Ag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderContent"));
})(varBag.model, idService);
}
},
"TC+OAoofIkySXnetguxT_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"tcqqPxTOWkmbNjK0zB1DiA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"iLeUsunTHUCc6lrUDhOCqQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"F35EE8IAE0qvmnrdXKEO0A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"+v3uGBXcOU6Tt3ac5RBdAA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"GWagjTnKvUiTPOfI9it45w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
},
"SsvD4FYZ8UejgzWJLoynFg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"c5i57MTkqUq07ianNIhDYQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"35pWpgzs0UabOraT01Iz5Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
},
"WlntR0lfxUWxvwq9uveGUg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
