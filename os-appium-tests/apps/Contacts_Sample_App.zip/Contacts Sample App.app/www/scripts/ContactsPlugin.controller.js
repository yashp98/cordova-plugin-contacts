﻿define("ContactsPlugin.controller$AddToContacts", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.controller", "CommonPlugin.model", "ContactsPlugin.controller$AddToContacts.AddToContactsJSJS", "CommonPlugin.model$ErrorRec", "ContactsPlugin.referencesHealth", "ContactsPlugin.referencesHealth$CommonPlugin", "ContactsPlugin.controller$CheckContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsPluginController, CommonPluginModel, ContactsPlugin_controller_AddToContacts_AddToContactsJSJS) {
var OS = OutSystems.Internal;
ContactsPluginController.default.addToContacts$Action = function (firstNameIn, lastNameIn, phoneIn, emailIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsPlugin.AddToContacts$vars"))());
vars.value.firstNameInLocal = firstNameIn;
vars.value.lastNameInLocal = lastNameIn;
vars.value.phoneInLocal = phoneIn;
vars.value.emailInLocal = emailIn;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var checkContactsPluginVar = new OS.DataTypes.VariableHolder();
var addToContactsJSJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsPlugin.AddToContacts$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.checkContactsPluginVar = checkContactsPluginVar;
varBag.addToContactsJSJSResult = addToContactsJSJSResult;
varBag.outVars = outVars;
OutSystemsDebugger.push("xoAkWcGZckm7VUL+oSmYgg:Oe6xWW6s9E6Jv+upiE6xNQ:/ClientActionFlows.Oe6xWW6s9E6Jv+upiE6xNQ:PYEULKNLKqI0MVAmx0bOXA", "ContactsPlugin", "AddToContacts", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:zRb93Vc6DEmvGKzhztAkSQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:4_ho4lh5Qk+a_D9vdrJ4+Q", callContext.id);
// Execute Action: CheckContactsPlugin
checkContactsPluginVar.value = ContactsPluginController.default.checkContactsPlugin$Action(callContext);

// Is Contacts Plugin available?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:8R0jY19nF0+DvZOvxlsSfw", callContext.id) && checkContactsPluginVar.value.isAvailableOut)) {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:fne0oxQN1UapXaKR4OTNlA", callContext.id);
// Use this action to add a contact to the device's address book.
return controller.safeExecuteAsyncJSNode(ContactsPlugin_controller_AddToContacts_AddToContactsJSJS, "AddToContactsJS", "AddToContacts", {
FirstName: OS.DataTypes.JSConversions.basicTypeToJS(vars.value.firstNameInLocal, OS.Types.Text, true),
LastName: OS.DataTypes.JSConversions.basicTypeToJS(vars.value.lastNameInLocal, OS.Types.Text, true),
Email: OS.DataTypes.JSConversions.basicTypeToJS(vars.value.emailInLocal, OS.Types.Text, true),
Phone: OS.DataTypes.JSConversions.basicTypeToJS(vars.value.phoneInLocal, OS.Types.Text, true),
Success: OS.DataTypes.JSConversions.basicTypeToJS(false, OS.Types.Boolean, true),
ErrorMessage: OS.DataTypes.JSConversions.basicTypeToJS("", OS.Types.Text, true)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ContactsPlugin.AddToContacts$addToContactsJSJSResult"))();
jsNodeResult.successOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.Success, OS.Types.Boolean);
jsNodeResult.errorMessageOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ErrorMessage, OS.Types.Text);
return jsNodeResult;
}, {}, {}).then(function (results) {
addToContactsJSJSResult.value = results;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:6wITza8pKEKYZVnAybr+aw", callContext.id) && addToContactsJSJSResult.value.successOut)) {
// Set Values
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:M_PzHuVgv0SJ0eUn9LORZA", callContext.id);
// Error.ErrorMessage = ""
outVars.value.errorOut.errorMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:M_PzHuVgv0SJ0eUn9LORZA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Success = AddToContactsJS.Success
outVars.value.successOut = addToContactsJSJSResult.value.successOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:M_PzHuVgv0SJ0eUn9LORZA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = 0
outVars.value.errorOut.errorCodeAttr = "0";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:SPtFLEizeE2wZPMh0uUqxQ", callContext.id);
} else {
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:4B5_XwfqREO6gMRoBoWICg", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:4B5_XwfqREO6gMRoBoWICg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = AddToContactsJS.ErrorMessage
outVars.value.errorOut.errorMessageAttr = addToContactsJSJSResult.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:4B5_XwfqREO6gMRoBoWICg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = 3
outVars.value.errorOut.errorCodeAttr = "3";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:LVdo8Y78hk6dmLF9z4AJ9Q", callContext.id);
}

});
} else {
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:3_U9F1XVDEuKraxNlFixcw", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:3_U9F1XVDEuKraxNlFixcw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = CheckContactsPlugin.Error.ErrorMessage
outVars.value.errorOut.errorMessageAttr = checkContactsPluginVar.value.errorOut.errorMessageAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:3_U9F1XVDEuKraxNlFixcw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = CheckContactsPlugin.Error.ErrorCode
outVars.value.errorOut.errorCodeAttr = checkContactsPluginVar.value.errorOut.errorCodeAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:3m9CzAHoh0S4aNpS7cwRSQ", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("AddToContacts.AddToContacts", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:F2zmZ50abkWaELM+NNhXtA", callContext.id);
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:myvsR5lf+UiDiWg55PtevA", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:myvsR5lf+UiDiWg55PtevA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.errorOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:myvsR5lf+UiDiWg55PtevA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = -1
outVars.value.errorOut.errorCodeAttr = (-1).toString();
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:9qaFgDKyCUOOuvy5gdg7TA", callContext.id);
return OS.Flow.returnAsync(outVars.value);

});
}

throw ex;
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("xoAkWcGZckm7VUL+oSmYgg:Oe6xWW6s9E6Jv+upiE6xNQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("xoAkWcGZckm7VUL+oSmYgg:Oe6xWW6s9E6Jv+upiE6xNQ", callContext.id);
throw ex;

});
};
var controller = ContactsPluginController.default;
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.AddToContacts$vars", [{
name: "FirstName",
attrName: "firstNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "LastName",
attrName: "lastNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Phone",
attrName: "phoneInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Email",
attrName: "emailInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.AddToContacts$addToContactsJSJSResult", [{
name: "Success",
attrName: "successOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.AddToContacts$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Error",
attrName: "errorOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new CommonPluginModel.ErrorRec();
},
complexType: CommonPluginModel.ErrorRec
}]);
ContactsPluginController.default.clientActionProxies.addToContacts$Action = function (firstNameIn, lastNameIn, phoneIn, emailIn) {
firstNameIn = (firstNameIn === undefined) ? "" : firstNameIn;
lastNameIn = (lastNameIn === undefined) ? "" : lastNameIn;
phoneIn = (phoneIn === undefined) ? "" : phoneIn;
emailIn = (emailIn === undefined) ? "" : emailIn;
return controller.executeActionInsideJSNode(ContactsPluginController.default.addToContacts$Action.bind(controller, OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(firstNameIn, OS.Types.Text), OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(lastNameIn, OS.Types.Text), OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(phoneIn, OS.Types.Text), OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(emailIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataTypes.JSConversions.basicTypeToJS(actionResults.successOut, OS.Types.Boolean, true),
Error: actionResults.errorOut
};
});
};
});
define("ContactsPlugin.controller$AddToContacts.AddToContactsJSJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
function onSuccess(contact) {
    $parameters.Success = true;
    $parameters.ErrorMessage = "";
    $resolve(); 
}

function onError(contactError) {
    $parameters.Success = false;
    $parameters.ErrorMessage = "Could not save contact";
    $resolve();
}

var name = new ContactName();
name.givenName = $parameters.FirstName;
name.familyName = $parameters.LastName;

var phoneNumbers = [];
phoneNumbers[0] = new ContactField('mobile', $parameters.Phone, true);

var emails = [];
emails[0] = new ContactField('work', $parameters.Email, true);

var contact = navigator.contacts.create();
contact.name = name;
contact.phoneNumbers = phoneNumbers;
contact.emails = emails;

// save to device
contact.save(onSuccess, onError);
});
};
});

define("ContactsPlugin.controller$CheckContactsPlugin", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.controller", "CommonPlugin.controller", "CommonPlugin.model", "ContactsPlugin.controller$CheckContactsPlugin.IsPluginAvailableJSJS", "CommonPlugin.controller$IsCordovaDefined", "ContactsPlugin.referencesHealth", "ContactsPlugin.referencesHealth$CommonPlugin", "CommonPlugin.model$ErrorRec"], function (exports, OutSystems, ContactsPluginModel, ContactsPluginController, CommonPluginController, CommonPluginModel, ContactsPlugin_controller_CheckContactsPlugin_IsPluginAvailableJSJS) {
var OS = OutSystems.Internal;
ContactsPluginController.default.checkContactsPlugin$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var isCordovaDefinedVar = new OS.DataTypes.VariableHolder();
var isPluginAvailableJSJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsPlugin.CheckContactsPlugin$outVars"))());
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.isCordovaDefinedVar = isCordovaDefinedVar;
varBag.isPluginAvailableJSJSResult = isPluginAvailableJSJSResult;
varBag.outVars = outVars;
try {try {OutSystemsDebugger.push("xoAkWcGZckm7VUL+oSmYgg:nMRel6wHbE2sc2ApRw1noA:/ClientActionFlows.nMRel6wHbE2sc2ApRw1noA:RzlJsOy8YSyTT_utRGWSDw", "ContactsPlugin", "CheckContactsPlugin", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:GKhdR5RkmU+qpL6jqT6qKw", callContext.id);
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:bpKPu1M4gUWUEUwLXI47pg", callContext.id);
// Execute Action: IsCordovaDefined
isCordovaDefinedVar.value = CommonPluginController.default.isCordovaDefined$Action(callContext);

if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:qmt6eAi2V0C8gtVYavqGdw", callContext.id) && isCordovaDefinedVar.value.isLoadedOut)) {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:YWLhNpojiEaEwcqA4siuaQ", callContext.id);
// Validates if the plugin is currently available. Useful to verify if the current application has the plugin installed.
isPluginAvailableJSJSResult.value = controller.safeExecuteJSNode(ContactsPlugin_controller_CheckContactsPlugin_IsPluginAvailableJSJS, "IsPluginAvailableJS", "CheckContactsPlugin", {
IsAvailable: OS.DataTypes.JSConversions.basicTypeToJS(false, OS.Types.Boolean, true)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ContactsPlugin.CheckContactsPlugin$isPluginAvailableJSJSResult"))();
jsNodeResult.isAvailableOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.IsAvailable, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:s5x+UYCbwEqQ0fQ63xIpZg", callContext.id) && isPluginAvailableJSJSResult.value.isAvailableOut)) {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:AQfRHwIekker_4qN7EqRqg", callContext.id);
// IsAvailable = IsPluginAvailableJS.IsAvailable
outVars.value.isAvailableOut = isPluginAvailableJSJSResult.value.isAvailableOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:AQfRHwIekker_4qN7EqRqg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorCode = 0
outVars.value.errorOut.errorCodeAttr = "0";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:AQfRHwIekker_4qN7EqRqg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorMessage = ""
outVars.value.errorOut.errorMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:UjfkuoRFu0yAXq78vFfhRw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:UvTo+zM+VEm_0o2kdVkCfQ", callContext.id);
// Error.ErrorCode = 2
outVars.value.errorOut.errorCodeAttr = "2";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:UvTo+zM+VEm_0o2kdVkCfQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = "Contacts Plugin is unavailable"
outVars.value.errorOut.errorMessageAttr = "Contacts Plugin is unavailable";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:UvTo+zM+VEm_0o2kdVkCfQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsAvailable = False
outVars.value.isAvailableOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:pe1k0vAmB0esWLCo2fXSpA", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:r4FxpFvgH0W6idon0W4MuA", callContext.id);
// Error.ErrorCode = 1
outVars.value.errorOut.errorCodeAttr = "1";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:r4FxpFvgH0W6idon0W4MuA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = "Cordova is not available"
outVars.value.errorOut.errorMessageAttr = "Cordova is not available";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:r4FxpFvgH0W6idon0W4MuA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsAvailable = False
outVars.value.isAvailableOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:QZH9Rtq51kWW7WHNwdWJCA", callContext.id);
}

} catch (ex) {
(function () {
OS.Logger.trace("CheckContactsPlugin.CheckContactsPlugin", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:sScw4LsKOUOVlXk1BrZY5g", callContext.id);
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:z0Skc1GpV0ePPejCCD8w9Q", callContext.id);
// IsAvailable = False
outVars.value.isAvailableOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:z0Skc1GpV0ePPejCCD8w9Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorCode = -1
outVars.value.errorOut.errorCodeAttr = (-1).toString();
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:z0Skc1GpV0ePPejCCD8w9Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.errorOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:o40KrX6HMkq5BxQ7cLcSNw", callContext.id);
return outVars.value;

}

throw ex;
})();
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xoAkWcGZckm7VUL+oSmYgg:nMRel6wHbE2sc2ApRw1noA", callContext.id);
}

};
var controller = ContactsPluginController.default;
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.CheckContactsPlugin$isPluginAvailableJSJSResult", [{
name: "IsAvailable",
attrName: "isAvailableOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.CheckContactsPlugin$outVars", [{
name: "IsAvailable",
attrName: "isAvailableOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Error",
attrName: "errorOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new CommonPluginModel.ErrorRec();
},
complexType: CommonPluginModel.ErrorRec
}]);
ContactsPluginController.default.clientActionProxies.checkContactsPlugin$Action = function () {
return controller.executeActionInsideJSNode(ContactsPluginController.default.checkContactsPlugin$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsAvailable: OS.DataTypes.JSConversions.basicTypeToJS(actionResults.isAvailableOut, OS.Types.Boolean, true),
Error: actionResults.errorOut
};
});
};
});
define("ContactsPlugin.controller$CheckContactsPlugin.IsPluginAvailableJSJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.IsAvailable = !!window.cordova && !!navigator.contacts;
};
});

define("ContactsPlugin.controller$FindContact", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.controller", "CommonPlugin.model", "ContactsPlugin.controller$FindContact.FindContactJSJS", "CommonPlugin.model$ErrorRec", "ContactsPlugin.referencesHealth", "ContactsPlugin.referencesHealth$CommonPlugin", "ContactsPlugin.controller$CheckContactsPlugin", "ContactsPlugin.model$ContactList"], function (exports, OutSystems, ContactsPluginModel, ContactsPluginController, CommonPluginModel, ContactsPlugin_controller_FindContact_FindContactJSJS) {
var OS = OutSystems.Internal;
ContactsPluginController.default.findContact$Action = function (searchParameterIn, multipleContactsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsPlugin.FindContact$vars"))());
vars.value.searchParameterInLocal = searchParameterIn;
vars.value.multipleContactsInLocal = multipleContactsIn;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var checkContactsPluginVar = new OS.DataTypes.VariableHolder();
var findContactJSJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeContactVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ContactsPluginModel.ContactList))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsPlugin.FindContact$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.checkContactsPluginVar = checkContactsPluginVar;
varBag.findContactJSJSResult = findContactJSJSResult;
varBag.jSONDeserializeContactVar = jSONDeserializeContactVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("xoAkWcGZckm7VUL+oSmYgg:1fgs4BbvP0qK_HuBETESRA:/ClientActionFlows.1fgs4BbvP0qK_HuBETESRA:FkRVX46tIlgLirtQBAz4bw", "ContactsPlugin", "FindContact", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:uz6kbgL9kUidvYv7tIeVUQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:z4XgERwuR0mfxJsVwd3Zxg", callContext.id);
// Execute Action: CheckContactsPlugin
checkContactsPluginVar.value = ContactsPluginController.default.checkContactsPlugin$Action(callContext);

// Is Contacts Plugin available?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:PhXvfrnYnUOY4bR7NCT1Zw", callContext.id) && checkContactsPluginVar.value.isAvailableOut)) {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:u+xdORXEZ0makFPRT4holg", callContext.id);
// Use this action to add a contact to the device's address book.
return controller.safeExecuteAsyncJSNode(ContactsPlugin_controller_FindContact_FindContactJSJS, "FindContactJS", "FindContact", {
SearchParameter: OS.DataTypes.JSConversions.basicTypeToJS(vars.value.searchParameterInLocal, OS.Types.Text, true),
MultipleContacts: OS.DataTypes.JSConversions.basicTypeToJS(vars.value.multipleContactsInLocal, OS.Types.Boolean, true),
ContactsJSON: OS.DataTypes.JSConversions.basicTypeToJS("", OS.Types.Text, true),
Success: OS.DataTypes.JSConversions.basicTypeToJS(false, OS.Types.Boolean, true),
ErrorMessage: OS.DataTypes.JSConversions.basicTypeToJS("", OS.Types.Text, true)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ContactsPlugin.FindContact$findContactJSJSResult"))();
jsNodeResult.contactsJSONOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ContactsJSON, OS.Types.Text);
jsNodeResult.successOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.Success, OS.Types.Boolean);
jsNodeResult.errorMessageOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ErrorMessage, OS.Types.Text);
return jsNodeResult;
}, {}, {}).then(function (results) {
findContactJSJSResult.value = results;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:P11g5sfJdkKOV+lRYQRSRg", callContext.id) && findContactJSJSResult.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:9R7SzlRkj0qky6oRKK9OAw", callContext.id);
// JSON Deserialize: JSONDeserializeContact
jSONDeserializeContactVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(findContactJSJSResult.value.contactsJSONOut, ContactsPluginModel.ContactList, false);
// Set Values
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:P7_uRc5dS0i0vC47owUUrw", callContext.id);
// Error.ErrorMessage = ""
outVars.value.errorOut.errorMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:P7_uRc5dS0i0vC47owUUrw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Success = FindContactJS.Success
outVars.value.successOut = findContactJSJSResult.value.successOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:P7_uRc5dS0i0vC47owUUrw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = 0
outVars.value.errorOut.errorCodeAttr = "0";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:P7_uRc5dS0i0vC47owUUrw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Contacts = JSONDeserializeContact.Data
outVars.value.contactsOut = jSONDeserializeContactVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:IcsElqe9O0ydGG7RI1LdyQ", callContext.id);
} else {
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:JnXmrQvHYUm6PlsLzItFpA", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:JnXmrQvHYUm6PlsLzItFpA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = FindContactJS.ErrorMessage
outVars.value.errorOut.errorMessageAttr = findContactJSJSResult.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:JnXmrQvHYUm6PlsLzItFpA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = 3
outVars.value.errorOut.errorCodeAttr = "3";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:HXuHylSG+kaEQacIOGJKIQ", callContext.id);
}

});
} else {
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:OKLnJGlgkEyC+ffOiS5W0g", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:OKLnJGlgkEyC+ffOiS5W0g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = CheckContactsPlugin.Error.ErrorMessage
outVars.value.errorOut.errorMessageAttr = checkContactsPluginVar.value.errorOut.errorMessageAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:OKLnJGlgkEyC+ffOiS5W0g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = CheckContactsPlugin.Error.ErrorCode
outVars.value.errorOut.errorCodeAttr = checkContactsPluginVar.value.errorOut.errorCodeAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:l7C6Eb58F0eAB8vlcqSaaw", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("FindContact.FindContact", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:5nMR1TayCUepEt+oLfUSKQ", callContext.id);
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:bMMydxBcUEmqdg8PXt274A", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:bMMydxBcUEmqdg8PXt274A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.errorOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:bMMydxBcUEmqdg8PXt274A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = -1
outVars.value.errorOut.errorCodeAttr = (-1).toString();
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:9aS1t98R9kiynDi+pZrx6w", callContext.id);
return OS.Flow.returnAsync(outVars.value);

});
}

throw ex;
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("xoAkWcGZckm7VUL+oSmYgg:1fgs4BbvP0qK_HuBETESRA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("xoAkWcGZckm7VUL+oSmYgg:1fgs4BbvP0qK_HuBETESRA", callContext.id);
throw ex;

});
};
var controller = ContactsPluginController.default;
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.FindContact$vars", [{
name: "SearchParameter",
attrName: "searchParameterInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "MultipleContacts",
attrName: "multipleContactsInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.FindContact$findContactJSJSResult", [{
name: "ContactsJSON",
attrName: "contactsJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Success",
attrName: "successOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.FindContact$outVars", [{
name: "Contacts",
attrName: "contactsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new ContactsPluginModel.ContactList();
},
complexType: ContactsPluginModel.ContactList
}, {
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Error",
attrName: "errorOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new CommonPluginModel.ErrorRec();
},
complexType: CommonPluginModel.ErrorRec
}]);
ContactsPluginController.default.clientActionProxies.findContact$Action = function (searchParameterIn, multipleContactsIn) {
searchParameterIn = (searchParameterIn === undefined) ? "" : searchParameterIn;
multipleContactsIn = (multipleContactsIn === undefined) ? false : multipleContactsIn;
return controller.executeActionInsideJSNode(ContactsPluginController.default.findContact$Action.bind(controller, OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(searchParameterIn, OS.Types.Text), OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(multipleContactsIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Contacts: actionResults.contactsOut,
Success: OS.DataTypes.JSConversions.basicTypeToJS(actionResults.successOut, OS.Types.Boolean, true),
Error: actionResults.errorOut
};
});
};
});
define("ContactsPlugin.controller$FindContact.FindContactJSJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
function onSuccess(contacts) {
    $parameters.Success = true;
    $parameters.ErrorMessage = "";
    $parameters.ContactsJSON = JSON.stringify(contacts);
    $resolve(); 
}

function onError(contactError) {
    $parameters.Success = false;
    $parameters.ErrorMessage = "Could not save contact";
    $resolve();
}

var options = new ContactFindOptions();
options.filter = $parameters.SearchParameter;
options.multiple = $parameters.MultipleContacts;
// Commented to get all fields
// options.desiredFields = [navigator.contacts.fieldType.id];

// Finds contacts
navigator.contacts.find(["*"], onSuccess, onError, options);

});
};
});

define("ContactsPlugin.controller$PickContact", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.controller", "CommonPlugin.model", "ContactsPlugin.controller$PickContact.PickContactJS", "CommonPlugin.model$ErrorRec", "ContactsPlugin.referencesHealth", "ContactsPlugin.referencesHealth$CommonPlugin", "ContactsPlugin.controller$CheckContactsPlugin", "ContactsPlugin.model$ContactRec"], function (exports, OutSystems, ContactsPluginModel, ContactsPluginController, CommonPluginModel, ContactsPlugin_controller_PickContact_PickContactJS) {
var OS = OutSystems.Internal;
ContactsPluginController.default.pickContact$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var checkContactsPluginVar = new OS.DataTypes.VariableHolder();
var pickContactJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeContactVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ContactsPluginModel.ContactRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsPlugin.PickContact$outVars"))());
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.checkContactsPluginVar = checkContactsPluginVar;
varBag.pickContactJSResult = pickContactJSResult;
varBag.jSONDeserializeContactVar = jSONDeserializeContactVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("xoAkWcGZckm7VUL+oSmYgg:19KSw2QSd0WdO+5bRPa64Q:/ClientActionFlows.19KSw2QSd0WdO+5bRPa64Q:UvTZ6+ctRd+aRZiPaBLKzg", "ContactsPlugin", "PickContact", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:JWwfdiucREKkkgD8VUNOLg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:wNyhxct1vkOFzxcTwh1mSQ", callContext.id);
// Execute Action: CheckContactsPlugin
checkContactsPluginVar.value = ContactsPluginController.default.checkContactsPlugin$Action(callContext);

// Is Contacts Plugin available?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:0qTuyOTkwEajeUTDGFs0fQ", callContext.id) && checkContactsPluginVar.value.isAvailableOut)) {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:Cc8UkZD95k2eUYOqtL5bWA", callContext.id);
return controller.safeExecuteAsyncJSNode(ContactsPlugin_controller_PickContact_PickContactJS, "PickContact", "PickContact", {
Success: OS.DataTypes.JSConversions.basicTypeToJS(false, OS.Types.Boolean, true),
ErrorMessage: OS.DataTypes.JSConversions.basicTypeToJS("", OS.Types.Text, true),
ContactJSON: OS.DataTypes.JSConversions.basicTypeToJS("", OS.Types.Text, true)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ContactsPlugin.PickContact$pickContactJSResult"))();
jsNodeResult.successOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.Success, OS.Types.Boolean);
jsNodeResult.errorMessageOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ErrorMessage, OS.Types.Text);
jsNodeResult.contactJSONOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ContactJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {}).then(function (results) {
pickContactJSResult.value = results;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:uBqQAgI_oESIKuDvkoC_AA", callContext.id) && pickContactJSResult.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:Ie3oh6X8k0+L0JzWJGYt1g", callContext.id);
// JSON Deserialize: JSONDeserializeContact
jSONDeserializeContactVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(pickContactJSResult.value.contactJSONOut, ContactsPluginModel.ContactRec, false);
// Set Values
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:2aYamp7HKUCCe3EofXOIUA", callContext.id);
// Error.ErrorMessage = ""
outVars.value.errorOut.errorMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:2aYamp7HKUCCe3EofXOIUA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Success = PickContact.Success
outVars.value.successOut = pickContactJSResult.value.successOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:2aYamp7HKUCCe3EofXOIUA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = 0
outVars.value.errorOut.errorCodeAttr = "0";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:2aYamp7HKUCCe3EofXOIUA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Contact = JSONDeserializeContact.Data
outVars.value.contactOut = jSONDeserializeContactVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:e9qQywlguE+3QPiCINZmiw", callContext.id);
} else {
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:xa1QYCxN_UCRW+LbxdpJOQ", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:xa1QYCxN_UCRW+LbxdpJOQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = PickContact.ErrorMessage
outVars.value.errorOut.errorMessageAttr = pickContactJSResult.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:xa1QYCxN_UCRW+LbxdpJOQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = 3
outVars.value.errorOut.errorCodeAttr = "3";
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:5LiVcoG3YE6p8wDdnxn3rQ", callContext.id);
}

});
} else {
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:QRl3rRqiEUKKcQZ2XyvodA", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:QRl3rRqiEUKKcQZ2XyvodA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = CheckContactsPlugin.Error.ErrorMessage
outVars.value.errorOut.errorMessageAttr = checkContactsPluginVar.value.errorOut.errorMessageAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:QRl3rRqiEUKKcQZ2XyvodA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = CheckContactsPlugin.Error.ErrorCode
outVars.value.errorOut.errorCodeAttr = checkContactsPluginVar.value.errorOut.errorCodeAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:m0XDcTfiYE2BOuwTOXoE_w", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("PickContact.PickContact", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:PUdceZzgQEe4o4L1jKYq5A", callContext.id);
// Set error
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:lsdGSEvxiUizATpN8CKybQ", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:lsdGSEvxiUizATpN8CKybQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.errorOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:lsdGSEvxiUizATpN8CKybQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Error.ErrorCode = -1
outVars.value.errorOut.errorCodeAttr = (-1).toString();
OutSystemsDebugger.handleBreakpoint("xoAkWcGZckm7VUL+oSmYgg:3gXZDvOP4kKUpaOYV1C5_g", callContext.id);
return OS.Flow.returnAsync(outVars.value);

});
}

throw ex;
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("xoAkWcGZckm7VUL+oSmYgg:19KSw2QSd0WdO+5bRPa64Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("xoAkWcGZckm7VUL+oSmYgg:19KSw2QSd0WdO+5bRPa64Q", callContext.id);
throw ex;

});
};
var controller = ContactsPluginController.default;
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.PickContact$pickContactJSResult", [{
name: "Success",
attrName: "successOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ContactJSON",
attrName: "contactJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
ContactsPluginController.default.constructor.registerVariableGroupType("ContactsPlugin.PickContact$outVars", [{
name: "Contact",
attrName: "contactOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new ContactsPluginModel.ContactRec();
},
complexType: ContactsPluginModel.ContactRec
}, {
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Error",
attrName: "errorOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new CommonPluginModel.ErrorRec();
},
complexType: CommonPluginModel.ErrorRec
}]);
ContactsPluginController.default.clientActionProxies.pickContact$Action = function () {
return controller.executeActionInsideJSNode(ContactsPluginController.default.pickContact$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Contact: actionResults.contactOut,
Success: OS.DataTypes.JSConversions.basicTypeToJS(actionResults.successOut, OS.Types.Boolean, true),
Error: actionResults.errorOut
};
});
};
});
define("ContactsPlugin.controller$PickContact.PickContactJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
function onSuccess(contact) {
    // TODO: could store contact js option to perform further operations like 
    // delete, or update
    $parameters.ContactJSON = JSON.stringify(contact);
    $parameters.Success = true;
    $parameters.ErrorMessage = "";
    $resolve(); 
}

function onError(err) {
    $parameters.Success = false;
    $parameters.ErrorMessage = "Could not pick contact";
    $resolve();
}


if (!navigator.contacts) { 
    onError(""); 
}
else {
    // pick contact from device's contact picker
    navigator.contacts.pickContact(onSuccess, onError);
}
});
};
});

define("ContactsPlugin.controller", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsPlugin.controller$debugger"], function (exports, OutSystems, ContactsPluginModel, ContactsPlugin_Controller_debugger) {
var OS = OutSystems.Internal;
var ContactsPluginController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return ContactsPluginController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
ContactsPluginController.default = new Controller();
});
define("ContactsPlugin.controller$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"HpNVSV7JU0+wjPMYh7s1yQ": {
getter: function (varBag, idService) {
return varBag.vars.value.firstNameInLocal;
},
dataType: OS.Types.Text
},
"m+YVGDNOGkCsWBif6_d5eQ": {
getter: function (varBag, idService) {
return varBag.vars.value.lastNameInLocal;
},
dataType: OS.Types.Text
},
"p+9BiVQ94UyE4yCvuXmC4g": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneInLocal;
},
dataType: OS.Types.Text
},
"7QMuQdnxsEqnltpqG2SQRg": {
getter: function (varBag, idService) {
return varBag.vars.value.emailInLocal;
},
dataType: OS.Types.Text
},
"xyX2WRsS2EGQbQpMvVkyyw": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"hebjjazBVUeySVtYntPF1w": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorOut;
}
},
"F2zmZ50abkWaELM+NNhXtA": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"4_ho4lh5Qk+a_D9vdrJ4+Q": {
getter: function (varBag, idService) {
return varBag.checkContactsPluginVar.value;
}
},
"fne0oxQN1UapXaKR4OTNlA": {
getter: function (varBag, idService) {
return varBag.addToContactsJSJSResult.value;
}
},
"bcQBI8pLokGCaqZPZhtMFg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isAvailableOut;
},
dataType: OS.Types.Boolean
},
"ltUQhwgZdEuRij3EF3ro0g": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorOut;
}
},
"sScw4LsKOUOVlXk1BrZY5g": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"bpKPu1M4gUWUEUwLXI47pg": {
getter: function (varBag, idService) {
return varBag.isCordovaDefinedVar.value;
}
},
"YWLhNpojiEaEwcqA4siuaQ": {
getter: function (varBag, idService) {
return varBag.isPluginAvailableJSJSResult.value;
}
},
"67po0cMqik+Vm+fhY2hyqQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.contactOut;
}
},
"osHzgh0vKUmqDePKEMluqA": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"wV74iept30OroIeD5QZyEw": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorOut;
}
},
"PUdceZzgQEe4o4L1jKYq5A": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"wNyhxct1vkOFzxcTwh1mSQ": {
getter: function (varBag, idService) {
return varBag.checkContactsPluginVar.value;
}
},
"Ie3oh6X8k0+L0JzWJGYt1g": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeContactVar.value;
}
},
"Cc8UkZD95k2eUYOqtL5bWA": {
getter: function (varBag, idService) {
return varBag.pickContactJSResult.value;
}
},
"m4Maa2eXSEmKyOBOZQc4lg": {
getter: function (varBag, idService) {
return varBag.vars.value.searchParameterInLocal;
},
dataType: OS.Types.Text
},
"qInmdVHcDU6OCVHJ0QrOaw": {
getter: function (varBag, idService) {
return varBag.vars.value.multipleContactsInLocal;
},
dataType: OS.Types.Boolean
},
"twvj5BKLN0GQFZAOhyheBw": {
getter: function (varBag, idService) {
return varBag.outVars.value.contactsOut;
}
},
"HDQAK4wIh0iOVP44F_kMPA": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"YG9JuNgqy0G5RkXqLiadtQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorOut;
}
},
"5nMR1TayCUepEt+oLfUSKQ": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"z4XgERwuR0mfxJsVwd3Zxg": {
getter: function (varBag, idService) {
return varBag.checkContactsPluginVar.value;
}
},
"9R7SzlRkj0qky6oRKK9OAw": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeContactVar.value;
}
},
"u+xdORXEZ0makFPRT4holg": {
getter: function (varBag, idService) {
return varBag.findContactJSJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
