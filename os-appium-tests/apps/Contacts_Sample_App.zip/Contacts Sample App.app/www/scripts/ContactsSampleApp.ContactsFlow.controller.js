﻿define("ContactsSampleApp.ContactsFlow.controller", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "ContactsSampleApp.Common.controller", "ContactsSampleApp.ContactsFlow.controller$debugger"], function (exports, OutSystems, ContactsSampleAppModel, ContactsSampleAppController, ContactsSampleApp_CommonController, ContactsSampleApp_ContactsFlow_Controller_debugger) {
var OS = OutSystems.Internal;
var ContactsSampleApp_ContactsFlowController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var varBag = {};
var controller = this.controller;
OS.Logger.trace("ContactsFlow", OS.Exceptions.getMessage(ex), ex.name);
return ContactsSampleApp_CommonController.default.handleError(ex, callContext);


};
return Controller;
})(OS.Controller.BaseController);
ContactsSampleApp_ContactsFlowController.default = new Controller();
});

define("ContactsSampleApp.ContactsFlow.controller$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
});
