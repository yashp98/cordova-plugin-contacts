﻿try {require(["OutSystems", "ContactsSampleApp.appDefinition"], function (OutSystems, ContactsSampleAppAppDefinition) {
var OS = OutSystems.Internal;
OS.ErrorScreen.initializeErrorPage(ContactsSampleAppAppDefinition, OS.Application);
});
} catch (ex) {
console.error(e);
}

