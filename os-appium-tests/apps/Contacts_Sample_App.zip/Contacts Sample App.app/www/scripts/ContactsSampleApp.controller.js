﻿define("ContactsSampleApp.controller$FileSystem_GetPhoto", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsSampleApp.controller$FileSystem_GetPhoto.GetContactPhotoJS", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsSampleApp_controller_FileSystem_GetPhoto_GetContactPhotoJS) {
var OS = OutSystems.Internal;
ContactsSampleAppController.default.fileSystem_GetPhoto$Action = function (imageURLIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsSampleApp.FileSystem_GetPhoto$vars"))());
vars.value.imageURLInLocal = imageURLIn;
var getContactPhotoJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ContactsSampleApp.FileSystem_GetPhoto$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getContactPhotoJSResult = getContactPhotoJSResult;
varBag.outVars = outVars;
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:UZ19cTOBJ0utCBtbC0k9Dw:/ClientActionFlows.UZ19cTOBJ0utCBtbC0k9Dw:v3uA2BCoRYyKqZH0ndvtfQ", "ContactsSampleApp", "FileSystem_GetPhoto", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:PBgCxx+430ya0R8h+2UScg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:qB08DTNE5k+gumtZ8Nw9Jw", callContext.id) && ((vars.value.imageURLInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:LUXgeWrXA0+tiIq9sK6ODA", callContext.id);
return controller.safeExecuteAsyncJSNode(ContactsSampleApp_controller_FileSystem_GetPhoto_GetContactPhotoJS, "GetContactPhoto", "FileSystem_GetPhoto", {
ContactPhotoURI: OS.DataTypes.JSConversions.basicTypeToJS(vars.value.imageURLInLocal, OS.Types.Text, true),
ContactPhoto: OS.DataTypes.JSConversions.basicTypeToJS(OS.DataTypes.BinaryData.defaultValue, OS.Types.BinaryData, true),
Success: OS.DataTypes.JSConversions.basicTypeToJS(false, OS.Types.Boolean, true),
ErrorMessage: OS.DataTypes.JSConversions.basicTypeToJS("", OS.Types.Text, true),
ErrorCode: OS.DataTypes.JSConversions.basicTypeToJS(0, OS.Types.Integer, true)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ContactsSampleApp.FileSystem_GetPhoto$getContactPhotoJSResult"))();
jsNodeResult.contactPhotoOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ContactPhoto, OS.Types.BinaryData);
jsNodeResult.successOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.Success, OS.Types.Boolean);
jsNodeResult.errorMessageOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ErrorMessage, OS.Types.Text);
jsNodeResult.errorCodeOut = OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType($parameters.ErrorCode, OS.Types.Integer);
return jsNodeResult;
}, {}, {}).then(function (results) {
getContactPhotoJSResult.value = results;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ropqI9cO+k+B3Ljoy4sUdA", callContext.id) && getContactPhotoJSResult.value.successOut)) {
// Set output
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:skrqfmm3X0KxujgeSkDDIw", callContext.id);
// ContactPhoto = GetContactPhoto.ContactPhoto
outVars.value.contactPhotoOut = getContactPhotoJSResult.value.contactPhotoOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:skrqfmm3X0KxujgeSkDDIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Success = True
outVars.value.successOut = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:3Np8WcSTNUKxYhj+w7Pr0g", callContext.id);
} else {
// Set output
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:Q3biJ_cFPkSpUTWEcjwZyw", callContext.id);
// Error.ErrorCode = GetContactPhoto.ErrorCode
outVars.value.errorOut.errorCodeAttr = (getContactPhotoJSResult.value.errorCodeOut).toString();
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:Q3biJ_cFPkSpUTWEcjwZyw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Error.ErrorMessage = GetContactPhoto.ErrorMessage
outVars.value.errorOut.errorMessageAttr = getContactPhotoJSResult.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:Q3biJ_cFPkSpUTWEcjwZyw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Success = GetContactPhoto.Success
outVars.value.successOut = getContactPhotoJSResult.value.successOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:xhoT4fAvYU+qf3TUS8FR8w", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:yxWHIzYQZEyn8XXqmRiYuA", callContext.id);
// Success = True
outVars.value.successOut = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:obGincUH6UeA9AUr4t6MnQ", callContext.id);
}

});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:UZ19cTOBJ0utCBtbC0k9Dw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:UZ19cTOBJ0utCBtbC0k9Dw", callContext.id);
throw ex;

});
};
var controller = ContactsSampleAppController.default;
ContactsSampleAppController.default.constructor.registerVariableGroupType("ContactsSampleApp.FileSystem_GetPhoto$vars", [{
name: "ImageURL",
attrName: "imageURLInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
ContactsSampleAppController.default.constructor.registerVariableGroupType("ContactsSampleApp.FileSystem_GetPhoto$getContactPhotoJSResult", [{
name: "ContactPhoto",
attrName: "contactPhotoOut",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}, {
name: "Success",
attrName: "successOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ErrorCode",
attrName: "errorCodeOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
ContactsSampleAppController.default.constructor.registerVariableGroupType("ContactsSampleApp.FileSystem_GetPhoto$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Error",
attrName: "errorOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new CommonPluginModel.ErrorRec();
},
complexType: CommonPluginModel.ErrorRec
}, {
name: "ContactPhoto",
attrName: "contactPhotoOut",
mandatory: false,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}]);
ContactsSampleAppController.default.clientActionProxies.fileSystem_GetPhoto$Action = function (imageURLIn) {
imageURLIn = (imageURLIn === undefined) ? "" : imageURLIn;
return controller.executeActionInsideJSNode(ContactsSampleAppController.default.fileSystem_GetPhoto$Action.bind(controller, OS.DataTypes.JSNodeConversions.jsNodeOutputToBasicType(imageURLIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataTypes.JSConversions.basicTypeToJS(actionResults.successOut, OS.Types.Boolean, true),
Error: actionResults.errorOut,
ContactPhoto: OS.DataTypes.JSConversions.basicTypeToJS(actionResults.contactPhotoOut, OS.Types.BinaryData, true)
};
});
};
});
define("ContactsSampleApp.controller$FileSystem_GetPhoto.GetContactPhotoJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
window.resolveLocalFileSystemURL($parameters.ContactPhotoURI, onResolveSuccess, onResolveFail);

function onResolveSuccess(fileEntry) {
    
    fileEntry.file(function (file) {
        var reader = new FileReader();
        
        reader.onloadend = function(evt) {
            // Remove the data:image/jpeg, part of the returned value
            $parameters.ContactPhoto = evt.target.result.substring(evt.target.result.indexOf(',') + 1);
            $parameters.Success = true
            
            $resolve();
        };

        reader.readAsDataURL(file);
        
    }, onErrorReadFile);
}

function onResolveFail(error) {
    $parameters.ErrorMessage = "Error resolving Local File System URL";
    $parameters.ErrorCode = error.code
    $parameters.Success = false
    $resolve();
}

function onErrorReadFile(error) {
    $parameters.ErrorMessage = "Error reading file";
    $parameters.ErrorCode = error.code
    $parameters.Success = false
    $resolve();
}

});
};
});

define("ContactsSampleApp.controller", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller$debugger"], function (exports, OutSystems, ContactsSampleAppModel, ContactsSampleApp_Controller_debugger) {
var OS = OutSystems.Internal;
var ContactsSampleAppController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
ContactsSampleAppController.default = new Controller();
});
define("ContactsSampleApp.controller$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"9yZc9ZC6+UKTjI72i1u3wA": {
getter: function (varBag, idService) {
return varBag.vars.value.imageURLInLocal;
},
dataType: OS.Types.Text
},
"OcOlKrtEREO9_ABRkn5bnw": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"0JJ9SOxZyEu55jESbl+vvA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorOut;
}
},
"2lLUnsvduEyFSgjXUmybuA": {
getter: function (varBag, idService) {
return varBag.outVars.value.contactPhotoOut;
},
dataType: OS.Types.BinaryData
},
"LUXgeWrXA0+tiIq9sK6ODA": {
getter: function (varBag, idService) {
return varBag.getContactPhotoJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
