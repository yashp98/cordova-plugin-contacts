﻿define("CommonPlugin.referencesHealth", [], function () {
});
