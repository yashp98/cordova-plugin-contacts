﻿define("ContactsSampleApp.model$FindContactRequestRec", ["exports", "OutSystems", "ContactsSampleApp.model"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var FindContactRequestRec = (function (_super) {
__extends(FindContactRequestRec, _super);
function FindContactRequestRec(defaults) {
_super.apply(this, arguments);
}
FindContactRequestRec.attributesToDeclare = function () {
return [
this.attr("SearchParameter", "searchParameterAttr", "SearchParameter", false, OS.Types.Text, function () {
return "";
}), 
this.attr("MultipleContacts", "multipleContactsAttr", "MultipleContacts", false, OS.Types.Boolean, function () {
return false;
})
].concat(_super.attributesToDeclare.call(this));
};
FindContactRequestRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
FindContactRequestRec.init();
return FindContactRequestRec;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.FindContactRequestRec = FindContactRequestRec;

});
define("ContactsSampleApp.model$FindContactRequestList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$FindContactRequestRec"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var FindContactRequestList = (function (_super) {
__extends(FindContactRequestList, _super);
function FindContactRequestList(defaults) {
_super.apply(this, arguments);
}
FindContactRequestList.RecordType = ContactsSampleAppModel.FindContactRequestRec;
return FindContactRequestList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.FindContactRequestList = FindContactRequestList;

});
define("ContactsSampleApp.model$ContactFieldList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactFieldRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactFieldList = (function (_super) {
__extends(ContactFieldList, _super);
function ContactFieldList(defaults) {
_super.apply(this, arguments);
}
ContactFieldList.RecordType = ContactsPluginModel.ContactFieldRec;
return ContactFieldList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactFieldList = ContactFieldList;

});
define("ContactsSampleApp.model$ContactAddressList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactAddressRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactAddressList = (function (_super) {
__extends(ContactAddressList, _super);
function ContactAddressList(defaults) {
_super.apply(this, arguments);
}
ContactAddressList.RecordType = ContactsPluginModel.ContactAddressRec;
return ContactAddressList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactAddressList = ContactAddressList;

});
define("ContactsSampleApp.model$ContactOrganizationList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactOrganizationRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactOrganizationList = (function (_super) {
__extends(ContactOrganizationList, _super);
function ContactOrganizationList(defaults) {
_super.apply(this, arguments);
}
ContactOrganizationList.RecordType = ContactsPluginModel.ContactOrganizationRec;
return ContactOrganizationList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactOrganizationList = ContactOrganizationList;

});
define("ContactsSampleApp.model$ContactRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactRecord = (function (_super) {
__extends(ContactRecord, _super);
function ContactRecord(defaults) {
_super.apply(this, arguments);
}
ContactRecord.attributesToDeclare = function () {
return [
this.attr("Contact", "contactAttr", "Contact", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactRec());
}, ContactsPluginModel.ContactRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactRecord.fromStructure = function (str) {
return new ContactRecord(new ContactRecord.RecordClass({
contactAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactRecord.IsAnonymousRecord = true;
ContactRecord.UniqueId = "02fbfcb4-679e-8285-4fb4-6fe3cfa74602";
ContactRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactRecord.init();
return ContactRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.ContactRecord = ContactRecord;

});
define("ContactsSampleApp.model$AddContactRequestRec", ["exports", "OutSystems", "ContactsSampleApp.model"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var AddContactRequestRec = (function (_super) {
__extends(AddContactRequestRec, _super);
function AddContactRequestRec(defaults) {
_super.apply(this, arguments);
}
AddContactRequestRec.attributesToDeclare = function () {
return [
this.attr("FirstName", "firstNameAttr", "FirstName", false, OS.Types.Text, function () {
return "";
}), 
this.attr("LastName", "lastNameAttr", "LastName", false, OS.Types.Text, function () {
return "";
}), 
this.attr("Phone", "phoneAttr", "Phone", false, OS.Types.PhoneNumber, function () {
return "";
}), 
this.attr("Email", "emailAttr", "Email", false, OS.Types.Email, function () {
return "";
})
].concat(_super.attributesToDeclare.call(this));
};
AddContactRequestRec.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
AddContactRequestRec.init();
return AddContactRequestRec;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.AddContactRequestRec = AddContactRequestRec;

});
define("ContactsSampleApp.model$AddContactRequestRecord", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$AddContactRequestRec"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var AddContactRequestRecord = (function (_super) {
__extends(AddContactRequestRecord, _super);
function AddContactRequestRecord(defaults) {
_super.apply(this, arguments);
}
AddContactRequestRecord.attributesToDeclare = function () {
return [
this.attr("AddContactRequest", "addContactRequestAttr", "AddContactRequest", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsSampleAppModel.AddContactRequestRec());
}, ContactsSampleAppModel.AddContactRequestRec)
].concat(_super.attributesToDeclare.call(this));
};
AddContactRequestRecord.fromStructure = function (str) {
return new AddContactRequestRecord(new AddContactRequestRecord.RecordClass({
addContactRequestAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AddContactRequestRecord.IsAnonymousRecord = true;
AddContactRequestRecord.UniqueId = "0a6963bd-4042-b572-c317-6a571001fffd";
AddContactRequestRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
AddContactRequestRecord.init();
return AddContactRequestRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.AddContactRequestRecord = AddContactRequestRecord;

});
define("ContactsSampleApp.model$FindContactRequestRecord", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$FindContactRequestRec"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var FindContactRequestRecord = (function (_super) {
__extends(FindContactRequestRecord, _super);
function FindContactRequestRecord(defaults) {
_super.apply(this, arguments);
}
FindContactRequestRecord.attributesToDeclare = function () {
return [
this.attr("FindContactRequest", "findContactRequestAttr", "FindContactRequest", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsSampleAppModel.FindContactRequestRec());
}, ContactsSampleAppModel.FindContactRequestRec)
].concat(_super.attributesToDeclare.call(this));
};
FindContactRequestRecord.fromStructure = function (str) {
return new FindContactRequestRecord(new FindContactRequestRecord.RecordClass({
findContactRequestAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FindContactRequestRecord.IsAnonymousRecord = true;
FindContactRequestRecord.UniqueId = "1387b7b9-43be-bef5-e368-b92ed24f9afe";
FindContactRequestRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
FindContactRequestRecord.init();
return FindContactRequestRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.FindContactRequestRecord = FindContactRequestRecord;

});
define("ContactsSampleApp.model$FindContactRequestRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$FindContactRequestRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var FindContactRequestRecordList = (function (_super) {
__extends(FindContactRequestRecordList, _super);
function FindContactRequestRecordList(defaults) {
_super.apply(this, arguments);
}
FindContactRequestRecordList.RecordType = ContactsSampleAppModel.FindContactRequestRecord;
return FindContactRequestRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.FindContactRequestRecordList = FindContactRequestRecordList;

});
define("ContactsSampleApp.model$ContactFieldRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactFieldRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactFieldRecord = (function (_super) {
__extends(ContactFieldRecord, _super);
function ContactFieldRecord(defaults) {
_super.apply(this, arguments);
}
ContactFieldRecord.attributesToDeclare = function () {
return [
this.attr("ContactField", "contactFieldAttr", "ContactField", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactFieldRec());
}, ContactsPluginModel.ContactFieldRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactFieldRecord.fromStructure = function (str) {
return new ContactFieldRecord(new ContactFieldRecord.RecordClass({
contactFieldAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactFieldRecord.IsAnonymousRecord = true;
ContactFieldRecord.UniqueId = "27effb4f-73b6-2c44-3999-1cf7173f1d5b";
ContactFieldRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactFieldRecord.init();
return ContactFieldRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.ContactFieldRecord = ContactFieldRecord;

});
define("ContactsSampleApp.model$ContactFieldRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$ContactFieldRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactFieldRecordList = (function (_super) {
__extends(ContactFieldRecordList, _super);
function ContactFieldRecordList(defaults) {
_super.apply(this, arguments);
}
ContactFieldRecordList.RecordType = ContactsSampleAppModel.ContactFieldRecord;
return ContactFieldRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactFieldRecordList = ContactFieldRecordList;

});
define("ContactsSampleApp.model$MenuActionRecord", ["exports", "OutSystems", "MobilePatterns.model", "ContactsSampleApp.model", "MobilePatterns.model$MenuActionRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$MobilePatterns"], function (exports, OutSystems, MobilePatternsModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var MenuActionRecord = (function (_super) {
__extends(MenuActionRecord, _super);
function MenuActionRecord(defaults) {
_super.apply(this, arguments);
}
MenuActionRecord.attributesToDeclare = function () {
return [
this.attr("MenuAction", "menuActionAttr", "MenuAction", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.MenuActionRec());
}, MobilePatternsModel.MenuActionRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuActionRecord.fromStructure = function (str) {
return new MenuActionRecord(new MenuActionRecord.RecordClass({
menuActionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuActionRecord.IsAnonymousRecord = true;
MenuActionRecord.UniqueId = "954cd123-1210-e70f-33f1-84017bf580ac";
MenuActionRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
MenuActionRecord.init();
return MenuActionRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.MenuActionRecord = MenuActionRecord;

});
define("ContactsSampleApp.model$MenuActionRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$MenuActionRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var MenuActionRecordList = (function (_super) {
__extends(MenuActionRecordList, _super);
function MenuActionRecordList(defaults) {
_super.apply(this, arguments);
}
MenuActionRecordList.RecordType = ContactsSampleAppModel.MenuActionRecord;
return MenuActionRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.MenuActionRecordList = MenuActionRecordList;

});
define("ContactsSampleApp.model$StorageTypeRecord", ["exports", "OutSystems", "FilePlugin.model", "ContactsSampleApp.model", "FilePlugin.model$StorageTypeRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$FilePlugin"], function (exports, OutSystems, FilePluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var StorageTypeRecord = (function (_super) {
__extends(StorageTypeRecord, _super);
function StorageTypeRecord(defaults) {
_super.apply(this, arguments);
}
StorageTypeRecord.attributesToDeclare = function () {
return [
this.attr("StorageType", "storageTypeAttr", "StorageType", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new FilePluginModel.StorageTypeRec());
}, FilePluginModel.StorageTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
StorageTypeRecord.fromStructure = function (str) {
return new StorageTypeRecord(new StorageTypeRecord.RecordClass({
storageTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StorageTypeRecord.IsAnonymousRecord = true;
StorageTypeRecord.UniqueId = "307a72dc-6a70-42ef-3c3f-cea28bdbf985";
StorageTypeRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
StorageTypeRecord.init();
return StorageTypeRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.StorageTypeRecord = StorageTypeRecord;

});
define("ContactsSampleApp.model$ErrorList", ["exports", "OutSystems", "CommonPlugin.model", "ContactsSampleApp.model", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ErrorList = (function (_super) {
__extends(ErrorList, _super);
function ErrorList(defaults) {
_super.apply(this, arguments);
}
ErrorList.RecordType = CommonPluginModel.ErrorRec;
return ErrorList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ErrorList = ErrorList;

});
define("ContactsSampleApp.model$ColumnBreakList", ["exports", "OutSystems", "MobilePatterns.model", "ContactsSampleApp.model", "MobilePatterns.model$ColumnBreakRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$MobilePatterns"], function (exports, OutSystems, MobilePatternsModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ColumnBreakList = (function (_super) {
__extends(ColumnBreakList, _super);
function ColumnBreakList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakList.RecordType = MobilePatternsModel.ColumnBreakRec;
return ColumnBreakList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ColumnBreakList = ColumnBreakList;

});
define("ContactsSampleApp.model$Mobile_OperatingSystemRecord", ["exports", "OutSystems", "CommonPlugin.model", "ContactsSampleApp.model", "CommonPlugin.model$Mobile_OperatingSystemRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemRecord = (function (_super) {
__extends(Mobile_OperatingSystemRecord, _super);
function Mobile_OperatingSystemRecord(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemRecord.attributesToDeclare = function () {
return [
this.attr("Mobile_OperatingSystem", "mobile_OperatingSystemAttr", "Mobile_OperatingSystem", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.Mobile_OperatingSystemRec());
}, CommonPluginModel.Mobile_OperatingSystemRec)
].concat(_super.attributesToDeclare.call(this));
};
Mobile_OperatingSystemRecord.fromStructure = function (str) {
return new Mobile_OperatingSystemRecord(new Mobile_OperatingSystemRecord.RecordClass({
mobile_OperatingSystemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Mobile_OperatingSystemRecord.IsAnonymousRecord = true;
Mobile_OperatingSystemRecord.UniqueId = "f56bdc75-0614-38d3-e901-3cdbe4073c38";
Mobile_OperatingSystemRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
Mobile_OperatingSystemRecord.init();
return Mobile_OperatingSystemRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.Mobile_OperatingSystemRecord = Mobile_OperatingSystemRecord;

});
define("ContactsSampleApp.model$Mobile_OperatingSystemRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$Mobile_OperatingSystemRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemRecordList = (function (_super) {
__extends(Mobile_OperatingSystemRecordList, _super);
function Mobile_OperatingSystemRecordList(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemRecordList.RecordType = ContactsSampleAppModel.Mobile_OperatingSystemRecord;
return Mobile_OperatingSystemRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.Mobile_OperatingSystemRecordList = Mobile_OperatingSystemRecordList;

});
define("ContactsSampleApp.model$MenuActionList", ["exports", "OutSystems", "MobilePatterns.model", "ContactsSampleApp.model", "MobilePatterns.model$MenuActionRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$MobilePatterns"], function (exports, OutSystems, MobilePatternsModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var MenuActionList = (function (_super) {
__extends(MenuActionList, _super);
function MenuActionList(defaults) {
_super.apply(this, arguments);
}
MenuActionList.RecordType = MobilePatternsModel.MenuActionRec;
return MenuActionList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.MenuActionList = MenuActionList;

});
define("ContactsSampleApp.model$ContactNameRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactNameRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactNameRecord = (function (_super) {
__extends(ContactNameRecord, _super);
function ContactNameRecord(defaults) {
_super.apply(this, arguments);
}
ContactNameRecord.attributesToDeclare = function () {
return [
this.attr("ContactName", "contactNameAttr", "ContactName", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactNameRec());
}, ContactsPluginModel.ContactNameRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactNameRecord.fromStructure = function (str) {
return new ContactNameRecord(new ContactNameRecord.RecordClass({
contactNameAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactNameRecord.IsAnonymousRecord = true;
ContactNameRecord.UniqueId = "9faf2b14-b0e9-9043-56f4-c30c2e29c727";
ContactNameRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactNameRecord.init();
return ContactNameRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.ContactNameRecord = ContactNameRecord;

});
define("ContactsSampleApp.model$ContactNameRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$ContactNameRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactNameRecordList = (function (_super) {
__extends(ContactNameRecordList, _super);
function ContactNameRecordList(defaults) {
_super.apply(this, arguments);
}
ContactNameRecordList.RecordType = ContactsSampleAppModel.ContactNameRecord;
return ContactNameRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactNameRecordList = ContactNameRecordList;

});
define("ContactsSampleApp.model$ErrorRecord", ["exports", "OutSystems", "CommonPlugin.model", "ContactsSampleApp.model", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ErrorRecord = (function (_super) {
__extends(ErrorRecord, _super);
function ErrorRecord(defaults) {
_super.apply(this, arguments);
}
ErrorRecord.attributesToDeclare = function () {
return [
this.attr("Error", "errorAttr", "Error", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.ErrorRec());
}, CommonPluginModel.ErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ErrorRecord.fromStructure = function (str) {
return new ErrorRecord(new ErrorRecord.RecordClass({
errorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ErrorRecord.IsAnonymousRecord = true;
ErrorRecord.UniqueId = "cbbd7d57-66e1-86ff-28ab-3b75adf75b93";
ErrorRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ErrorRecord.init();
return ErrorRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.ErrorRecord = ErrorRecord;

});
define("ContactsSampleApp.model$ErrorRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$ErrorRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ErrorRecordList = (function (_super) {
__extends(ErrorRecordList, _super);
function ErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ErrorRecordList.RecordType = ContactsSampleAppModel.ErrorRecord;
return ErrorRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ErrorRecordList = ErrorRecordList;

});
define("ContactsSampleApp.model$ContactNameList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactNameRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactNameList = (function (_super) {
__extends(ContactNameList, _super);
function ContactNameList(defaults) {
_super.apply(this, arguments);
}
ContactNameList.RecordType = ContactsPluginModel.ContactNameRec;
return ContactNameList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactNameList = ContactNameList;

});
define("ContactsSampleApp.model$AddContactRequestList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$AddContactRequestRec"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var AddContactRequestList = (function (_super) {
__extends(AddContactRequestList, _super);
function AddContactRequestList(defaults) {
_super.apply(this, arguments);
}
AddContactRequestList.RecordType = ContactsSampleAppModel.AddContactRequestRec;
return AddContactRequestList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.AddContactRequestList = AddContactRequestList;

});
define("ContactsSampleApp.model$ContactOrganizationRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactOrganizationRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactOrganizationRecord = (function (_super) {
__extends(ContactOrganizationRecord, _super);
function ContactOrganizationRecord(defaults) {
_super.apply(this, arguments);
}
ContactOrganizationRecord.attributesToDeclare = function () {
return [
this.attr("ContactOrganization", "contactOrganizationAttr", "ContactOrganization", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactOrganizationRec());
}, ContactsPluginModel.ContactOrganizationRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactOrganizationRecord.fromStructure = function (str) {
return new ContactOrganizationRecord(new ContactOrganizationRecord.RecordClass({
contactOrganizationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactOrganizationRecord.IsAnonymousRecord = true;
ContactOrganizationRecord.UniqueId = "93f02c96-b6e3-055c-f3e0-db8e15f483ac";
ContactOrganizationRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactOrganizationRecord.init();
return ContactOrganizationRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.ContactOrganizationRecord = ContactOrganizationRecord;

});
define("ContactsSampleApp.model$ContactOrganizationRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$ContactOrganizationRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactOrganizationRecordList = (function (_super) {
__extends(ContactOrganizationRecordList, _super);
function ContactOrganizationRecordList(defaults) {
_super.apply(this, arguments);
}
ContactOrganizationRecordList.RecordType = ContactsSampleAppModel.ContactOrganizationRecord;
return ContactOrganizationRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactOrganizationRecordList = ContactOrganizationRecordList;

});
define("ContactsSampleApp.model$StorageTypeRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$StorageTypeRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var StorageTypeRecordList = (function (_super) {
__extends(StorageTypeRecordList, _super);
function StorageTypeRecordList(defaults) {
_super.apply(this, arguments);
}
StorageTypeRecordList.RecordType = ContactsSampleAppModel.StorageTypeRecord;
return StorageTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.StorageTypeRecordList = StorageTypeRecordList;

});
define("ContactsSampleApp.model$StorageTypeList", ["exports", "OutSystems", "FilePlugin.model", "ContactsSampleApp.model", "FilePlugin.model$StorageTypeRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$FilePlugin"], function (exports, OutSystems, FilePluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var StorageTypeList = (function (_super) {
__extends(StorageTypeList, _super);
function StorageTypeList(defaults) {
_super.apply(this, arguments);
}
StorageTypeList.RecordType = FilePluginModel.StorageTypeRec;
return StorageTypeList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.StorageTypeList = StorageTypeList;

});
define("ContactsSampleApp.model$ContactAddressRecord", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactAddressRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactAddressRecord = (function (_super) {
__extends(ContactAddressRecord, _super);
function ContactAddressRecord(defaults) {
_super.apply(this, arguments);
}
ContactAddressRecord.attributesToDeclare = function () {
return [
this.attr("ContactAddress", "contactAddressAttr", "ContactAddress", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsPluginModel.ContactAddressRec());
}, ContactsPluginModel.ContactAddressRec)
].concat(_super.attributesToDeclare.call(this));
};
ContactAddressRecord.fromStructure = function (str) {
return new ContactAddressRecord(new ContactAddressRecord.RecordClass({
contactAddressAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ContactAddressRecord.IsAnonymousRecord = true;
ContactAddressRecord.UniqueId = "a141adb5-7ff9-2281-e375-405159ed89a0";
ContactAddressRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ContactAddressRecord.init();
return ContactAddressRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.ContactAddressRecord = ContactAddressRecord;

});
define("ContactsSampleApp.model$AddContactRequestRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$AddContactRequestRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var AddContactRequestRecordList = (function (_super) {
__extends(AddContactRequestRecordList, _super);
function AddContactRequestRecordList(defaults) {
_super.apply(this, arguments);
}
AddContactRequestRecordList.RecordType = ContactsSampleAppModel.AddContactRequestRecord;
return AddContactRequestRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.AddContactRequestRecordList = AddContactRequestRecordList;

});
define("ContactsSampleApp.model$ColumnBreakRecord", ["exports", "OutSystems", "MobilePatterns.model", "ContactsSampleApp.model", "MobilePatterns.model$ColumnBreakRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$MobilePatterns"], function (exports, OutSystems, MobilePatternsModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecord = (function (_super) {
__extends(ColumnBreakRecord, _super);
function ColumnBreakRecord(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecord.attributesToDeclare = function () {
return [
this.attr("ColumnBreak", "columnBreakAttr", "ColumnBreak", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MobilePatternsModel.ColumnBreakRec());
}, MobilePatternsModel.ColumnBreakRec)
].concat(_super.attributesToDeclare.call(this));
};
ColumnBreakRecord.fromStructure = function (str) {
return new ColumnBreakRecord(new ColumnBreakRecord.RecordClass({
columnBreakAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColumnBreakRecord.IsAnonymousRecord = true;
ColumnBreakRecord.UniqueId = "b6adbbf4-e08b-ad29-75a6-f8f796279b71";
ColumnBreakRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ColumnBreakRecord.init();
return ColumnBreakRecord;
})(OS.DataTypes.GenericRecord);
ContactsSampleAppModel.ColumnBreakRecord = ColumnBreakRecord;

});
define("ContactsSampleApp.model$ColumnBreakRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$ColumnBreakRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecordList = (function (_super) {
__extends(ColumnBreakRecordList, _super);
function ColumnBreakRecordList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecordList.RecordType = ContactsSampleAppModel.ColumnBreakRecord;
return ColumnBreakRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ColumnBreakRecordList = ColumnBreakRecordList;

});
define("ContactsSampleApp.model$ContactAddressRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$ContactAddressRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactAddressRecordList = (function (_super) {
__extends(ContactAddressRecordList, _super);
function ContactAddressRecordList(defaults) {
_super.apply(this, arguments);
}
ContactAddressRecordList.RecordType = ContactsSampleAppModel.ContactAddressRecord;
return ContactAddressRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactAddressRecordList = ContactAddressRecordList;

});
define("ContactsSampleApp.model$ContactList", ["exports", "OutSystems", "ContactsPlugin.model", "ContactsSampleApp.model", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$ContactsPlugin"], function (exports, OutSystems, ContactsPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactList = (function (_super) {
__extends(ContactList, _super);
function ContactList(defaults) {
_super.apply(this, arguments);
}
ContactList.RecordType = ContactsPluginModel.ContactRec;
return ContactList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactList = ContactList;

});
define("ContactsSampleApp.model$ContactRecordList", ["exports", "OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.model$ContactRecord"], function (exports, OutSystems, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var ContactRecordList = (function (_super) {
__extends(ContactRecordList, _super);
function ContactRecordList(defaults) {
_super.apply(this, arguments);
}
ContactRecordList.RecordType = ContactsSampleAppModel.ContactRecord;
return ContactRecordList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.ContactRecordList = ContactRecordList;

});
define("ContactsSampleApp.model$Mobile_OperatingSystemList", ["exports", "OutSystems", "CommonPlugin.model", "ContactsSampleApp.model", "CommonPlugin.model$Mobile_OperatingSystemRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, ContactsSampleAppModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemList = (function (_super) {
__extends(Mobile_OperatingSystemList, _super);
function Mobile_OperatingSystemList(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemList.RecordType = CommonPluginModel.Mobile_OperatingSystemRec;
return Mobile_OperatingSystemList;
})(OS.DataTypes.GenericRecordList);
ContactsSampleAppModel.Mobile_OperatingSystemList = Mobile_OperatingSystemList;

});
define("ContactsSampleApp.model", ["exports", "OutSystems"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ContactsSampleAppModel = exports;
Object.defineProperty(ContactsSampleAppModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["ce77e8b9-2e19-49b0-b485-1dbee0f6c291"];
}
});

ContactsSampleAppModel.staticEntities = {};
ContactsSampleAppModel.staticEntities.mobile_OperatingSystem = {};
var getMobile_OperatingSystemRecord = function (record) {
return OS.ApplicationInfo.getModules()["5b6515d9-f417-41d9-9c45-5dfc1a7b019f"].staticEntities["c1eb5dfb-b8c1-47fc-bc7d-1cd017f67311"][record];
};
Object.defineProperty(ContactsSampleAppModel.staticEntities.mobile_OperatingSystem, "android", {
get: function () {
return getMobile_OperatingSystemRecord("01edb2f7-0e57-4dc0-9509-92d0d28ebfe3");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.mobile_OperatingSystem, "windows", {
get: function () {
return getMobile_OperatingSystemRecord("164b2bee-9204-44fd-99b7-4d8e15ea9c63");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.mobile_OperatingSystem, "iOS", {
get: function () {
return getMobile_OperatingSystemRecord("91c837e3-89f4-4179-9b8c-c79a99090027");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.mobile_OperatingSystem, "other", {
get: function () {
return getMobile_OperatingSystemRecord("e0264a53-735d-4dea-8647-b8bfe757d34b");
}
});

ContactsSampleAppModel.staticEntities.menuAction = {};
var getMenuActionRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["9cc12883-06ab-4cf0-9997-ede7c6c02d67"][record];
};
Object.defineProperty(ContactsSampleAppModel.staticEntities.menuAction, "menu", {
get: function () {
return getMenuActionRecord("55ba18a9-cd6b-45dd-99ce-9081ee1387ea");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.menuAction, "auto", {
get: function () {
return getMenuActionRecord("6c0c753a-86f4-4e76-9781-6e821c850c72");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.menuAction, "hidden", {
get: function () {
return getMenuActionRecord("86c9d356-be64-46a1-b027-843ab93b4aea");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.menuAction, "back", {
get: function () {
return getMenuActionRecord("f2db3c50-4c38-4ee7-a770-aa9476cb0d68");
}
});

ContactsSampleAppModel.staticEntities.columnBreak = {};
var getColumnBreakRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["cce6ac21-942a-492f-8b46-64c5e6ea057b"][record];
};
Object.defineProperty(ContactsSampleAppModel.staticEntities.columnBreak, "breakMiddle", {
get: function () {
return getColumnBreakRecord("3b01fc99-ef23-4043-8771-f88660720e01");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.columnBreak, "breakAll", {
get: function () {
return getColumnBreakRecord("43788f73-6893-4396-b67a-04a6ff690e74");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.columnBreak, "breakNone", {
get: function () {
return getColumnBreakRecord("69e6c609-9e8a-45a7-b006-45b92275ec49");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.columnBreak, "breakLast", {
get: function () {
return getColumnBreakRecord("6b3725c8-8951-48ed-a977-cbfaf003c896");
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.columnBreak, "breakFirst", {
get: function () {
return getColumnBreakRecord("8c8b45b6-c1af-4b11-907e-3c8a5ce161e2");
}
});

ContactsSampleAppModel.staticEntities.storageType = {};
var getStorageTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["dba29b2f-44a2-40ee-8034-35085b88a8fe"].staticEntities["ce5288f5-7a74-4d79-ba18-a48c137bd489"][record];
};
Object.defineProperty(ContactsSampleAppModel.staticEntities.storageType, "internal", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStorageTypeRecord("7adf55e3-18d0-4074-8948-43dd54505f29"));
}
});

Object.defineProperty(ContactsSampleAppModel.staticEntities.storageType, "external", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStorageTypeRecord("98071031-b214-4e31-b2cb-0148e4e230f4"));
}
});

});
