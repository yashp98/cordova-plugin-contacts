﻿define("ContactsSampleApp.referencesHealth$CommonPlugin", [], function () {
// Reference to producer 'CommonPlugin' is OK.
});
define("ContactsSampleApp.referencesHealth$ContactsPlugin", [], function () {
// Reference to producer 'ContactsPlugin' is OK.
});
define("ContactsSampleApp.referencesHealth$FilePlugin", [], function () {
// Reference to producer 'FilePlugin' is OK.
});
define("ContactsSampleApp.referencesHealth$MobilePatterns", [], function () {
// Reference to producer 'MobilePatterns' is OK.
});
define("ContactsSampleApp.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ContactsSampleApp.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ContactsSampleApp.referencesHealth", [], function () {
});
