﻿define("ContactsPlugin.referencesHealth$CommonPlugin", [], function () {
// Reference to producer 'CommonPlugin' is OK.
});
define("ContactsPlugin.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ContactsPlugin.referencesHealth", [], function () {
});
