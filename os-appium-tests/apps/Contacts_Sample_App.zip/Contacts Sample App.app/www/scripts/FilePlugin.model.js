﻿define("FilePlugin.model$StorageTypeRec", ["exports", "OutSystems", "FilePlugin.model"], function (exports, OutSystems, FilePluginModel) {
var OS = OutSystems.Internal;
var StorageTypeRec = (function (_super) {
__extends(StorageTypeRec, _super);
function StorageTypeRec(defaults) {
_super.apply(this, arguments);
}
StorageTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, OS.Types.Integer, function () {
return 0;
}), 
this.attr("Label", "labelAttr", "Label", true, OS.Types.Text, function () {
return "";
}), 
this.attr("Order", "orderAttr", "Order", true, OS.Types.Integer, function () {
return 0;
}), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, OS.Types.Boolean, function () {
return false;
})
].concat(_super.attributesToDeclare.call(this));
};
StorageTypeRec.generateFromLocalStorage = function () {
return false;
};
StorageTypeRec.init();
return StorageTypeRec;
})(OS.DataTypes.GenericRecord);
FilePluginModel.StorageTypeRec = StorageTypeRec;

});
define("FilePlugin.model$StorageTypeRecord", ["exports", "OutSystems", "FilePlugin.model", "FilePlugin.model$StorageTypeRec"], function (exports, OutSystems, FilePluginModel) {
var OS = OutSystems.Internal;
var StorageTypeRecord = (function (_super) {
__extends(StorageTypeRecord, _super);
function StorageTypeRecord(defaults) {
_super.apply(this, arguments);
}
StorageTypeRecord.attributesToDeclare = function () {
return [
this.attr("StorageType", "storageTypeAttr", "StorageType", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new FilePluginModel.StorageTypeRec());
}, FilePluginModel.StorageTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
StorageTypeRecord.fromStructure = function (str) {
return new StorageTypeRecord(new StorageTypeRecord.RecordClass({
storageTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StorageTypeRecord.IsAnonymousRecord = true;
StorageTypeRecord.UniqueId = "307a72dc-6a70-42ef-3c3f-cea28bdbf985";
StorageTypeRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
StorageTypeRecord.init();
return StorageTypeRecord;
})(OS.DataTypes.GenericRecord);
FilePluginModel.StorageTypeRecord = StorageTypeRecord;

});
define("FilePlugin.model$ErrorList", ["exports", "OutSystems", "CommonPlugin.model", "FilePlugin.model", "CommonPlugin.model$ErrorRec", "FilePlugin.referencesHealth", "FilePlugin.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, FilePluginModel) {
var OS = OutSystems.Internal;
var ErrorList = (function (_super) {
__extends(ErrorList, _super);
function ErrorList(defaults) {
_super.apply(this, arguments);
}
ErrorList.RecordType = CommonPluginModel.ErrorRec;
return ErrorList;
})(OS.DataTypes.GenericRecordList);
FilePluginModel.ErrorList = ErrorList;

});
define("FilePlugin.model$Mobile_OperatingSystemRecord", ["exports", "OutSystems", "CommonPlugin.model", "FilePlugin.model", "CommonPlugin.model$Mobile_OperatingSystemRec", "FilePlugin.referencesHealth", "FilePlugin.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, FilePluginModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemRecord = (function (_super) {
__extends(Mobile_OperatingSystemRecord, _super);
function Mobile_OperatingSystemRecord(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemRecord.attributesToDeclare = function () {
return [
this.attr("Mobile_OperatingSystem", "mobile_OperatingSystemAttr", "Mobile_OperatingSystem", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.Mobile_OperatingSystemRec());
}, CommonPluginModel.Mobile_OperatingSystemRec)
].concat(_super.attributesToDeclare.call(this));
};
Mobile_OperatingSystemRecord.fromStructure = function (str) {
return new Mobile_OperatingSystemRecord(new Mobile_OperatingSystemRecord.RecordClass({
mobile_OperatingSystemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Mobile_OperatingSystemRecord.IsAnonymousRecord = true;
Mobile_OperatingSystemRecord.UniqueId = "f56bdc75-0614-38d3-e901-3cdbe4073c38";
Mobile_OperatingSystemRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
Mobile_OperatingSystemRecord.init();
return Mobile_OperatingSystemRecord;
})(OS.DataTypes.GenericRecord);
FilePluginModel.Mobile_OperatingSystemRecord = Mobile_OperatingSystemRecord;

});
define("FilePlugin.model$Mobile_OperatingSystemRecordList", ["exports", "OutSystems", "FilePlugin.model", "FilePlugin.model$Mobile_OperatingSystemRecord"], function (exports, OutSystems, FilePluginModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemRecordList = (function (_super) {
__extends(Mobile_OperatingSystemRecordList, _super);
function Mobile_OperatingSystemRecordList(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemRecordList.RecordType = FilePluginModel.Mobile_OperatingSystemRecord;
return Mobile_OperatingSystemRecordList;
})(OS.DataTypes.GenericRecordList);
FilePluginModel.Mobile_OperatingSystemRecordList = Mobile_OperatingSystemRecordList;

});
define("FilePlugin.model$ErrorRecord", ["exports", "OutSystems", "CommonPlugin.model", "FilePlugin.model", "CommonPlugin.model$ErrorRec", "FilePlugin.referencesHealth", "FilePlugin.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, FilePluginModel) {
var OS = OutSystems.Internal;
var ErrorRecord = (function (_super) {
__extends(ErrorRecord, _super);
function ErrorRecord(defaults) {
_super.apply(this, arguments);
}
ErrorRecord.attributesToDeclare = function () {
return [
this.attr("Error", "errorAttr", "Error", false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.ErrorRec());
}, CommonPluginModel.ErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ErrorRecord.fromStructure = function (str) {
return new ErrorRecord(new ErrorRecord.RecordClass({
errorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ErrorRecord.IsAnonymousRecord = true;
ErrorRecord.UniqueId = "cbbd7d57-66e1-86ff-28ab-3b75adf75b93";
ErrorRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.namedAttributeReaderImplementation, attributeOrder);
};
ErrorRecord.init();
return ErrorRecord;
})(OS.DataTypes.GenericRecord);
FilePluginModel.ErrorRecord = ErrorRecord;

});
define("FilePlugin.model$ErrorRecordList", ["exports", "OutSystems", "FilePlugin.model", "FilePlugin.model$ErrorRecord"], function (exports, OutSystems, FilePluginModel) {
var OS = OutSystems.Internal;
var ErrorRecordList = (function (_super) {
__extends(ErrorRecordList, _super);
function ErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ErrorRecordList.RecordType = FilePluginModel.ErrorRecord;
return ErrorRecordList;
})(OS.DataTypes.GenericRecordList);
FilePluginModel.ErrorRecordList = ErrorRecordList;

});
define("FilePlugin.model$StorageTypeRecordList", ["exports", "OutSystems", "FilePlugin.model", "FilePlugin.model$StorageTypeRecord"], function (exports, OutSystems, FilePluginModel) {
var OS = OutSystems.Internal;
var StorageTypeRecordList = (function (_super) {
__extends(StorageTypeRecordList, _super);
function StorageTypeRecordList(defaults) {
_super.apply(this, arguments);
}
StorageTypeRecordList.RecordType = FilePluginModel.StorageTypeRecord;
return StorageTypeRecordList;
})(OS.DataTypes.GenericRecordList);
FilePluginModel.StorageTypeRecordList = StorageTypeRecordList;

});
define("FilePlugin.model$StorageTypeList", ["exports", "OutSystems", "FilePlugin.model", "FilePlugin.model$StorageTypeRec"], function (exports, OutSystems, FilePluginModel) {
var OS = OutSystems.Internal;
var StorageTypeList = (function (_super) {
__extends(StorageTypeList, _super);
function StorageTypeList(defaults) {
_super.apply(this, arguments);
}
StorageTypeList.RecordType = FilePluginModel.StorageTypeRec;
return StorageTypeList;
})(OS.DataTypes.GenericRecordList);
FilePluginModel.StorageTypeList = StorageTypeList;

});
define("FilePlugin.model$Mobile_OperatingSystemList", ["exports", "OutSystems", "CommonPlugin.model", "FilePlugin.model", "CommonPlugin.model$Mobile_OperatingSystemRec", "FilePlugin.referencesHealth", "FilePlugin.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, FilePluginModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemList = (function (_super) {
__extends(Mobile_OperatingSystemList, _super);
function Mobile_OperatingSystemList(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemList.RecordType = CommonPluginModel.Mobile_OperatingSystemRec;
return Mobile_OperatingSystemList;
})(OS.DataTypes.GenericRecordList);
FilePluginModel.Mobile_OperatingSystemList = Mobile_OperatingSystemList;

});
define("FilePlugin.model", ["exports", "OutSystems"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var FilePluginModel = exports;
Object.defineProperty(FilePluginModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["dba29b2f-44a2-40ee-8034-35085b88a8fe"];
}
});

FilePluginModel.staticEntities = {};
FilePluginModel.staticEntities.storageType = {};
var getStorageTypeRecord = function (record) {
return FilePluginModel.module.staticEntities["ce5288f5-7a74-4d79-ba18-a48c137bd489"][record];
};
Object.defineProperty(FilePluginModel.staticEntities.storageType, "internal", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStorageTypeRecord("7adf55e3-18d0-4074-8948-43dd54505f29"));
}
});

Object.defineProperty(FilePluginModel.staticEntities.storageType, "external", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStorageTypeRecord("98071031-b214-4e31-b2cb-0148e4e230f4"));
}
});

FilePluginModel.staticEntities.mobile_OperatingSystem = {};
var getMobile_OperatingSystemRecord = function (record) {
return OS.ApplicationInfo.getModules()["5b6515d9-f417-41d9-9c45-5dfc1a7b019f"].staticEntities["c1eb5dfb-b8c1-47fc-bc7d-1cd017f67311"][record];
};
Object.defineProperty(FilePluginModel.staticEntities.mobile_OperatingSystem, "android", {
get: function () {
return getMobile_OperatingSystemRecord("01edb2f7-0e57-4dc0-9509-92d0d28ebfe3");
}
});

Object.defineProperty(FilePluginModel.staticEntities.mobile_OperatingSystem, "windows", {
get: function () {
return getMobile_OperatingSystemRecord("164b2bee-9204-44fd-99b7-4d8e15ea9c63");
}
});

Object.defineProperty(FilePluginModel.staticEntities.mobile_OperatingSystem, "iOS", {
get: function () {
return getMobile_OperatingSystemRecord("91c837e3-89f4-4179-9b8c-c79a99090027");
}
});

Object.defineProperty(FilePluginModel.staticEntities.mobile_OperatingSystem, "other", {
get: function () {
return getMobile_OperatingSystemRecord("e0264a53-735d-4dea-8647-b8bfe757d34b");
}
});

});
