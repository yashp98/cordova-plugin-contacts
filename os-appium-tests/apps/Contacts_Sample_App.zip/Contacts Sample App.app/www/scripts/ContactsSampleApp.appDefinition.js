﻿define("ContactsSampleApp.appDefinition", ["OutSystems"], function (OutSystems) {
var OS = OutSystems.Internal;
return {
environmentKey: "067b8a61-1087-4831-8930-f3607c42ad0f",
environmentName: "Development",
applicationKey: "f82fc270-8263-4e82-8f9d-dc8a0cf7942f",
applicationName: "Contacts Sample App",
userProviderName: "Users",
debugEnabled: true,
homeModuleName: "ContactsSampleApp",
homeModuleKey: "ce77e8b9-2e19-49b0-b485-1dbee0f6c291",
homeModuleControllerName: "ContactsSampleApp.controller",
homeModuleLanguageResourcesName: "ContactsSampleApp.languageResources",
defaultTransition: "SlideFromRight",
errorPageConfig: {
showExceptionStack: false
}
};
});
