﻿define("ContactsSampleApp.ContactsFlow.Find.mvc$model", ["OutSystems", "ContactsSampleApp.model", "CommonPlugin.model", "ContactsPlugin.controller", "ContactsPlugin.model", "ContactsSampleApp.model$ContactList", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$FindContact", "ContactsSampleApp.referencesHealth$ContactsPlugin", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.model$FindContactRequestRec"], function (OutSystems, ContactsSampleAppModel, CommonPluginModel, ContactsPluginController, ContactsPluginModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("FindContactRequest", "findContactRequestVar", "FindContactRequest", true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsSampleAppModel.FindContactRequestRec());
}, ContactsSampleAppModel.FindContactRequestRec), 
this.attr("Contacts", "contactsVar", "Contacts", true, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ContactsSampleAppModel.ContactList());
}, ContactsSampleAppModel.ContactList)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromLocalStorage = function (row, indexRef, attributeOrder) {
return this.fromLocalStorageImplementation(row, indexRef, OS.Entities.attributeReaderImplementation, attributeOrder);
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Form1: OS.Model.ValidationWidgetRecord,
inputSearchParameter: OS.Model.ValidationWidgetRecord,
switchMultipleContacts: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("ContactsSampleApp.ContactsFlow.Find.mvc$view", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.controller", "ContactsPlugin.model", "react", "OutSystemsReactView", "ContactsSampleApp.ContactsFlow.Find.mvc$model", "ContactsSampleApp.ContactsFlow.Find.mvc$controller", "ContactsSampleApp.Common.Layout.mvc$view", "OutSystemsReactWidgets", "ContactsSampleApp.Common.MenuIcon.mvc$view", "MobilePatterns.Utilities.MarginContainer.mvc$view", "ContactsSampleApp.ContactsFlow.BottomBar.mvc$view", "ContactsSampleApp.model$ContactList", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$FindContact", "ContactsSampleApp.referencesHealth$ContactsPlugin", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.model$FindContactRequestRec"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginController, ContactsPluginModel, React, OSView, ContactsSampleApp_ContactsFlow_Find_mvc_model, ContactsSampleApp_ContactsFlow_Find_mvc_controller, ContactsSampleApp_Common_Layout_mvc_view, OSWidgets, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ContactsFlow.Find";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MobilePatterns.BaseTheme.css", "css/MobilePatterns.TabletTheme.css", "css/ContactsSampleApp.ContactsSampleApp.css", "css/MobilePatterns.TabletTheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ContactsSampleApp_Common_Layout_mvc_view, ContactsSampleApp_Common_MenuIcon_mvc_view, MobilePatterns_Utilities_MarginContainer_mvc_view, ContactsSampleApp_ContactsFlow_BottomBar_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Find_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ContactsSampleApp_ContactsFlow_Find_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(ContactsSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: new PlaceholderContent(function () {
return ["Find", React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Contacts plugin")];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/ContactsSampleApp/Helper", {}),
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "8kiB85JOEkCZebXHKWYCcA"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "info-circle",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-style-key": "hn0+wgVchUi2M9RnWtoMBw"
},
text: [" "],
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(MobilePatterns_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form card",
_idProps: {
service: idService,
name: "Form1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/testapp_name1 OnClick");
controller.name1OnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "testapp_name1"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Test app - Name1"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "rBmu8iEjKEWEXdC+7dbf6A"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/last1 OnClick");
controller.last1OnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "last1"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Last1"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "FwRYpKO_r0e_d3piKzUiKg"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/phonenumber OnClick");
controller.onClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "phonenumber"
},
_widgetRecordProvider: widgetsRecordProvider
}, "+351"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "D6v03WK9hkuY6akNDkI+wQ"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/email3_outsystems_com OnClick");
controller.email3_outsystems_comOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "email3_outsystems_com"
},
_widgetRecordProvider: widgetsRecordProvider
}, "email3@outsystems.com"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "TKjitco_2kCPrLZxNShF2g"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/number1 OnClick");
controller.onClick2$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "number1"
},
_widgetRecordProvider: widgetsRecordProvider
}, "1"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "c48HgmC_nkygEvqWMNaG7w"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/testapp_name3 OnClick");
controller.name3OnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "testapp_name3"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Test app - Name3"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "EpvFZJMzykiYcrHPoylsgA"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/name2 OnClick");
controller.name2OnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "name2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Name2"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "gtAEkRxLJUSMOcmbXZMe_w"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/email3 OnClick");
controller.email3OnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "email3"
},
_widgetRecordProvider: widgetsRecordProvider
}, "email3"), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "VSQw2EVeVkqgk1vQbtYmPg"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/nonexistentcontact OnClick");
controller.zeroOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "nonexistentcontact"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Non existent contact")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "inputSearchParameter",
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Search Parameter"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.findContactRequestVar.searchParameterAttr, function (value) {
model.variables.findContactRequestVar.searchParameterAttr = value;
}),
_idProps: {
service: idService,
name: "inputSearchParameter"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Search parameter which the contacts will be matched to.", React.DOM.br(), "NOTE: All fields from the contact will be matched against this.")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSAutoMarginTop"
},
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "switchMultipleContacts",
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Multiple Contacts"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.findContactRequestVar.multipleContactsAttr, function (value) {
model.variables.findContactRequestVar.multipleContactsAttr = value;
}),
_idProps: {
service: idService,
name: "switchMultipleContacts"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, "When true, a list of matches will be returned; otherwise, only one result will be returned.")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-style-key": "qtEn8QXTpEO9p7rSujX6xA"
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
_this.validateWidget(idService.getId("Form1"));
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/findContactButton OnClick");
return controller.findOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});

;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "findContactButton"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Find Contact")))];
})
},
_dependencies: [asPrimitiveValue(model.variables.findContactRequestVar.multipleContactsAttr), asPrimitiveValue(model.variables.findContactRequestVar.searchParameterAttr)]
}), React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"data-style-key": "4sjVxSdU_kajy8c_pk_guA"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.contactsVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.ListItem, {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ContactsFlow/Find/ListItem1 OnClick");
controller.contactOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "list-item",
triggerActionOnFullSwipeLeft: true,
triggerActionOnFullSwipeRight: true,
_idProps: {
service: idService,
name: "ListItem1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
leftActions: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "OSFillParent"
},
value: model.variables.contactsVar.getCurrent(callContext.iterationContext).nameAttr.formattedAttr,
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Id:"), React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.contactsVar.getCurrent(callContext.iterationContext).idAttr,
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
rightActions: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.contactsVar.getCurrent(callContext.iterationContext).idAttr), asPrimitiveValue(model.variables.contactsVar.getCurrent(callContext.iterationContext).nameAttr.formattedAttr)]
})];
}, callContext, idService, "1")
},
_dependencies: []
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ContactsSampleApp_ContactsFlow_BottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.contactsVar), asPrimitiveValue(model.variables.findContactRequestVar.multipleContactsAttr), asPrimitiveValue(model.variables.findContactRequestVar.searchParameterAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ContactsSampleApp.ContactsFlow.Find.mvc$controller", ["OutSystems", "ContactsSampleApp.model", "ContactsSampleApp.controller", "CommonPlugin.model", "ContactsPlugin.controller", "ContactsPlugin.model", "ContactsSampleApp.languageResources", "ContactsSampleApp.ContactsFlow.controller", "ContactsSampleApp.ContactsFlow.Find.mvc$debugger", "ContactsSampleApp.model$ContactList", "CommonPlugin.model$ErrorRec", "ContactsSampleApp.referencesHealth", "ContactsSampleApp.referencesHealth$CommonPlugin", "ContactsPlugin.controller$FindContact", "ContactsSampleApp.referencesHealth$ContactsPlugin", "ContactsPlugin.model$ContactRec", "ContactsSampleApp.model$FindContactRequestRec"], function (OutSystems, ContactsSampleAppModel, ContactsSampleAppController, CommonPluginModel, ContactsPluginController, ContactsPluginModel, ContactsSampleAppLanguageResources, ContactsSampleApp_ContactsFlowController, ContactsSampleApp_ContactsFlow_Find_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:xcIpCBC+X0+QNFvASwQs6g:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.xcIpCBC+X0+QNFvASwQs6g:ZjIRJvSZfbcmGXlRopmpGw", "ContactsSampleApp", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:jR_nDUbju0aNExPqb+xHMw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:2pYv2TLh_0CsO1B3F2RRSw", callContext.id);
// FindContactRequest.SearchParameter = "Test"
model.variables.findContactRequestVar.searchParameterAttr = "Test";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:2pYv2TLh_0CsO1B3F2RRSw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = False
model.variables.findContactRequestVar.multipleContactsAttr = false;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:0V1CLWpqS0i2WkZesYgsiA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:xcIpCBC+X0+QNFvASwQs6g", callContext.id);
}

};
Controller.prototype._findOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("FindOnClick");
callContext = controller.callContext(callContext);
var findContactVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.findContactVar = findContactVar;
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:oLj1LK7NS0yteHTjrDdDBg:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.oLj1LK7NS0yteHTjrDdDBg:djoraAWJJbEvhUTPFlyLYg", "ContactsSampleApp", "FindOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:DHO0S4PsgkyUFsU66ZjOKg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:xXq55x5JXE+kYPOAs0xC_A", callContext.id);
// Execute Action: FindContact
model.flush();
return ContactsPluginController.default.findContact$Action(model.variables.findContactRequestVar.searchParameterAttr, model.variables.findContactRequestVar.multipleContactsAttr, callContext).then(function (value) {
findContactVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:VgL3bRU9P0S3VExiIMYeMA", callContext.id) && findContactVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:JnYT18Tfp0mEJbLeBX95RA", callContext.id);
// Contacts = FindContact.Contacts
model.variables.contactsVar = findContactVar.value.contactsOut;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:HN0iMBTTZEqQr7nKQSxWGA", callContext.id);
} else {
// FindContact Error
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:jHCsYcJPekCSxvR6fqXYgA", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(((("ErrorCode: " + findContactVar.value.errorOut.errorCodeAttr) + ", ErrorMessage: ") + findContactVar.value.errorOut.errorMessageAttr), /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:djHvhbrhW0mgAbfc+s93Bg", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:oLj1LK7NS0yteHTjrDdDBg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:oLj1LK7NS0yteHTjrDdDBg", callContext.id);
throw ex;

});
};
Controller.prototype._name3OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name3OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:JIBOLXUONkutgJPzl8Gv7A:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.JIBOLXUONkutgJPzl8Gv7A:4mz2+lLq0IegnPbh2FOCPg", "ContactsSampleApp", "Name3OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:1bECfBqRxky19m1tD2iKxA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ALDHQ0meAUGRsj1TMG4e2w", callContext.id);
// FindContactRequest.SearchParameter = "Test app - Name3"
model.variables.findContactRequestVar.searchParameterAttr = "Test app - Name3";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:ALDHQ0meAUGRsj1TMG4e2w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:hGuMJh3qH0OentpEW2eGdg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:JIBOLXUONkutgJPzl8Gv7A", callContext.id);
}

};
Controller.prototype._name2OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name2OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:5i9dQpXTCU2G2ZA3MfIJ_w:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.5i9dQpXTCU2G2ZA3MfIJ_w:HHaauc8PH+tDu+ygvDTUkw", "ContactsSampleApp", "Name2OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:MtRsiydK7EGA8urVA6AFng", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:aBfSZMeJEkGFhq97RnnGYA", callContext.id);
// FindContactRequest.SearchParameter = "Name2"
model.variables.findContactRequestVar.searchParameterAttr = "Name2";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:aBfSZMeJEkGFhq97RnnGYA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:xJCFOhPTn0CAtDAP383LjA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:5i9dQpXTCU2G2ZA3MfIJ_w", callContext.id);
}

};
Controller.prototype._onClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:odPYUucuGk2xd0s6OOgvLw:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.odPYUucuGk2xd0s6OOgvLw:Eq__O3myKzWCE54AzS3KYA", "ContactsSampleApp", "OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:4SNtYCpGlk+9+bLtm06zcA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:KlZjaCRng0KBIFBy_l6fQQ", callContext.id);
// FindContactRequest.SearchParameter = "+351"
model.variables.findContactRequestVar.searchParameterAttr = "+351";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:KlZjaCRng0KBIFBy_l6fQQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:a4frLvbsf0+T5xnwmaSuvg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:odPYUucuGk2xd0s6OOgvLw", callContext.id);
}

};
Controller.prototype._name1OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Name1OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:FgXZdRQ4bUuKgZkKgis9dA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.FgXZdRQ4bUuKgZkKgis9dA:MNdk_sWPxXE95wr7+eUK5Q", "ContactsSampleApp", "Name1OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:qDw8WMttXUCTZO6q2Y3cDw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:2y+bxH6VI0WRuogGfR0tLw", callContext.id);
// FindContactRequest.SearchParameter = "Test app - Name1"
model.variables.findContactRequestVar.searchParameterAttr = "Test app - Name1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:2y+bxH6VI0WRuogGfR0tLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:trfpB2bvL0qvjIY4g3T6EA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:FgXZdRQ4bUuKgZkKgis9dA", callContext.id);
}

};
Controller.prototype._contactOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ContactOnClick");
callContext = controller.callContext(callContext);
var serializeContactVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.serializeContactVar = serializeContactVar;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:U0SLfBghXE+XlpaTA+To5w:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.U0SLfBghXE+XlpaTA+To5w:kOK1rZUtMZYlaCkFe9Devg", "ContactsSampleApp", "ContactOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:uKsSodNbWkiS475vTDqdYg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:s+mh_8us2EeZE8QRQT3Jcg", callContext.id);
// JSON Serialize: SerializeContact
serializeContactVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.contactsVar.getCurrent(callContext.iterationContext), false, false);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:AVCKl5ajIkKly7LaWs4DBQ", callContext.id);
// Destination: /ContactsSampleApp/Contact
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/ContactsSampleApp/Contact", {
ContactSerialized: serializeContactVar.value.jSONOut
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:U0SLfBghXE+XlpaTA+To5w", callContext.id);
}

};
Controller.prototype._zeroOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("zeroOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:G7bMgeOrJUaQIkTrQIcSIA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.G7bMgeOrJUaQIkTrQIcSIA:BVFRO97O+zlVR6pGqCSkxg", "ContactsSampleApp", "zeroOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:LQJRrW3P8kCpXf7EzDwr0Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:VhYcQfmc7ky8K7C8alCu3A", callContext.id);
// FindContactRequest.SearchParameter = "non existent contact"
model.variables.findContactRequestVar.searchParameterAttr = "non existent contact";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:VhYcQfmc7ky8K7C8alCu3A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:aIcQXZX5ZU+82TZev9sYOw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:G7bMgeOrJUaQIkTrQIcSIA", callContext.id);
}

};
Controller.prototype._last1OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Last1OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:QPq9oTM8GkWCeLwCHdhUHA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.QPq9oTM8GkWCeLwCHdhUHA:mNeurz3rcOxpe4SDejQr+Q", "ContactsSampleApp", "Last1OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:kXgKiKqR+0uoWkOcor+6yQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:NvsY+VCH6UCcqgwHdljuLg", callContext.id);
// FindContactRequest.SearchParameter = "Last1"
model.variables.findContactRequestVar.searchParameterAttr = "Last1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:NvsY+VCH6UCcqgwHdljuLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:rmMo+ooUn06GJiQq5ocKog", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:QPq9oTM8GkWCeLwCHdhUHA", callContext.id);
}

};
Controller.prototype._email3_outsystems_comOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("email3_outsystems_comOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:x1+xpGgC8UWjyxBNw0Vqtg:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.x1+xpGgC8UWjyxBNw0Vqtg:bgImO5KfrUzj1hgfKm1Btw", "ContactsSampleApp", "email3_outsystems_comOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:URUNhLjJKkuYl7xhBfcawg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:M2+HMVXFgk2QPen1eXXTrg", callContext.id);
// FindContactRequest.SearchParameter = "email3@outsystems.com"
model.variables.findContactRequestVar.searchParameterAttr = "email3@outsystems.com";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:M2+HMVXFgk2QPen1eXXTrg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:QjT5sFLTfkOERhfn5nZYOg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:x1+xpGgC8UWjyxBNw0Vqtg", callContext.id);
}

};
Controller.prototype._email3OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("email3OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:29sltGgAU0eqbye6RuGQGg:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.29sltGgAU0eqbye6RuGQGg:Vg3iRCI9oFd8CL_K_IonQw", "ContactsSampleApp", "email3OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:kBWm71KOSEG2v_e8+C2I2g", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:73LnPjpo50GvppbVVWOUnA", callContext.id);
// FindContactRequest.SearchParameter = "email3"
model.variables.findContactRequestVar.searchParameterAttr = "email3";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:73LnPjpo50GvppbVVWOUnA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:VYEpYGrXTkGsUQdHjmF6qg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:29sltGgAU0eqbye6RuGQGg", callContext.id);
}

};
Controller.prototype._onClick2$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick2");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:gFFGuRzqrk2tMOQP8FQ95g:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA/ClientActions.gFFGuRzqrk2tMOQP8FQ95g:VbeT13SjyZ73DuiMh_3bqA", "ContactsSampleApp", "OnClick2", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:O+Tea53QOkS_j0qIUSoyCw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:Td+SbrQXTUOCS09oDTw5mg", callContext.id);
// FindContactRequest.SearchParameter = "1"
model.variables.findContactRequestVar.searchParameterAttr = "1";
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:Td+SbrQXTUOCS09oDTw5mg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FindContactRequest.MultipleContacts = True
model.variables.findContactRequestVar.multipleContactsAttr = true;
OutSystemsDebugger.handleBreakpoint("ueh3zhkusEm0hR2+4PbCkQ:1bu4kAOWREui0yqCh8O5Tg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:gFFGuRzqrk2tMOQP8FQ95g", callContext.id);
}

};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.findOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._findOnClick$Action, callContext);

};
Controller.prototype.name3OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name3OnClick$Action, callContext);

};
Controller.prototype.name2OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name2OnClick$Action, callContext);

};
Controller.prototype.onClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick$Action, callContext);

};
Controller.prototype.name1OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._name1OnClick$Action, callContext);

};
Controller.prototype.contactOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._contactOnClick$Action, callContext);

};
Controller.prototype.zeroOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._zeroOnClick$Action, callContext);

};
Controller.prototype.last1OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._last1OnClick$Action, callContext);

};
Controller.prototype.email3_outsystems_comOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._email3_outsystems_comOnClick$Action, callContext);

};
Controller.prototype.email3OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._email3OnClick$Action, callContext);

};
Controller.prototype.onClick2$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick2$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q:oTswzJAtrUammmPpEwGYvg", "ContactsSampleApp", "ContactsFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ueh3zhkusEm0hR2+4PbCkQ:xYlIxD2an0erUBu5RrcKIA:/NRWebFlows.i8nFxlGNzkynmBJaegbj0Q/NodesShownInESpaceTree.xYlIxD2an0erUBu5RrcKIA:+_TZCJR677sChAN5k+Gxow", "ContactsSampleApp", "Find", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:xYlIxD2an0erUBu5RrcKIA", callContext.id);
OutSystemsDebugger.pop("ueh3zhkusEm0hR2+4PbCkQ:i8nFxlGNzkynmBJaegbj0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ContactsFlow/Find On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ContactsSampleApp_ContactsFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ContactsSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ContactsSampleAppLanguageResources);
});

define("ContactsSampleApp.ContactsFlow.Find.mvc$debugger", ["exports", "Debugger", "OutSystems"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"xXq55x5JXE+kYPOAs0xC_A": {
getter: function (varBag, idService) {
return varBag.findContactVar.value;
}
},
"s+mh_8us2EeZE8QRQT3Jcg": {
getter: function (varBag, idService) {
return varBag.serializeContactVar.value;
}
},
"hWOYv3RsSkW4TZ2V1HWQzw": {
getter: function (varBag, idService) {
return varBag.model.variables.findContactRequestVar;
}
},
"KFcFSQUr4U+BUAvwh7kMCA": {
getter: function (varBag, idService) {
return varBag.model.variables.contactsVar;
}
},
"AOZimC5+B02KI7f6Bq4OgQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"e7K1ZfCyYE+D_jFOQXOhJA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"e6oq91AuDEKyqiL8PCG6lw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"_2uNrOOwPEu8l0jTI7LMCw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderContent"));
})(varBag.model, idService);
}
},
"YhxN23vruEim3V5DgzGtLw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"IzMZK35waUyGP97h2TsHog": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MarginContainer"));
})(varBag.model, idService);
}
},
"UyonuzqeEEGGsjvy1jKe7Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form1"));
})(varBag.model, idService);
}
},
"ULI9+HQwFki_xo2w5jCf2w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("testapp_name1"));
})(varBag.model, idService);
}
},
"rBmu8iEjKEWEXdC+7dbf6A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("last1"));
})(varBag.model, idService);
}
},
"FwRYpKO_r0e_d3piKzUiKg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("phonenumber"));
})(varBag.model, idService);
}
},
"D6v03WK9hkuY6akNDkI+wQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("email3_outsystems_com"));
})(varBag.model, idService);
}
},
"TKjitco_2kCPrLZxNShF2g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("number1"));
})(varBag.model, idService);
}
},
"c48HgmC_nkygEvqWMNaG7w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("testapp_name3"));
})(varBag.model, idService);
}
},
"EpvFZJMzykiYcrHPoylsgA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("name2"));
})(varBag.model, idService);
}
},
"gtAEkRxLJUSMOcmbXZMe_w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("email3"));
})(varBag.model, idService);
}
},
"VSQw2EVeVkqgk1vQbtYmPg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("nonexistentcontact"));
})(varBag.model, idService);
}
},
"40_2xoX4v0m6rPrnhoijOw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("inputSearchParameter"));
})(varBag.model, idService);
}
},
"6z9IvWqREUGAyrAfMrpu0Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("switchMultipleContacts"));
})(varBag.model, idService);
}
},
"qtEn8QXTpEO9p7rSujX6xA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("findContactButton"));
})(varBag.model, idService);
}
},
"luXOHy2LDEeVOwp_w5WUFw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ListItem1"));
})(varBag.model, idService);
}
},
"bkUNt4v38UGz_H+o6TCEvA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
